import * as React from "react"
import { ArrowRight, Copy } from "lucide-react"

import { Badge } from "@/components/badge"
import { Button } from "@/components/button"
import { Toaster, showSuccessToast } from "@/components/sonner"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/tabs"
import { cn } from "@/lib/utils"

// 8 个系统管理 demo 页 + Dashboard
import { LoginSettingPage } from "@/pages/LoginSettingPage"
import { AppCenterPage } from "@/pages/AppCenterPage"
import { SessionManagementPage } from "@/pages/SessionManagementPage"
import { MembersPage } from "@/pages/MembersPage"
import { RolesPage } from "@/pages/RolesPage"
import { OperationsLogPage } from "@/pages/OperationsLogPage"
import { LoginLogPage } from "@/pages/LoginLogPage"
import { GeneralSettingsPage } from "@/pages/GeneralSettingsPage"
import { DashboardPage } from "@/pages/DashboardPage"
import { UnderDevelopmentPage } from "@/pages/UnderDevelopmentPage"

// Foundations 区
import { Foundations } from "@/showcase/foundations"

// 71 个组件 showcase
import { AccordionShowcase } from "@/showcase/components/accordion"
import { AlertShowcase } from "@/showcase/components/alert"
import { AlertDialogShowcase } from "@/showcase/components/alert-dialog"
import { AppCardShowcase } from "@/showcase/components/app-card"
import { AspectRatioShowcase } from "@/showcase/components/aspect-ratio"
import { AvatarShowcase } from "@/showcase/components/avatar"
import { BadgeShowcase } from "@/showcase/components/badge"
import { BreadcrumbShowcase } from "@/showcase/components/breadcrumb"
import { ButtonShowcase } from "@/showcase/components/button"
import { ButtonGroupShowcase } from "@/showcase/components/button-group"
import { CalendarShowcase } from "@/showcase/components/calendar"
import { CardShowcase } from "@/showcase/components/card"
import { CarouselShowcase } from "@/showcase/components/carousel"
import { ChannelDonutShowcase } from "@/showcase/components/channel-donut"
import { ChartShowcase } from "@/showcase/components/chart"
import { CheckboxShowcase } from "@/showcase/components/checkbox"
import { CollapsibleShowcase } from "@/showcase/components/collapsible"
import { ComboboxShowcase } from "@/showcase/components/combobox"
import { CommandShowcase } from "@/showcase/components/command"
import { ConfirmDialogShowcase } from "@/showcase/components/confirm-dialog"
import { ContextMenuShowcase } from "@/showcase/components/context-menu"
import { DataTableShowcase } from "@/showcase/components/data-table"
import { DatePickerShowcase } from "@/showcase/components/date-picker"
import { DialogShowcase } from "@/showcase/components/dialog"
import { DirectionShowcase } from "@/showcase/components/direction"
import { DropdownMenuShowcase } from "@/showcase/components/dropdown-menu"
import { EmptyStateShowcase } from "@/showcase/components/empty-state"
import { FieldShowcase } from "@/showcase/components/field"
import { FunnelBarsShowcase } from "@/showcase/components/funnel-bars"
import { HoverCardShowcase } from "@/showcase/components/hover-card"
import { InputShowcase } from "@/showcase/components/input"
import { InputGroupShowcase } from "@/showcase/components/input-group"
import { InputOTPShowcase } from "@/showcase/components/input-otp"
import { ItemShowcase } from "@/showcase/components/item"
import { KbdShowcase } from "@/showcase/components/kbd"
import { KpiCardShowcase } from "@/showcase/components/kpi-card"
import { LabelShowcase } from "@/showcase/components/label"
import { MenubarShowcase } from "@/showcase/components/menubar"
import { NarrowRailShowcase } from "@/showcase/components/narrow-rail"
import { NativeSelectShowcase } from "@/showcase/components/native-select"
import { NumberInputShowcase } from "@/showcase/components/number-input"
import { PaginationShowcase } from "@/showcase/components/pagination"
import { PopoverShowcase } from "@/showcase/components/popover"
import { ProgressShowcase } from "@/showcase/components/progress"
import { RadioPillShowcase } from "@/showcase/components/radio-pill"
import { ResizableShowcase } from "@/showcase/components/resizable"
import { ScrollAreaShowcase } from "@/showcase/components/scroll-area"
import { SearchInputShowcase } from "@/showcase/components/search-input"
import { SelectShowcase } from "@/showcase/components/select"
import { SeparatorShowcase } from "@/showcase/components/separator"
import { SettingsCardShowcase } from "@/showcase/components/settings-card"
import { SheetShowcase } from "@/showcase/components/sheet"
import { SidebarShowcase } from "@/showcase/components/sidebar"
import { SkeletonShowcase } from "@/showcase/components/skeleton"
import { SliderShowcase } from "@/showcase/components/slider"
import { SonnerShowcase } from "@/showcase/components/sonner"
import { SpinnerShowcase } from "@/showcase/components/spinner"
import { SubNavShowcase } from "@/showcase/components/sub-nav"
import { SwitchShowcase } from "@/showcase/components/switch"
import { TableShowcase } from "@/showcase/components/table"
import { TableSkeletonShowcase } from "@/showcase/components/table-skeleton"
import { TabsShowcase } from "@/showcase/components/tabs"
import { TagInputShowcase } from "@/showcase/components/tag-input"
import { TextareaShowcase } from "@/showcase/components/textarea"
import { ToggleShowcase } from "@/showcase/components/toggle"
import { ToggleChipShowcase } from "@/showcase/components/toggle-chip"
import { ToggleGroupShowcase } from "@/showcase/components/toggle-group"
import { TooltipShowcase } from "@/showcase/components/tooltip"
import { TopPageBarShowcase } from "@/showcase/components/top-page-bar"
import { TrendComboChartShowcase } from "@/showcase/components/trend-combo-chart"
import { TypographyComponentShowcase } from "@/showcase/components/typography"
import { WideNavShowcase } from "@/showcase/components/wide-nav"

// ─── Catalog item ─────────────────────────────────────────────────────────────

type CatalogItem = {
  name: string
  source: string
  showcase: () => React.ReactNode
  /** 子组件（同族分支，在目录中缩进展示于父项之下） */
  children?: CatalogItem[]
}

function wrap(name: string, source: string, showcase: () => React.ReactNode): CatalogItem {
  return { name, source, showcase }
}

// 展平嵌套目录（父项后紧跟其子项），用于内容区卡片渲染与计数
function flattenCatalog(items: CatalogItem[]): CatalogItem[] {
  return items.flatMap((item) => [item, ...(item.children ?? [])])
}

function toAnchorId(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")
}

const catalogItems: CatalogItem[] = [
  wrap("App Card", "src/components/app-card.tsx", AppCardShowcase),
  wrap("Accordion", "src/components/accordion.tsx", AccordionShowcase),
  wrap("Alert", "src/components/alert.tsx", AlertShowcase),
  wrap("Alert Dialog", "src/components/alert-dialog.tsx", AlertDialogShowcase),
  wrap("Aspect Ratio", "src/components/aspect-ratio.tsx", AspectRatioShowcase),
  wrap("Avatar", "src/components/avatar.tsx", AvatarShowcase),
  wrap("Badge", "src/components/badge.tsx", BadgeShowcase),
  wrap("Breadcrumb", "src/components/breadcrumb.tsx", BreadcrumbShowcase),
  wrap("Button", "src/components/button.tsx", ButtonShowcase),
  wrap("Button Group", "src/components/button-group.tsx", ButtonGroupShowcase),
  wrap("Calendar", "src/components/calendar.tsx", CalendarShowcase),
  wrap("Card", "src/components/card.tsx", CardShowcase),
  wrap("Carousel", "src/components/carousel.tsx", CarouselShowcase),
  {
    ...wrap("Chart", "src/components/chart.tsx", ChartShowcase),
    children: [
      wrap("Channel Donut", "src/components/channel-donut.tsx", ChannelDonutShowcase),
      wrap("Funnel Bars", "src/components/funnel-bars.tsx", FunnelBarsShowcase),
      wrap("Trend Combo Chart", "src/components/trend-combo-chart.tsx", TrendComboChartShowcase),
    ],
  },
  wrap("Checkbox", "src/components/checkbox.tsx", CheckboxShowcase),
  wrap("Collapsible", "src/components/collapsible.tsx", CollapsibleShowcase),
  wrap("Combobox", "src/components/combobox.tsx", ComboboxShowcase),
  wrap("Command", "src/components/command.tsx", CommandShowcase),
  wrap("Confirm Dialog", "src/components/confirm-dialog.tsx", ConfirmDialogShowcase),
  wrap("Context Menu", "src/components/context-menu.tsx", ContextMenuShowcase),
  wrap("Data Table", "src/components/data-table.tsx", DataTableShowcase),
  wrap("Date Picker", "src/components/date-picker.tsx", DatePickerShowcase),
  wrap("Dialog", "src/components/dialog.tsx", DialogShowcase),
  wrap("Direction", "src/components/direction.tsx", DirectionShowcase),
  wrap("Dropdown Menu", "src/components/dropdown-menu.tsx", DropdownMenuShowcase),
  wrap("Empty State", "src/components/empty-state.tsx", EmptyStateShowcase),
  wrap("Field", "src/components/field.tsx", FieldShowcase),
  wrap("Hover Card", "src/components/hover-card.tsx", HoverCardShowcase),
  wrap("Input", "src/components/input.tsx", InputShowcase),
  wrap("Input Group", "src/components/input-group.tsx", InputGroupShowcase),
  wrap("Input OTP", "src/components/input-otp.tsx", InputOTPShowcase),
  wrap("Item", "src/components/item.tsx", ItemShowcase),
  wrap("Kbd", "src/components/kbd.tsx", KbdShowcase),
  wrap("KPI Card", "src/components/kpi-card.tsx", KpiCardShowcase),
  wrap("Label", "src/components/label.tsx", LabelShowcase),
  wrap("Menubar", "src/components/menubar.tsx", MenubarShowcase),
  wrap("Native Select", "src/components/native-select.tsx", NativeSelectShowcase),
  wrap("Narrow Rail", "src/components/narrow-rail.tsx", NarrowRailShowcase),
  wrap("Number Input", "src/components/number-input.tsx", NumberInputShowcase),
  wrap("Pagination", "src/components/pagination.tsx", PaginationShowcase),
  wrap("Popover", "src/components/popover.tsx", PopoverShowcase),
  wrap("Progress", "src/components/progress.tsx", ProgressShowcase),
  wrap("Radio Pill", "src/components/radio-pill.tsx", RadioPillShowcase),
  wrap("Resizable", "src/components/resizable.tsx", ResizableShowcase),
  wrap("Scroll Area", "src/components/scroll-area.tsx", ScrollAreaShowcase),
  wrap("Search Input", "src/components/search-input.tsx", SearchInputShowcase),
  wrap("Select", "src/components/select.tsx", SelectShowcase),
  wrap("Separator", "src/components/separator.tsx", SeparatorShowcase),
  wrap("Settings Card", "src/components/settings-card.tsx", SettingsCardShowcase),
  wrap("Sheet", "src/components/sheet.tsx", SheetShowcase),
  wrap("Sidebar", "src/components/narrow-rail.tsx + src/components/wide-nav.tsx", SidebarShowcase),
  wrap("Skeleton", "src/components/skeleton.tsx", SkeletonShowcase),
  wrap("Slider", "src/components/slider.tsx", SliderShowcase),
  wrap("Sonner", "src/components/sonner.tsx", SonnerShowcase),
  wrap("Spinner", "src/components/spinner.tsx", SpinnerShowcase),
  wrap("Sub Nav", "src/components/sub-nav.tsx", SubNavShowcase),
  wrap("Switch", "src/components/switch.tsx", SwitchShowcase),
  wrap("Table", "src/components/table.tsx", TableShowcase),
  wrap("Table Skeleton", "src/components/table-skeleton.tsx", TableSkeletonShowcase),
  wrap("Tabs", "src/components/tabs.tsx", TabsShowcase),
  wrap("Tag Input", "src/components/tag-input.tsx", TagInputShowcase),
  wrap("Textarea", "src/components/textarea.tsx", TextareaShowcase),
  wrap("Toggle", "src/components/toggle.tsx", ToggleShowcase),
  wrap("Toggle Chip", "src/components/toggle-chip.tsx", ToggleChipShowcase),
  wrap("Toggle Group", "src/components/toggle-group.tsx", ToggleGroupShowcase),
  wrap("Tooltip", "src/components/tooltip.tsx", TooltipShowcase),
  wrap("Top Page Bar", "src/components/top-page-bar.tsx", TopPageBarShowcase),
  wrap("Typography", "src/components/typography.tsx", TypographyComponentShowcase),
  wrap("Wide Nav", "src/components/wide-nav.tsx", WideNavShowcase),
]

// 展平后的全部组件（含 Chart 下的分支子项），用于卡片渲染与计数
const allCatalogItems = flattenCatalog(catalogItems)

const EXPECTED_CATALOG_ITEMS = 72

if (allCatalogItems.length !== EXPECTED_CATALOG_ITEMS) {
  throw new Error(
    `Expected ${EXPECTED_CATALOG_ITEMS} catalog items, received ${allCatalogItems.length}`
  )
}

// ─── Demo pages 跳转 ──────────────────────────────────────────────────────────

const DEMO_PAGES: Array<{ hash: string; label: string }> = [
  { hash: "general-settings", label: "通用设置" },
  { hash: "login-setting", label: "登录设置" },
  { hash: "app-center", label: "应用中心" },
  { hash: "sessions", label: "在线设备" },
  { hash: "members", label: "成员" },
  { hash: "roles", label: "角色" },
  { hash: "operations-log", label: "操作日志" },
  { hash: "login-log", label: "登录日志" },
  { hash: "dashboard", label: "Dashboard" },
]

// ─── Catalog page primitives ──────────────────────────────────────────────────

function CatalogCard({ item }: { item: CatalogItem }) {
  return <>{item.showcase()}</>
}

function DirectoryLink({ name }: { name: string }) {
  return (
    <a
      href={`#${toAnchorId(name)}`}
      className={cn(
        "block rounded-[var(--corner-md)] border border-transparent px-[var(--space-3)] py-[var(--space-2)] text-[13px] text-muted-foreground transition-colors",
        "hover:border-border hover:bg-secondary hover:text-foreground"
      )}
    >
      <span className="truncate">{name}</span>
    </a>
  )
}

function DirectoryItem({ item }: { item: CatalogItem }) {
  if (!item.children?.length) {
    return <DirectoryLink name={item.name} />
  }
  // 父项 + 缩进分支：子项以左侧分隔线缩进展示于父项之下
  return (
    <div className="grid gap-[var(--space-1)]">
      <DirectoryLink name={item.name} />
      <div className="ml-[var(--space-3)] grid gap-[var(--space-1)] border-l border-border pl-[var(--space-2)]">
        {item.children.map((child) => (
          <DirectoryLink key={child.name} name={child.name} />
        ))}
      </div>
    </div>
  )
}

// ─── CatalogView ──────────────────────────────────────────────────────────────

function CatalogView() {
  return (
    <>
      <Toaster />
      <div className="min-h-screen bg-background text-foreground">
        <main className="mx-auto max-w-[1480px] px-[var(--space-5)] py-[56px] md:px-[48px] xl:px-[72px]">
          <div className="flex flex-col items-start justify-between gap-[var(--space-5)] xl:flex-row xl:items-start">
            <div>
              <h1 className="text-2xl font-semibold tracking-tight">百融 UI 设计规范</h1>
              <p className="mt-1 text-sm text-muted-foreground">
                {`${allCatalogItems.length} 个本地组件 + 基础 token 规范。下方可切换"组件库"与"基础规范"两个视图。`}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                aria-label="Copy page URL"
                size="icon-sm"
                variant="outline"
                onClick={() => {
                  window.navigator.clipboard.writeText(window.location.href)
                  showSuccessToast("已复制当前页面链接")
                }}
              >
                <Copy />
              </Button>
            </div>
          </div>

          {/* Demo Pages */}
          <section className="mt-[var(--space-6)] rounded-[var(--corner-lg)] border border-border bg-card px-[var(--space-5)] py-[var(--space-4)]">
            <div className="flex items-baseline gap-[var(--space-3)]">
              <p className="text-[13px] font-semibold text-foreground">完整页面 Demo</p>
              <p className="text-[12px] text-muted-foreground">
                点击跳转到对应业务页，验证组件在真实页面中的组合效果
              </p>
            </div>
            <div className="mt-[var(--space-3)] flex flex-wrap gap-[var(--space-2)]">
              {DEMO_PAGES.map((p) => (
                <Button
                  key={p.hash}
                  variant="outline"
                  size="sm"
                  onClick={() => { window.location.hash = p.hash }}
                >
                  {p.label}
                  <ArrowRight />
                </Button>
              ))}
            </div>
          </section>

          {/* 组件库 / 基础规范 切换 — 默认 components，组件库优先 */}
          <Tabs defaultValue="components" className="mt-[var(--space-8)]">
            <TabsList>
              <TabsTrigger value="components">组件库 · {allCatalogItems.length}</TabsTrigger>
              <TabsTrigger value="foundations">基础规范</TabsTrigger>
            </TabsList>

            <TabsContent
              value="components"
              className="mt-[var(--space-6)] grid gap-[var(--space-6)] md:grid-cols-[300px_minmax(0,1fr)]"
            >
              <aside className="md:sticky md:top-6 md:self-start">
                <div className="rounded-[var(--corner-lg)] border border-border bg-card p-[var(--space-5)]">
                  <div className="flex items-start justify-between gap-[var(--space-3)]">
                    <div>
                      <h2 className="text-[16px] font-semibold tracking-tight text-foreground">目录</h2>
                      <p className="mt-[var(--space-2)] text-[13px] leading-6 text-muted-foreground">
                        点击组件名称直接定位到对应卡片。
                      </p>
                    </div>
                    <Badge size="sm" variant="default">{allCatalogItems.length}</Badge>
                  </div>
                  <div className="mt-[var(--space-4)] grid gap-[var(--space-1)] md:max-h-[75vh] md:overflow-y-auto md:pr-[var(--space-1)]">
                    {catalogItems.map((item) => (
                      <DirectoryItem key={item.name} item={item} />
                    ))}
                  </div>
                </div>
              </aside>

              <div className="grid gap-[var(--space-6)] xl:grid-cols-2">
                {allCatalogItems.map((item) => (
                  <CatalogCard key={item.name} item={item} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="foundations" className="mt-[var(--space-6)]">
              <Foundations />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </>
  )
}

// ─── Router ───────────────────────────────────────────────────────────────────

// 「系统管理」侧导航中尚未实现的 6 个模块 → 渲染占位页
const UNDER_DEV_ROUTES = [
  "idp",
  "departments",
  "user-groups",
  "permissions",
  "permission-policy",
  "notification-template",
]

function getRoute() {
  if (typeof window === "undefined") return "catalog"
  const hash = window.location.hash.replace(/^#/, "")
  if (hash === "login-setting") return "login-setting"
  if (hash === "app-center") return "app-center"
  if (hash === "sessions") return "sessions"
  if (hash === "members") return "members"
  if (hash === "roles") return "roles"
  if (hash === "operations-log") return "operations-log"
  if (hash === "login-log") return "login-log"
  if (hash === "general-settings") return "general-settings"
  if (hash === "dashboard") return "dashboard"
  if (UNDER_DEV_ROUTES.includes(hash)) return hash
  return "catalog"
}

function App() {
  const [route, setRoute] = React.useState(getRoute)

  React.useEffect(() => {
    const handler = () => setRoute(getRoute())
    window.addEventListener("hashchange", handler)
    return () => window.removeEventListener("hashchange", handler)
  }, [])

  if (route === "login-setting") return <LoginSettingPage />
  if (route === "app-center") return <AppCenterPage />
  if (route === "sessions") return <SessionManagementPage />
  if (route === "members") return <MembersPage />
  if (route === "roles") return <RolesPage />
  if (route === "operations-log") return <OperationsLogPage />
  if (route === "login-log") return <LoginLogPage />
  if (route === "general-settings") return <GeneralSettingsPage />
  if (route === "dashboard") return <DashboardPage />
  if (UNDER_DEV_ROUTES.includes(route)) return <UnderDevelopmentPage activeKey={route} />
  return <CatalogView />
}

export default App
