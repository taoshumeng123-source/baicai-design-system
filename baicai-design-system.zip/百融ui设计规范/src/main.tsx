import React from "react"
import ReactDOM from "react-dom/client"
import "./styles/globals.css"

function renderFatalError(error: unknown) {
  const root = document.getElementById("root")
  if (!root) return

  const message =
    error instanceof Error
      ? `${error.name}: ${error.message}\n\n${error.stack ?? ""}`
      : String(error)

  root.innerHTML = `
    <div style="padding:24px;font-family:var(--font-sans-base, 'PingFang SC', sans-serif);color:#171717;">
      <div style="max-width:960px;margin:0 auto;border:1px solid #e1e1e1;border-radius:16px;background:#fff;padding:20px 24px;white-space:pre-wrap;line-height:1.6;">
        <strong style="display:block;margin-bottom:12px;">Runtime error</strong>
        ${message.replace(/[&<>]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[char] ?? char))}
      </div>
    </div>
  `
}

class RootErrorBoundary extends React.Component<
  React.PropsWithChildren,
  { error: Error | null }
> {
  constructor(props: React.PropsWithChildren) {
    super(props)
    this.state = { error: null }
  }

  static getDerivedStateFromError(error: Error) {
    return { error }
  }

  componentDidCatch(error: Error) {
    console.error(error)
  }

  render() {
    if (this.state.error) {
      return (
        <div style={{ padding: 24 }}>
          <div
            style={{
              maxWidth: 960,
              margin: "0 auto",
              border: "1px solid #e1e1e1",
              borderRadius: 16,
              background: "#fff",
              padding: "20px 24px",
              whiteSpace: "pre-wrap",
              lineHeight: 1.6,
              color: "#171717",
            }}
          >
            <strong style={{ display: "block", marginBottom: 12 }}>
              React render error
            </strong>
            {this.state.error.name}: {this.state.error.message}
            {"\n\n"}
            {this.state.error.stack}
          </div>
        </div>
      )
    }

    return this.props.children
  }
}

window.addEventListener("error", (event) => {
  renderFatalError(event.error ?? event.message)
})

window.addEventListener("unhandledrejection", (event) => {
  renderFatalError(event.reason)
})

async function boot() {
  try {
    const { default: App } = await import("./App")

    ReactDOM.createRoot(document.getElementById("root")!).render(
      <React.StrictMode>
        <RootErrorBoundary>
          <App />
        </RootErrorBoundary>
      </React.StrictMode>
    )
  } catch (error) {
    renderFatalError(error)
  }
}

void boot()
