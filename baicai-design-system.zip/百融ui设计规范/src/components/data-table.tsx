import * as React from "react"
import {
  ArrowLeft,
  ArrowRight,
  GripVertical,
  MoreHorizontal,
  Plus,
  Trash2,
} from "lucide-react"

import { Button } from "@/components/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/dropdown-menu"
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyIllustration,
  EmptyTitle,
} from "@/components/empty"
import { cn } from "@/lib/utils"

export interface DataTableColumn<T> {
  key: string
  label: string
  width: number
  align?: "left" | "center" | "right"
  render: (row: T) => React.ReactNode
  headerClassName?: string
  cellClassName?: string
}

export interface DataTableModule<T> {
  key: string
  label: string
  description?: string
  columns: DataTableColumn<T>[]
  defaultVisible?: boolean
  tint?: "blue" | "emerald" | "amber" | "violet"
}

interface DataTableProps<T> {
  rows: T[]
  getRowId: (row: T) => string
  leftColumns: DataTableColumn<T>[]
  modules: DataTableModule<T>[]
  rightColumns: DataTableColumn<T>[]
  emptyText?: string
  className?: string
  getRowClassName?: (row: T, index: number) => string | undefined
}

const ACTION_COLUMN_WIDTH = 40
const HEADER_CELL_CLASSNAME =
  "h-10 border-b border-r border-border bg-card px-[var(--space-3)] text-left align-middle text-[12px] font-medium leading-[16px] text-foreground"
const BODY_CELL_CLASSNAME =
  "h-10 border-b border-r border-border bg-card px-[var(--space-3)] py-[var(--space-2)] align-middle text-[12px] leading-[16px] text-foreground"
const LEFT_STICKY_EDGE_CLASSNAME =
  "shadow-[8px_0_14px_-14px_var(--foreground)]"
const RIGHT_STICKY_EDGE_CLASSNAME =
  "shadow-[-8px_0_14px_-14px_var(--foreground)]"

function getAlignmentClass(align: DataTableColumn<unknown>["align"]) {
  if (align === "center") return "text-center"
  if (align === "right") return "text-right"
  return "text-left"
}

function getLeftOffsets<T>(columns: DataTableColumn<T>[]) {
  let offset = 0
  return columns.map((column) => {
    const current = offset
    offset += column.width
    return current
  })
}

function getRightOffsets<T>(columns: DataTableColumn<T>[]) {
  let offset = 0
  const offsets = new Array<number>(columns.length).fill(0)

  for (let index = columns.length - 1; index >= 0; index -= 1) {
    offsets[index] = offset
    offset += columns[index].width
  }

  return offsets
}

export function DataTable<T>({
  rows,
  getRowId,
  leftColumns,
  modules,
  rightColumns,
  emptyText = "暂无数据",
  className,
  getRowClassName,
}: DataTableProps<T>) {
  const [visibleModuleKeys, setVisibleModuleKeys] = React.useState<string[]>(
    () =>
      modules
        .filter((module) => module.defaultVisible !== false)
        .map((module) => module.key)
  )
  const [draggingModuleKey, setDraggingModuleKey] = React.useState<string | null>(
    null
  )

  React.useEffect(() => {
    setVisibleModuleKeys(
      modules
        .filter((module) => module.defaultVisible !== false)
        .map((module) => module.key)
    )
  }, [modules])

  const visibleModules = visibleModuleKeys
    .map((key) => modules.find((module) => module.key === key))
    .filter((module): module is DataTableModule<T> => Boolean(module))

  const hiddenModules = modules.filter(
    (module) => !visibleModuleKeys.includes(module.key)
  )
  const centerColumns = visibleModules.flatMap((module) => module.columns)

  const leftOffsets = React.useMemo(() => getLeftOffsets(leftColumns), [leftColumns])
  const rightOffsets = React.useMemo(
    () => getRightOffsets(rightColumns),
    [rightColumns]
  )

  const totalCenterWidth = centerColumns.reduce(
    (sum, column) => sum + column.width,
    0
  )

  const showActionColumn = modules.length > 0

  const addModule = (key: string) => {
    setVisibleModuleKeys((current) => {
      return current.includes(key) ? current : [...current, key]
    })
  }

  const removeModule = (key: string) => {
    setVisibleModuleKeys((current) => current.filter((item) => item !== key))
  }

  const moveModule = (fromKey: string, toKey: string) => {
    if (fromKey === toKey) return

    setVisibleModuleKeys((current) => {
      const next = [...current]
      const fromIndex = next.indexOf(fromKey)
      const toIndex = next.indexOf(toKey)

      if (fromIndex === -1 || toIndex === -1) return current

      const [moved] = next.splice(fromIndex, 1)
      next.splice(toIndex, 0, moved)
      return next
    })
  }

  const moveModuleByOffset = (key: string, offset: -1 | 1) => {
    setVisibleModuleKeys((current) => {
      const fromIndex = current.indexOf(key)
      const toIndex = fromIndex + offset

      if (fromIndex === -1 || toIndex < 0 || toIndex >= current.length) {
        return current
      }

      const next = [...current]
      const [moved] = next.splice(fromIndex, 1)
      next.splice(toIndex, 0, moved)
      return next
    })
  }

  const renderCenterHeader = (
    module: DataTableModule<T>,
    column: DataTableColumn<T>,
    moduleIndex: number,
    columnIndex: number
  ) => {
    const isFirstModule = moduleIndex === 0
    const isLastModule = moduleIndex === visibleModules.length - 1
    const isModuleLead = columnIndex === 0

    if (!isModuleLead) {
      return <span className="truncate">{column.label}</span>
    }

    return (
      <div
        role="button"
        tabIndex={0}
        draggable
        onDragStart={(event) => {
          if ((event.target as HTMLElement).closest("[data-module-action]")) {
            event.preventDefault()
            return
          }

          setDraggingModuleKey(module.key)
        }}
        onDragEnd={() => setDraggingModuleKey(null)}
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => {
          event.preventDefault()
          if (draggingModuleKey) {
            moveModule(draggingModuleKey, module.key)
          }
          setDraggingModuleKey(null)
        }}
        className={cn(
          "group/module flex cursor-grab items-center justify-between gap-[var(--space-2)] active:cursor-grabbing",
          draggingModuleKey === module.key && "opacity-60"
        )}
      >
        <div className="flex min-w-0 items-center gap-[var(--space-2)]">
          <GripVertical className="size-3 text-muted-foreground opacity-60 transition-opacity group-hover/module:opacity-100" />
          <span
            className="truncate text-[12px] font-medium text-foreground"
          >
            {column.label}
          </span>
        </div>

        <div className="-mr-1 flex shrink-0 items-center gap-[2px]">
          <Button
            type="button"
            variant="ghost"
            size="icon-xs"
            className="size-6 opacity-70 transition-opacity group-hover/module:opacity-100"
            aria-label={`前移${module.label}字段组`}
            data-module-action
            draggable={false}
            disabled={isFirstModule}
            onClick={() => moveModuleByOffset(module.key, -1)}
          >
            <ArrowLeft data-icon="inline-start" />
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon-xs"
            className="size-6 opacity-70 transition-opacity group-hover/module:opacity-100"
            aria-label={`后移${module.label}字段组`}
            data-module-action
            draggable={false}
            disabled={isLastModule}
            onClick={() => moveModuleByOffset(module.key, 1)}
          >
            <ArrowRight data-icon="inline-start" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                size="icon-xs"
                className="size-6 opacity-70 transition-opacity group-hover/module:opacity-100 data-[state=open]:opacity-100"
                aria-label={`调整${module.label}字段组`}
                data-module-action
                draggable={false}
              >
                <MoreHorizontal data-icon="inline-start" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuLabel>{module.label}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                disabled={isFirstModule}
                onClick={() => moveModuleByOffset(module.key, -1)}
              >
                <ArrowLeft data-icon="inline-start" />
                前移一组
              </DropdownMenuItem>
              <DropdownMenuItem
                disabled={isLastModule}
                onClick={() => moveModuleByOffset(module.key, 1)}
              >
                <ArrowRight data-icon="inline-start" />
                后移一组
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="text-destructive focus:bg-destructive-soft focus:text-destructive"
                onClick={() => removeModule(module.key)}
              >
                <Trash2 data-icon="inline-start" />
                删除字段组
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    )
  }

  return (
    <div
      className={cn(
        "flex h-full w-full overflow-hidden rounded-[var(--corner-md)] border border-border bg-card",
        className
      )}
    >
      <div className="min-h-0 flex-1 overflow-auto bg-card">
        <table
          className="w-full border-separate border-spacing-0 text-sm"
          style={{
            minWidth:
              leftColumns.reduce((sum, column) => sum + column.width, 0) +
              Math.max(totalCenterWidth, 240) +
              rightColumns.reduce((sum, column) => sum + column.width, 0) +
              (showActionColumn ? ACTION_COLUMN_WIDTH : 0),
          }}
        >
          <thead>
            <tr>
              {leftColumns.map((column, index) => (
                <th
                  key={column.key}
                  className={cn(
                    "sticky top-0 z-30",
                    HEADER_CELL_CLASSNAME,
                    getAlignmentClass(column.align),
                    index === leftColumns.length - 1 && LEFT_STICKY_EDGE_CLASSNAME,
                    column.headerClassName
                  )}
                  style={{
                    left: leftOffsets[index],
                    width: column.width,
                    minWidth: column.width,
                    maxWidth: column.width,
                  }}
                >
                  {column.label}
                </th>
              ))}

              {visibleModules.map((module, moduleIndex) =>
                module.columns.map((column, columnIndex) => (
                  <th
                    key={column.key}
                    className={cn(
                      HEADER_CELL_CLASSNAME,
                      getAlignmentClass(column.align),
                      column.headerClassName
                    )}
                    style={{
                      width: column.width,
                      minWidth: column.width,
                      maxWidth: column.width,
                    }}
                  >
                    {renderCenterHeader(module, column, moduleIndex, columnIndex)}
                  </th>
                ))
              )}

              {rightColumns.map((column, index) => (
                <th
                  key={column.key}
                  className={cn(
                    "sticky top-0 z-30",
                    HEADER_CELL_CLASSNAME,
                    getAlignmentClass(column.align),
                    index === 0 && RIGHT_STICKY_EDGE_CLASSNAME,
                    column.headerClassName
                  )}
                  style={{
                    right:
                      (showActionColumn ? ACTION_COLUMN_WIDTH : 0) +
                      rightOffsets[index],
                    width: column.width,
                    minWidth: column.width,
                    maxWidth: column.width,
                  }}
                >
                  {column.label}
                </th>
              ))}

              {showActionColumn ? (
                <th
                  className={cn(
                    "sticky right-0 top-0 z-40 border-b border-border bg-secondary px-0"
                  )}
                  style={{
                    width: ACTION_COLUMN_WIDTH,
                    minWidth: ACTION_COLUMN_WIDTH,
                    maxWidth: ACTION_COLUMN_WIDTH,
                  }}
                >
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        className="h-10 w-full rounded-none"
                        aria-label="添加字段模块"
                      >
                        <Plus data-icon="inline-start" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuLabel>添加字段模块</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      {hiddenModules.length ? (
                        hiddenModules.map((module) => (
                          <DropdownMenuItem
                            key={module.key}
                            onClick={() => addModule(module.key)}
                          >
                            <Plus data-icon="inline-start" />
                            {module.label}
                          </DropdownMenuItem>
                        ))
                      ) : (
                        <DropdownMenuItem disabled>暂无可添加字段</DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </th>
              ) : null}
            </tr>
          </thead>

          <tbody>
            {rows.length ? (
              rows.map((row, rowIndex) => (
                <tr key={getRowId(row)} className="group">
                  {leftColumns.map((column, index) => (
                    <td
                      key={column.key}
                      className={cn(
                        "sticky z-20 transition-colors group-hover:bg-secondary",
                        BODY_CELL_CLASSNAME,
                        getRowClassName?.(row, rowIndex),
                        getAlignmentClass(column.align),
                        index === leftColumns.length - 1 &&
                          LEFT_STICKY_EDGE_CLASSNAME,
                        column.cellClassName
                      )}
                      style={{
                        left: leftOffsets[index],
                        width: column.width,
                        minWidth: column.width,
                        maxWidth: column.width,
                      }}
                    >
                      {column.render(row)}
                    </td>
                  ))}

                  {visibleModules.length ? (
                    visibleModules.map((module) =>
                      module.columns.map((column) => (
                        <td
                          key={column.key}
                          className={cn(
                            BODY_CELL_CLASSNAME,
                            "transition-colors group-hover:bg-secondary",
                            getRowClassName?.(row, rowIndex),
                            getAlignmentClass(column.align),
                            column.cellClassName
                          )}
                          style={{
                            width: column.width,
                            minWidth: column.width,
                            maxWidth: column.width,
                          }}
                        >
                          {column.render(row)}
                        </td>
                      ))
                    )
                  ) : (
                    <td className="border-b border-border px-[var(--space-4)] py-[var(--space-8)] text-center text-sm text-muted-foreground">
                      请选择至少一个字段模块
                    </td>
                  )}

                  {rightColumns.map((column, index) => (
                    <td
                      key={column.key}
                      className={cn(
                        "sticky z-20 transition-colors group-hover:bg-secondary",
                        BODY_CELL_CLASSNAME,
                        getRowClassName?.(row, rowIndex),
                        getAlignmentClass(column.align),
                        index === 0 && RIGHT_STICKY_EDGE_CLASSNAME,
                        column.cellClassName
                      )}
                      style={{
                        right:
                          (showActionColumn ? ACTION_COLUMN_WIDTH : 0) +
                          rightOffsets[index],
                        width: column.width,
                        minWidth: column.width,
                        maxWidth: column.width,
                      }}
                    >
                      {column.render(row)}
                    </td>
                  ))}

                  {showActionColumn ? (
                    <td
                      className={cn(
                        "sticky right-0 z-20 border-b border-border bg-card px-0 transition-colors group-hover:bg-secondary",
                        getRowClassName?.(row, rowIndex)
                      )}
                      style={{
                        width: ACTION_COLUMN_WIDTH,
                        minWidth: ACTION_COLUMN_WIDTH,
                        maxWidth: ACTION_COLUMN_WIDTH,
                      }}
                    >
                      <div className="h-10 w-full" />
                    </td>
                  ) : null}
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={
                    leftColumns.length +
                    Math.max(centerColumns.length, 1) +
                    rightColumns.length +
                    (showActionColumn ? 1 : 0)
                  }
                  className="px-[var(--space-4)] py-[var(--space-4)]"
                >
                  <div className="flex justify-center">
                    <Empty size="sm">
                      <EmptyIllustration
                        alt="暂无数据"
                        size="sm"
                        title="暂无数据"
                        variant="no-data"
                      />
                      <EmptyContent>
                        <EmptyHeader>
                          <EmptyTitle>暂无数据</EmptyTitle>
                          {emptyText !== "暂无数据" ? (
                            <EmptyDescription>{emptyText}</EmptyDescription>
                          ) : null}
                        </EmptyHeader>
                      </EmptyContent>
                    </Empty>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
