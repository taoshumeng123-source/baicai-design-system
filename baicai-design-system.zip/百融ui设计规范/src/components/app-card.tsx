import * as React from "react"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/badge"

export interface AppCardProps {
  icon: React.ReactNode
  iconBg: string
  iconColor: string
  name: string
  category: string
  description: string
  status: "active" | "enabled" | "coming_soon"
  className?: string
}

const STATUS_CONFIG = {
  active: { label: "已上线", variant: "info" as const, className: "" },
  enabled: { label: "已开通", variant: "success" as const, className: "" },
  coming_soon: { label: "即将上线", variant: "secondary" as const, className: "text-muted-foreground" },
}

export function AppCard({
  icon,
  iconBg,
  iconColor,
  name,
  category,
  description,
  status,
  className,
}: AppCardProps) {
  const { label, variant, className: badgeClassName } = STATUS_CONFIG[status]
  const isActive = status === "active" || status === "enabled"

  return (
    <div
      className={cn(
        "flex flex-col rounded-[var(--corner-lg)] border border-border bg-card p-[var(--space-5)] transition-shadow duration-150",
        isActive && "cursor-pointer hover:shadow-[var(--shadow-card-hover)]",
        className
      )}
    >
      <div className="flex items-start justify-between">
        <div
          className={cn(
            "flex size-[40px] items-center justify-center rounded-[var(--corner-md)]",
            isActive ? iconBg : "bg-secondary"
          )}
        >
          <span className={isActive ? iconColor : "text-muted-foreground"}>{icon}</span>
        </div>
        <Badge variant={variant} size="sm" className={badgeClassName}>
          {label}
        </Badge>
      </div>

      <p className="mt-[var(--space-4)] text-[16px] font-semibold leading-snug text-foreground">
        {name}
      </p>

      <p className="mt-[var(--space-2)] text-[13px] leading-[20px] text-muted-foreground">
        {category}，{description}
      </p>
    </div>
  )
}
