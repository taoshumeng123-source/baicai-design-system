import * as React from "react"

import { cn } from "@/lib/utils"

export interface NumberInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  unit?: string
  unitWidth?: string
}

const NumberInput = React.forwardRef<HTMLInputElement, NumberInputProps>(
  ({ className, unit, unitWidth = "w-[40px]", ...props }, ref) => {
    return (
      <div
        className={cn(
          "flex h-[var(--control-height-xs)] w-fit items-center overflow-clip rounded-[var(--corner-sm)] border border-input bg-card transition-colors focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/10",
          className
        )}
      >
        <input
          ref={ref}
          type="number"
          className="h-full w-[52px] border-0 bg-transparent px-0 text-center text-[13px] text-foreground outline-none [appearance:textfield] placeholder:text-muted-foreground [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
          {...props}
        />
        {unit && (
          <span
            className={cn(
              "flex h-full shrink-0 items-center justify-center border-l border-input bg-background px-[var(--space-2)] text-[12px] leading-[17px] text-muted-foreground whitespace-nowrap",
              unitWidth
            )}
          >
            {unit}
          </span>
        )}
      </div>
    )
  }
)
NumberInput.displayName = "NumberInput"

export { NumberInput }
