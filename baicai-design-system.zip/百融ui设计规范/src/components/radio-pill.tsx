import * as React from "react"
import { cn } from "@/lib/utils"

export interface RadioPillProps {
  active: boolean
  label: string
  onSelect: () => void
  disabled?: boolean
  className?: string
}

const RadioPill = React.forwardRef<HTMLButtonElement, RadioPillProps>(
  ({ active, label, onSelect, disabled, className }, ref) => (
    <button
      ref={ref}
      type="button"
      onClick={onSelect}
      aria-pressed={active}
      disabled={disabled}
      className={cn(
        "group inline-flex items-center gap-[8px] text-[13px] font-normal text-foreground transition-colors select-none",
        disabled && "cursor-not-allowed opacity-45",
        className
      )}
    >
      <span
        className={cn(
          "inline-flex size-[16px] shrink-0 rounded-full bg-card transition-all",
          active
            ? "border-[4px] border-primary"
            : "border-[1.5px] border-[#cecece] group-hover:border-primary"
        )}
      />
      {label}
    </button>
  )
)
RadioPill.displayName = "RadioPill"

export { RadioPill }
