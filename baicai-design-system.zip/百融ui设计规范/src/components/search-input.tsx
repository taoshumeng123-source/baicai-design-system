"use client"

import * as React from "react"
import { Search } from "lucide-react"

import { cn } from "../lib/utils"
import { Input } from "./input"

interface SearchInputProps
  extends Omit<React.ComponentProps<"input">, "onChange"> {
  onSearch?: (value: string) => void
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void
}

const SearchInput = React.forwardRef<HTMLInputElement, SearchInputProps>(
  ({ className, onSearch, onChange, ...props }, ref) => {
    const timeoutRef = React.useRef<ReturnType<typeof setTimeout>>(null)

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      onChange?.(e)
      if (onSearch) {
        if (timeoutRef.current) clearTimeout(timeoutRef.current)
        const value = e.target.value
        timeoutRef.current = setTimeout(() => onSearch(value), 300)
      }
    }

    React.useEffect(() => {
      return () => {
        if (timeoutRef.current) clearTimeout(timeoutRef.current)
      }
    }, [])

    return (
      <div className={cn("relative", className)}>
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          ref={ref}
          className="pl-9"
          onChange={handleChange}
          {...props}
        />
      </div>
    )
  }
)
SearchInput.displayName = "SearchInput"

export { SearchInput }
export type { SearchInputProps }
