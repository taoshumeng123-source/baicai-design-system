"use client"

import * as React from "react"
import {
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock3,
} from "lucide-react"

import { Button } from "@/components/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/popover"
import { ScrollArea } from "@/components/scroll-area"
import { cn } from "@/lib/utils"

type DateRange = {
  from?: Date
  to?: Date
}

function startOfDay(date: Date) {
  const next = new Date(date)
  next.setHours(0, 0, 0, 0)
  return next
}

function sameDay(left?: Date, right?: Date) {
  if (!left || !right) return false
  return startOfDay(left).getTime() === startOfDay(right).getTime()
}

function inRange(day: Date, range?: DateRange) {
  if (!range?.from || !range?.to) return false
  const value = startOfDay(day).getTime()
  return (
    value > startOfDay(range.from).getTime() &&
    value < startOfDay(range.to).getTime()
  )
}

function buildMonthGrid(month: Date) {
  const first = new Date(month.getFullYear(), month.getMonth(), 1)
  const offset = (first.getDay() + 6) % 7
  const start = new Date(month.getFullYear(), month.getMonth(), 1 - offset)

  return Array.from({ length: 42 }, (_, index) => {
    const day = new Date(start)
    day.setDate(start.getDate() + index)
    return day
  })
}

function monthLabel(date: Date) {
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "long",
  }).format(date)
}

function fullDateLabel(date: Date) {
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date)
}

function shortDateLabel(date?: Date) {
  if (!date) return ""
  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit",
    day: "2-digit",
  }).format(date)
}

const weekdays = ["一", "二", "三", "四", "五", "六", "日"] as const

function CalendarGrid({
  month,
  selected,
  range,
  onSelect,
}: {
  month: Date
  selected?: Date
  range?: DateRange
  onSelect: (day: Date) => void
}) {
  const days = React.useMemo(() => buildMonthGrid(month), [month])

  return (
    <div className="space-y-[var(--space-3)]">
      <div className="grid grid-cols-7 gap-[var(--space-1)] text-center text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
        {weekdays.map((day) => (
          <span key={day} className="py-[var(--space-1)]">
            {day}
          </span>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-[var(--space-1)]">
        {days.map((day) => {
          const isCurrentMonth = day.getMonth() === month.getMonth()
          const isSelected = sameDay(day, selected)
          const isRangeStart = sameDay(day, range?.from)
          const isRangeEnd = sameDay(day, range?.to)
          const isInsideRange = inRange(day, range)

          return (
            <button
              key={day.toISOString()}
              type="button"
              onClick={() => onSelect(day)}
              className={cn(
                "flex h-10 items-center justify-center rounded-md text-sm transition-colors",
                isCurrentMonth
                  ? "text-foreground hover:bg-primary-soft"
                  : "text-muted-foreground/50",
                (isSelected || isRangeStart || isRangeEnd) &&
                  "bg-primary text-primary-foreground hover:bg-primary",
                isInsideRange &&
                  "rounded-md bg-primary-soft text-primary-emphasis hover:bg-primary-soft-hover"
              )}
            >
              {day.getDate()}
            </button>
          )
        })}
      </div>
    </div>
  )
}

export function DatePicker({
  value,
  onChange,
  placeholder = "选择日期",
}: {
  value?: Date
  onChange: (value?: Date) => void
  placeholder?: string
}) {
  const [open, setOpen] = React.useState(false)
  const [month, setMonth] = React.useState(value ?? new Date())

  React.useEffect(() => {
    if (value) setMonth(value)
  }, [value])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "w-full justify-start px-[var(--space-4)]",
            !value && "text-muted-foreground"
          )}
        >
          <CalendarDays data-icon="inline-start" />
          {value ? fullDateLabel(value) : placeholder}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[336px] p-[var(--space-4)]">
        <div className="space-y-[var(--space-4)]">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={() =>
                setMonth(
                  (current) => new Date(current.getFullYear(), current.getMonth() - 1, 1)
                )
              }
            >
              <ChevronLeft />
            </Button>
            <p className="text-sm font-semibold text-foreground">
              {monthLabel(month)}
            </p>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={() =>
                setMonth(
                  (current) => new Date(current.getFullYear(), current.getMonth() + 1, 1)
                )
              }
            >
              <ChevronRight />
            </Button>
          </div>

          <CalendarGrid
            month={month}
            selected={value}
            onSelect={(day) => {
              onChange(day)
              setOpen(false)
            }}
          />
        </div>
      </PopoverContent>
    </Popover>
  )
}

export function DateRangePicker({
  value,
  onChange,
}: {
  value: DateRange
  onChange: (value: DateRange) => void
}) {
  const [open, setOpen] = React.useState(false)
  const [month, setMonth] = React.useState(value.from ?? new Date())

  const label =
    value.from && value.to
      ? `${shortDateLabel(value.from)} - ${shortDateLabel(value.to)}`
      : value.from
        ? `${shortDateLabel(value.from)} - 结束日期`
        : "选择日期范围"

  const handleSelect = (day: Date) => {
    if (!value.from || (value.from && value.to)) {
      onChange({ from: day, to: undefined })
      return
    }

    if (startOfDay(day).getTime() < startOfDay(value.from).getTime()) {
      onChange({ from: day, to: value.from })
      setOpen(false)
      return
    }

    onChange({ from: value.from, to: day })
    setOpen(false)
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "w-full justify-start px-[var(--space-4)]",
            !value.from && "text-muted-foreground"
          )}
        >
          <CalendarDays data-icon="inline-start" />
          {label}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[372px] p-[var(--space-4)]">
        <div className="space-y-[var(--space-4)]">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={() =>
                setMonth(
                  (current) => new Date(current.getFullYear(), current.getMonth() - 1, 1)
                )
              }
            >
              <ChevronLeft />
            </Button>
            <div className="text-center">
              <p className="text-sm font-semibold text-foreground">
                {monthLabel(month)}
              </p>
              <p className="text-xs text-muted-foreground">
                {value.from
                  ? value.to
                    ? `${fullDateLabel(value.from)} 至 ${fullDateLabel(value.to)}`
                    : "请选择结束日期"
                  : "请选择开始日期"}
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={() =>
                setMonth(
                  (current) => new Date(current.getFullYear(), current.getMonth() + 1, 1)
                )
              }
            >
              <ChevronRight />
            </Button>
          </div>

          <CalendarGrid month={month} range={value} onSelect={handleSelect} />
        </div>
      </PopoverContent>
    </Popover>
  )
}

export function TimePicker({
  value,
  onChange,
}: {
  value: string
  onChange: (value: string) => void
}) {
  const [open, setOpen] = React.useState(false)
  const [hour, minute] = value.split(":")

  const hours = Array.from({ length: 24 }, (_, index) =>
    String(index).padStart(2, "0")
  )
  const minutes = Array.from({ length: 12 }, (_, index) =>
    String(index * 5).padStart(2, "0")
  )

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" className="w-full justify-start px-[var(--space-4)]">
          <Clock3 data-icon="inline-start" />
          {value}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[260px] p-[var(--space-4)]">
        <div className="space-y-[var(--space-4)]">
          <div className="space-y-1">
            <p className="text-sm font-semibold text-foreground">选择时间</p>
            <p className="text-xs text-muted-foreground">
              以 5 分钟为颗粒度快速选择
            </p>
          </div>

          <div className="grid grid-cols-[1fr_auto_1fr] items-start gap-[var(--space-3)]">
            <ScrollArea className="h-52 rounded-xl bg-secondary">
              <div className="space-y-[var(--space-1)] p-[var(--space-2)]">
                {hours.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => onChange(`${item}:${minute ?? "00"}`)}
                    className={cn(
                      "flex w-full items-center justify-between rounded-lg px-[var(--space-3)] py-[var(--space-2)] text-sm transition-colors",
                      item === hour
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-primary-soft"
                    )}
                  >
                    <span>{item}</span>
                    {item === hour ? <Check className="size-4" /> : null}
                  </button>
                ))}
              </div>
            </ScrollArea>

            <div className="pt-[84px] text-lg font-semibold text-muted-foreground">
              :
            </div>

            <ScrollArea className="h-52 rounded-xl bg-secondary">
              <div className="space-y-[var(--space-1)] p-[var(--space-2)]">
                {minutes.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => onChange(`${hour ?? "09"}:${item}`)}
                    className={cn(
                      "flex w-full items-center justify-between rounded-lg px-[var(--space-3)] py-[var(--space-2)] text-sm transition-colors",
                      item === minute
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-primary-soft"
                    )}
                  >
                    <span>{item}</span>
                    {item === minute ? <Check className="size-4" /> : null}
                  </button>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )
}

export type { DateRange }
