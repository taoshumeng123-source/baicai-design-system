import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

type EmptySize = "default" | "sm"
type EmptyVariant =
  | "no-data"
  | "no-content"
  | "no-result"
  | "no-permission"
  | "network-error"

const EmptyContext = React.createContext<{ size: EmptySize }>({
  size: "default",
})

const EMPTY_IMAGE_MAP: Record<EmptyVariant, string> = {
  "no-data": `${import.meta.env.BASE_URL}empty-state/no-data.png`,
  "no-content": `${import.meta.env.BASE_URL}empty-state/no-content.png`,
  "no-result": `${import.meta.env.BASE_URL}empty-state/no-result.png`,
  "no-permission": `${import.meta.env.BASE_URL}empty-state/no-permission.png`,
  "network-error": `${import.meta.env.BASE_URL}empty-state/network-error.png`,
}

function inferEmptyVariant(title?: string, description?: string): EmptyVariant {
  const text = `${title ?? ""} ${description ?? ""}`

  if (/网络|异常|错误|失败/.test(text)) return "network-error"
  if (/权限|禁止|不可访问/.test(text)) return "no-permission"
  if (/结果|搜索|筛选|未命中/.test(text)) return "no-result"
  if (/内容|开发中|即将上线|建设中|功能即将上线/.test(text)) return "no-content"
  return "no-data"
}

function getEmptyStateImageSrc(
  variant?: EmptyVariant,
  title?: string,
  description?: string
) {
  return EMPTY_IMAGE_MAP[variant ?? inferEmptyVariant(title, description)]
}

const emptyVariants = cva(
  "flex min-w-0 flex-col items-center justify-center gap-[12px] p-[20px] text-center",
  {
    variants: {
      size: {
        default: "",
        sm: "",
      },
    },
    defaultVariants: {
      size: "default",
    },
  }
)

function Empty({
  className,
  size = "default",
  ...props
}: React.ComponentProps<"div"> & { size?: EmptySize }) {
  return (
    <EmptyContext.Provider value={{ size }}>
      <div
        data-slot="empty"
        data-size={size}
        className={cn(emptyVariants({ size, className }))}
        {...props}
      />
    </EmptyContext.Provider>
  )
}

function EmptyHeader({ className, ...props }: React.ComponentProps<"div">) {
  const { size } = React.useContext(EmptyContext)

  return (
    <div
      data-slot="empty-header"
      data-size={size}
      className={cn(
        "flex flex-col items-center",
        size === "default" ? "w-[204px] gap-[4px]" : "w-[140px] gap-[4px]",
        className
      )}
      {...props}
    />
  )
}

const emptyMediaVariants = cva(
  "shrink-0 [&_img]:pointer-events-none [&_img]:block [&_img]:h-full [&_img]:w-full [&_img]:object-contain [&_svg]:pointer-events-none [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-transparent",
        icon: "flex items-center justify-center rounded-xl bg-primary-soft text-primary-emphasis",
        image: "overflow-hidden bg-transparent",
      },
      size: {
        default: "",
        sm: "",
      },
    },
    compoundVariants: [
      {
        variant: "icon",
        size: "default",
        className: "size-[100px] [&_svg:not([class*='size-'])]:size-10",
      },
      {
        variant: "icon",
        size: "sm",
        className: "size-[50px] [&_svg:not([class*='size-'])]:size-6",
      },
      {
        variant: "image",
        size: "default",
        className: "size-[100px]",
      },
      {
        variant: "image",
        size: "sm",
        className: "size-[50px]",
      },
      {
        variant: "default",
        size: "default",
        className: "size-[100px]",
      },
      {
        variant: "default",
        size: "sm",
        className: "size-[50px]",
      },
    ],
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

function EmptyMedia({
  className,
  variant = "default",
  size,
  ...props
}: React.ComponentProps<"div"> &
  VariantProps<typeof emptyMediaVariants>) {
  const context = React.useContext(EmptyContext)

  return (
    <div
      data-slot="empty-media"
      data-variant={variant}
      data-size={size ?? context.size}
      className={cn(
        emptyMediaVariants({
          variant,
          size: size ?? context.size,
          className,
        })
      )}
      {...props}
    />
  )
}

function EmptyTitle({ className, ...props }: React.ComponentProps<"div">) {
  const { size } = React.useContext(EmptyContext)

  return (
    <div
      data-slot="empty-title"
      data-size={size}
      className={cn(
        "w-[140px] text-center text-[16px] leading-6 tracking-normal text-foreground",
        size === "default" ? "font-medium" : "font-semibold",
        className
      )}
      {...props}
    />
  )
}

function EmptyDescription({ className, ...props }: React.ComponentProps<"div">) {
  const { size } = React.useContext(EmptyContext)

  return (
    <div
      data-slot="empty-description"
      data-size={size}
      className={cn(
        "flex w-full flex-wrap items-center justify-center gap-[4px] text-center text-[14px] font-normal leading-[22px] text-[#969696] [&>a]:text-primary [&>a]:no-underline [&>a:hover]:text-primary-hover",
        className
      )}
      {...props}
    />
  )
}

function EmptyContent({ className, ...props }: React.ComponentProps<"div">) {
  const { size } = React.useContext(EmptyContext)

  return (
    <div
      data-slot="empty-content"
      data-size={size}
      className={cn(
        "flex min-w-0 flex-col items-center",
        size === "default" ? "w-[204px] gap-[12px]" : "w-[140px] gap-[4px]",
        className
      )}
      {...props}
    />
  )
}

function EmptyActionLink({
  className,
  ...props
}: React.ComponentProps<"button">) {
  return (
    <button
      type="button"
      data-slot="empty-action-link"
      className={cn(
        "text-[14px] font-normal leading-[22px] text-primary transition-colors hover:text-primary-hover focus-visible:outline-none",
        className
      )}
      {...props}
    />
  )
}

function EmptyIllustration({
  className,
  size,
  src,
  alt,
  variant,
  title,
  description,
  ...props
}: Omit<React.ComponentProps<"img">, "src"> & {
  src?: string
  variant?: EmptyVariant
  size?: EmptySize
  title?: string
  description?: string
}) {
  const resolvedSrc = src ?? getEmptyStateImageSrc(variant, title, description)

  return (
    <EmptyMedia className={className} size={size} variant="image">
      <img
        alt={alt}
        data-slot="empty-illustration"
        src={resolvedSrc}
        {...props}
      />
    </EmptyMedia>
  )
}

export {
  Empty,
  EMPTY_IMAGE_MAP,
  inferEmptyVariant,
  getEmptyStateImageSrc,
  EmptyHeader,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
  EmptyMedia,
  EmptyActionLink,
  EmptyIllustration,
}
export type { EmptySize, EmptyVariant }
