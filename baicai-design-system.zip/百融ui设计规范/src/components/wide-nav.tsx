import * as React from "react"
import { cn } from "@/lib/utils"

// ─── NavItem ──────────────────────────────────────────────────────────────────

export interface NavItemProps {
  icon?: React.ReactNode
  children: React.ReactNode
  active?: boolean
  badge?: React.ReactNode
  onClick?: () => void
  className?: string
}

const NavItem = React.forwardRef<HTMLButtonElement, NavItemProps>(
  ({ icon, children, active, badge, onClick, className }, ref) => (
    <button
      ref={ref}
      type="button"
      aria-current={active ? "page" : undefined}
      onClick={onClick}
      className={cn(
        "flex h-[40px] w-full items-center gap-[var(--space-2)] rounded-[var(--corner-md)] px-[12px] text-[13px] font-normal transition-colors",
        active
          ? "bg-primary-soft text-primary"
          : "text-muted-foreground hover:bg-primary-soft/60 hover:text-primary",
        className
      )}
    >
      {icon && (
        <span className="flex size-[16px] shrink-0 items-center justify-center">
          {icon}
        </span>
      )}
      <span className="flex-1 truncate text-left">{children}</span>
      {badge && (
        <span className="ml-auto shrink-0 text-[11px] font-medium tabular-nums">
          {badge}
        </span>
      )}
    </button>
  )
)
NavItem.displayName = "NavItem"

// ─── NavGroup ─────────────────────────────────────────────────────────────────

export interface NavGroupProps {
  label?: string
  children: React.ReactNode
  className?: string
}

function NavGroup({ label, children, className }: NavGroupProps) {
  return (
    <div className={cn("flex flex-col gap-[var(--space-0_5)]", className)}>
      {label && (
        <p className="px-[12px] py-[var(--space-1)] text-[11px] font-medium uppercase tracking-wider text-muted-foreground/70">
          {label}
        </p>
      )}
      {children}
    </div>
  )
}

// ─── WideNavHeader ────────────────────────────────────────────────────────────

export interface WideNavHeaderProps {
  title: string
  subtitle?: string
  className?: string
}

function WideNavHeader({ title, subtitle, className }: WideNavHeaderProps) {
  return (
    <div className={cn("pl-[20px] pr-[var(--space-2)] pt-[var(--space-3)] pb-[var(--space-1)]", className)}>
      <p className="text-[14px] font-semibold text-foreground">{title}</p>
      {subtitle && (
        <p className="mt-[2px] text-[12px] text-muted-foreground">{subtitle}</p>
      )}
    </div>
  )
}

// ─── WideNav ──────────────────────────────────────────────────────────────────

export interface WideNavProps {
  header?: React.ReactNode
  children: React.ReactNode
  footer?: React.ReactNode
  className?: string
}

const WideNav = React.forwardRef<HTMLElement, WideNavProps>(
  ({ header, children, footer, className }, ref) => (
    <nav
      ref={ref}
      className={cn(
        "flex w-[240px] shrink-0 flex-col border-r border-border bg-sidebar-soft",
        className
      )}
    >
      {header && <div className="shrink-0">{header}</div>}
      <div className="flex flex-1 flex-col gap-[var(--space-4)] overflow-y-auto px-[var(--space-2)] py-[var(--space-3)]">
        {children}
      </div>
      {footer && (
        <div className="shrink-0 border-t border-border px-[var(--space-2)] py-[var(--space-3)]">
          {footer}
        </div>
      )}
    </nav>
  )
)
WideNav.displayName = "WideNav"

export { WideNav, WideNavHeader, NavGroup, NavItem }
