import * as React from "react"
import { cn } from "@/lib/utils"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/tooltip"

// ─── AppTile ──────────────────────────────────────────────────────────────────

export interface AppTileProps {
  icon: React.ReactNode
  label?: string
  active?: boolean
  onClick?: () => void
  className?: string
}

const AppTile = React.forwardRef<HTMLButtonElement, AppTileProps>(
  ({ icon, label, active, onClick, className }, ref) => {
    const button = (
      <button
        ref={ref}
        type="button"
        aria-label={label}
        aria-current={active ? "page" : undefined}
        onClick={onClick}
        className={cn(
          "flex size-[44px] shrink-0 items-center justify-center rounded-[var(--corner-md)] transition-colors",
          active
            ? "bg-sidebar-brand-bg text-primary"
            : "text-muted-foreground hover:bg-sidebar-brand-bg/60 hover:text-primary",
          className
        )}
      >
        {icon}
      </button>
    )

    if (!label) return button

    return (
      <Tooltip>
        <TooltipTrigger asChild>{button}</TooltipTrigger>
        <TooltipContent side="right" sideOffset={8}>
          {label}
        </TooltipContent>
      </Tooltip>
    )
  }
)
AppTile.displayName = "AppTile"

// ─── AdminTile ────────────────────────────────────────────────────────────────

export interface AdminTileProps {
  icon: React.ReactNode
  label?: string
  active?: boolean
  onClick?: () => void
  className?: string
}

const AdminTile = React.forwardRef<HTMLButtonElement, AdminTileProps>(
  ({ icon, label, active, onClick, className }, ref) => {
    const button = (
      <button
        ref={ref}
        type="button"
        aria-label={label}
        aria-current={active ? "page" : undefined}
        onClick={onClick}
        className={cn(
          "flex size-[44px] shrink-0 items-center justify-center rounded-[var(--corner-md)] transition-colors",
          active
            ? "bg-sidebar-brand-bg text-primary"
            : "text-muted-foreground hover:bg-sidebar-brand-bg/60 hover:text-primary",
          className
        )}
      >
        {icon}
      </button>
    )

    if (!label) return button

    return (
      <Tooltip>
        <TooltipTrigger asChild>{button}</TooltipTrigger>
        <TooltipContent side="right" sideOffset={8}>
          {label}
        </TooltipContent>
      </Tooltip>
    )
  }
)
AdminTile.displayName = "AdminTile"

// ─── NarrowRail ───────────────────────────────────────────────────────────────

export interface NarrowRailProps {
  logo?: React.ReactNode
  topItems?: React.ReactNode
  bottomItems?: React.ReactNode
  className?: string
}

const NarrowRail = React.forwardRef<HTMLElement, NarrowRailProps>(
  ({ logo, topItems, bottomItems, className }, ref) => (
    <TooltipProvider delayDuration={300}>
      <nav
        ref={ref}
        className={cn(
          "flex w-[56px] shrink-0 flex-col items-center gap-[var(--space-1)] bg-gradient-to-b from-primary-soft to-[#f3f1fe] py-[var(--space-3)]",
          className
        )}
      >
        {logo && (
          <div className="flex size-[44px] items-center justify-center">
            {logo}
          </div>
        )}

        {topItems && (
          <div className="mt-[var(--space-2)] flex flex-1 flex-col items-center gap-[var(--space-1)]">
            {topItems}
          </div>
        )}

        {bottomItems && (
          <div className="flex flex-col items-center gap-[var(--space-1)]">
            {bottomItems}
          </div>
        )}
      </nav>
    </TooltipProvider>
  )
)
NarrowRail.displayName = "NarrowRail"

export { NarrowRail, AppTile, AdminTile }
