import * as React from "react"

import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/tooltip"
import { ChartHoverBubble } from "@/components/chart-hover-bubble"

// 招聘漏斗：居中圆角条（宽度收窄成倒三角）+ 浅紫渐变（hover 品牌色渐变）+ 段内数值
// + 右侧转化率 + hover 整行浅灰底 + 可选底部「整体转化」。
// 宽度公式 0.16 起底 + 0.84*比例，保证最小段也够显示数值。自带 hover 气泡（无色点）。

export interface FunnelStage {
  key: string
  label: string
  value: number
}

export interface FunnelBarsProps {
  data: FunnelStage[]
  /** 底部「整体转化」行；值 = 末段 / 首段，由组件内部计算 */
  footer?: { label: string }
}

function FunnelBars({ data, footer }: FunnelBarsProps) {
  const max = data[0]?.value ?? 1
  return (
    <div className="flex flex-1 flex-col">
      <TooltipProvider delayDuration={100}>
        <div className="flex flex-1 flex-col justify-center gap-[var(--space-2)]">
          {data.map((stage, i) => {
            const isLast = i === data.length - 1
            // 宽度 = 0.16 起底 + 比例，收窄成倒三角；起底保证最小段仍够显示数值
            const wTop = 0.16 + 0.84 * (stage.value / max)
            // 转化率：流向下一阶段
            const conv = isLast
              ? null
              : Math.round((data[i + 1].value / stage.value) * 100)
            return (
              <Tooltip key={stage.key}>
                <TooltipTrigger asChild>
                  <div
                    className="group grid h-8 items-center rounded-[var(--corner-md)] transition-colors hover:bg-secondary/60"
                    style={{ gridTemplateColumns: "72px 1fr 56px" }}
                  >
                    <span className="truncate text-[13px] text-foreground">{stage.label}</span>
                    <div className="relative flex h-full items-center justify-center">
                      <div
                        className="absolute bottom-[2px] left-1/2 top-[2px] -translate-x-1/2 rounded-[var(--corner-xs)] bg-gradient-to-r from-[var(--primary-border)] to-[var(--primary-border)]/55 transition-colors duration-200 group-hover:from-[var(--primary)] group-hover:to-[var(--primary)]/55"
                        style={{ width: `${wTop * 100}%` }}
                      />
                      <span className="relative text-[13px] font-semibold tabular-nums text-primary-emphasis transition-colors group-hover:text-primary-foreground">
                        {stage.value.toLocaleString()}
                      </span>
                    </div>
                    <span className="text-right text-[12px] tabular-nums text-muted-foreground">
                      {conv != null ? `↓${conv}%` : ""}
                    </span>
                  </div>
                </TooltipTrigger>
                <TooltipContent
                  side="top"
                  sideOffset={6}
                  className="border-none bg-transparent p-0 shadow-none"
                >
                  <ChartHoverBubble title={stage.label} label="人数" value={stage.value} />
                </TooltipContent>
              </Tooltip>
            )
          })}
        </div>
      </TooltipProvider>

      {footer && data.length > 0 && (
        <div className="mt-[var(--space-4)] flex items-center justify-between border-t border-border pt-[var(--space-3)]">
          <span className="text-[13px] text-foreground">{footer.label}</span>
          <span className="text-[15px] font-semibold tabular-nums text-foreground">
            {((data[data.length - 1].value / data[0].value) * 100).toFixed(1)}%
          </span>
        </div>
      )}
    </div>
  )
}

export { FunnelBars }
