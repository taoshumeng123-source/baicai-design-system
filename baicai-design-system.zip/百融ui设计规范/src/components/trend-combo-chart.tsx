import * as React from "react"
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  Line,
  XAxis,
  YAxis,
} from "recharts"

import {
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/chart"

// 招聘趋势：分组柱（每柱按 color 生成竖向微弱渐变）+ 折线（右轴 %）+ 双 Y 轴。
// 复用 @/components/chart 的 ChartContainer / Tooltip / Legend。
// hover 游标为覆盖整组的全高浅灰渐变面块（TrendCursor），而非竖线。

// hover 游标：覆盖整组的全高浅色渐变面块
// ComposedChart 含折线时 recharts 走线游标（传 points，不传 width），故从 points 构造矩形
function TrendCursor(props: {
  x?: number
  y?: number
  width?: number
  height?: number
  points?: { x: number; y: number }[]
  count?: number
  fill?: string
}) {
  const { width, height, points, count = 6, fill } = props
  // 柱游标：直接给了 x/y/width/height
  if (typeof width === "number" && width > 0 && typeof props.x === "number") {
    return <rect x={props.x} y={props.y} width={width} height={height} rx={6} fill={fill} />
  }
  // 线游标：从竖线 points 构造整组宽 + 全高的矩形
  if (points && points.length >= 2) {
    const cx = points[0].x
    const top = Math.min(points[0].y, points[1].y)
    const h = Math.abs(points[1].y - points[0].y) || height || 0
    const plotW = typeof width === "number" ? width : 0
    const bandW = plotW && count ? (plotW / count) * 0.82 : 96
    return <rect x={cx - bandW / 2} y={top} width={bandW} height={h} rx={6} fill={fill} />
  }
  return null
}

export interface TrendBar {
  key: string
  label: string
  color: string
  /** 竖向渐变上下端不透明度，默认 { from: 1, to: 0.55 } */
  gradient?: { from?: number; to?: number }
}

export interface TrendLine {
  key: string
  label: string
  color: string
}

export interface TrendComboChartProps {
  data: Record<string, number | string>[]
  bars: TrendBar[]
  line: TrendLine
  xKey: string
  /** 右轴（折线 %）取值域，默认 [0, 100] */
  rightDomain?: [number, number]
  /** 右轴刻度 */
  rightTicks?: number[]
  className?: string
}

function TrendComboChart({
  data,
  bars,
  line,
  xKey,
  rightDomain = [0, 100],
  rightTicks,
  className = "h-[260px] w-full",
}: TrendComboChartProps) {
  const uid = React.useId().replace(/:/g, "")
  const cursorId = `tcc-cursor-${uid}`
  const barGradId = (key: string) => `tcc-${key}-${uid}`

  const config = React.useMemo<ChartConfig>(() => {
    const c: ChartConfig = {}
    for (const b of bars) c[b.key] = { label: b.label, color: b.color }
    c[line.key] = { label: line.label, color: line.color }
    return c
  }, [bars, line])

  return (
    <ChartContainer config={config} className={className}>
      <ComposedChart data={data} margin={{ top: 8, right: 4, left: 0, bottom: 0 }} accessibilityLayer>
        <defs>
          {bars.map((b) => (
            <linearGradient key={b.key} id={barGradId(b.key)} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor={`var(--color-${b.key})`} stopOpacity={b.gradient?.from ?? 1} />
              <stop offset="100%" stopColor={`var(--color-${b.key})`} stopOpacity={b.gradient?.to ?? 0.55} />
            </linearGradient>
          ))}
          <linearGradient id={cursorId} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="var(--muted-foreground)" stopOpacity={0.02} />
            <stop offset="100%" stopColor="var(--muted-foreground)" stopOpacity={0.1} />
          </linearGradient>
        </defs>
        <CartesianGrid vertical={false} strokeDasharray="3 3" />
        <XAxis dataKey={xKey} axisLine={false} tickLine={false} tickMargin={10} />
        <YAxis yAxisId="left" axisLine={false} tickLine={false} width={40} tickCount={6} />
        <YAxis
          yAxisId="right"
          orientation="right"
          axisLine={false}
          tickLine={false}
          width={40}
          domain={rightDomain}
          ticks={rightTicks}
          tickFormatter={(v) => `${v}%`}
        />
        <ChartTooltip
          content={<ChartTooltipContent />}
          cursor={<TrendCursor count={data.length} fill={`url(#${cursorId})`} />}
        />
        <ChartLegend content={<ChartLegendContent verticalAlign="top" />} verticalAlign="top" />
        {bars.map((b) => (
          <Bar
            key={b.key}
            yAxisId="left"
            dataKey={b.key}
            fill={`url(#${barGradId(b.key)})`}
            radius={[3, 3, 0, 0]}
            maxBarSize={22}
          />
        ))}
        <Line
          yAxisId="right"
          dataKey={line.key}
          type="monotone"
          stroke={`var(--color-${line.key})`}
          strokeWidth={2}
          dot={{ r: 3, fill: `var(--color-${line.key})`, strokeWidth: 0 }}
          activeDot={{ r: 4 }}
        />
      </ComposedChart>
    </ChartContainer>
  )
}

export { TrendComboChart }
