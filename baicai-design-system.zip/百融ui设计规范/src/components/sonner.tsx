"use client"

import * as React from "react"
import { X } from "lucide-react"
import {
  Toaster as Sonner,
  toast,
  type ExternalToast,
  type ToasterProps,
} from "sonner"

import { cn } from "@/lib/utils"

type AppToastOptions = Omit<ExternalToast, "closeButton" | "duration">

const toastClassNames = {
  toast:
    "group toast relative overflow-hidden rounded-[var(--corner-xs)] border-0 bg-card text-foreground shadow-[0_1px_24px_rgba(0,0,0,0.3)] before:absolute before:inset-y-0 before:left-0 before:w-2 before:content-['']",
  content:
    "sonner-toast-content flex flex-1 flex-col gap-[10px] px-[20px] py-[20px]",
  title:
    "sonner-toast-title text-[16px] font-semibold leading-[24px] tracking-[0.01em] text-foreground",
  description:
    "sonner-toast-description text-[14px] leading-[20px] text-muted-foreground",
  icon: "hidden",
  closeButton:
    "absolute right-[16px] top-[16px] flex size-[16px] items-center justify-center rounded-none border-0 bg-transparent p-0 text-foreground opacity-100 shadow-none transition-opacity hover:opacity-70 focus-visible:outline-none focus-visible:ring-0",
  success:
    "w-[264px] before:bg-[var(--toast-success-accent)] [&_.sonner-toast-content]:gap-0 [&_.sonner-toast-content]:py-[23px] [&_.sonner-toast-description]:hidden",
  error:
    "w-[346px] before:bg-destructive [&_.sonner-toast-content]:pr-[40px]",
  warning:
    "w-[346px] before:bg-warning [&_.sonner-toast-content]:pr-[40px]",
  actionButton:
    "border-none bg-primary text-primary-foreground shadow-none hover:bg-primary-hover",
  cancelButton:
    "border border-input bg-card text-foreground shadow-none hover:bg-secondary",
} satisfies NonNullable<ToasterProps["toastOptions"]>["classNames"]

const Toaster = ({ className, style, ...props }: ToasterProps) => (
  <Sonner
    className={cn("toaster group", className)}
    closeButton={false}
    gap={24}
    offset={40}
    position="top-center"
    visibleToasts={3}
    style={
      {
        "--toast-success-accent": "#52c41a",
        ...style,
      } as React.CSSProperties
    }
    icons={{
      close: <X className="size-4" />,
    }}
    toastOptions={{
      className: "font-sans",
      unstyled: true,
      classNames: {
        ...toastClassNames,
      },
    }}
    {...props}
  />
)

function showSuccessToast(message: React.ReactNode, options: AppToastOptions = {}) {
  return toast.success(message, {
    closeButton: false,
    duration: 2400,
    ...options,
  })
}

function showFailureToast(message: React.ReactNode, options: AppToastOptions = {}) {
  return toast.error(message, {
    closeButton: true,
    duration: Infinity,
    ...options,
  })
}

function showReminderToast(message: React.ReactNode, options: AppToastOptions = {}) {
  return toast.warning(message, {
    closeButton: true,
    duration: Infinity,
    ...options,
  })
}

export {
  Toaster,
  showSuccessToast,
  showFailureToast,
  showReminderToast,
}
