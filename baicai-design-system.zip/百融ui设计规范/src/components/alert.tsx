import * as React from "react"
import { X } from "lucide-react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const alertVariants = cva(
  // padding 全 8px；图标 16×16：默认 top=8 与 AlertTitle (leading-4=16px) 中心对齐；
  // single-line（无 h5 Title 仅 Description leading-5=20px）时图标下移到 top=10、close 按钮下移到 top=6 让两者都与 Description 第一行/容器垂直居中
  "relative w-full rounded-[var(--corner-md)] border px-[var(--space-2)] py-[var(--space-2)] text-sm shadow-[var(--shadow-control)] [&>svg]:absolute [&>svg]:left-[var(--space-2)] [&>svg]:top-[var(--space-2)] [&>svg]:size-[16px] [&>svg]:text-foreground [&:not(:has(h5))>svg]:top-[10px] [&:not(:has(h5))>button]:top-[6px] [&>svg~*:not(button)]:pl-[24px]",
  {
    variants: {
      variant: {
        default: "border-border bg-card text-foreground",
        destructive:
          "border-destructive-border bg-destructive-soft text-foreground [&>svg]:text-destructive",
        success:
          "border-success-border bg-success-soft text-foreground [&>svg]:text-success",
        warning:
          "border-warning-border bg-warning-soft text-foreground [&>svg]:text-warning",
        info:
          "border-info-border bg-info-soft text-foreground [&>svg]:text-info",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

const Alert = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & VariantProps<typeof alertVariants>
>(({ className, variant, ...props }, ref) => (
  <div
    ref={ref}
    role="alert"
    className={cn(alertVariants({ variant }), className)}
    {...props}
  />
))
Alert.displayName = "Alert"

const AlertTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h5
    ref={ref}
    className={cn("mb-[var(--space-1)] font-medium leading-4 tracking-[0.01em]", className)}
    {...props}
  />
))
AlertTitle.displayName = "AlertTitle"

const AlertDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("text-[12px] leading-5 text-muted-foreground [&_p]:leading-5", className)}
    {...props}
  />
))
AlertDescription.displayName = "AlertDescription"

const AlertClose = React.forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement>
>(({ className, ...props }, ref) => (
  <button
    ref={ref}
    type="button"
    aria-label="关闭"
    className={cn(
      "absolute right-[var(--space-2)] top-[var(--space-2)] flex size-6 items-center justify-center rounded-[var(--corner-xs)] text-muted-foreground/70 transition-colors hover:bg-secondary hover:text-foreground",
      className
    )}
    {...props}
  >
    <X className="size-[14px]" />
  </button>
))
AlertClose.displayName = "AlertClose"

export { Alert, AlertTitle, AlertDescription, AlertClose }
