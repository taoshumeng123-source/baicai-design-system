import * as React from "react"
import { Inbox, type LucideIcon } from "lucide-react"

import { cn } from "../lib/utils"
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyIllustration,
  EmptyTitle,
  type EmptyVariant as EmptyStateVariant,
  inferEmptyVariant,
} from "@/components/empty"

interface EmptyStateProps {
  icon?: LucideIcon
  title: string
  description?: React.ReactNode
  action?: React.ReactNode
  size?: "sm" | "default"
  variant?: EmptyStateVariant
  className?: string
}

function EmptyState({
  icon: Icon = Inbox,
  title,
  description,
  action,
  size = "default",
  variant,
  className,
}: EmptyStateProps) {
  const descriptionText = typeof description === "string" ? description : undefined
  const resolvedVariant = variant ?? inferEmptyVariant(title, descriptionText)

  return (
    <div
      className={cn(
        "flex items-center justify-center",
        className
      )}
    >
      <Empty size={size}>
        <EmptyIllustration
          alt={title}
          description={descriptionText}
          size={size}
          title={title}
          variant={resolvedVariant}
        />
        <EmptyContent
          className={cn(
            size === "default" ? "w-[204px]" : "w-[140px]",
            !description && !action && "gap-[4px]"
          )}
        >
          <EmptyHeader className="w-full max-w-full">
            <EmptyTitle className="w-full max-w-full text-balance break-words">
              {title}
            </EmptyTitle>
            {description ? (
              <EmptyDescription className="block w-full text-balance break-words">
                {description}
              </EmptyDescription>
            ) : null}
          </EmptyHeader>
          {action ? (
            <div className="flex w-full flex-wrap items-center justify-center gap-[var(--space-3)]">
              {action}
            </div>
          ) : null}
          {!action && !description ? (
            <div className="sr-only">
              <Icon />
            </div>
          ) : null}
        </EmptyContent>
      </Empty>
    </div>
  )
}

export { EmptyState }
export type { EmptyStateProps }
