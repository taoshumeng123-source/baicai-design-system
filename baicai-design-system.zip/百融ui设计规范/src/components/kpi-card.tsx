import * as React from "react"
import { ArrowUp, type LucideIcon } from "lucide-react"
import {
  Bar,
  BarChart,
  Cell,
  LabelList,
  ResponsiveContainer,
  XAxis,
} from "recharts"

import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/tooltip"

// KPI 玻璃卡：玻璃渐变卡 + 左上 icon tile + 大数字 + 趋势 + note + 右下迷你柱图，
// 传入 compare 时 hover 弹出「数据对比」气泡（真实数值表 + 带刻度的近 6 月趋势）。
// 需置于 <TooltipProvider> 内（沿用 Tooltip 约定）。普通月柱用 --primary-border
// 浅紫渐变、最新月用 --primary 高亮。

// 「数据对比」气泡内趋势柱的月份刻度
const TREND_MONTHS = ["12月", "1月", "2月", "3月", "4月", "5月"]

// 卡右下角迷你柱图：浅色渐变柱 + 高亮最新月（圆角 pill）
function MiniBars({ data }: { data: readonly number[] }) {
  const id = React.useId().replace(/:/g, "")
  const last = data.length - 1
  const points = data.map((v, i) => ({ i, v }))
  return (
    <div className="h-[48px] w-[108px] shrink-0">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={points} margin={{ top: 4, right: 0, bottom: 0, left: 0 }} barGap={4}>
          <defs>
            <linearGradient id={`mb-l-${id}`} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="var(--primary-border)" stopOpacity={0.6} />
              <stop offset="100%" stopColor="var(--primary-border)" stopOpacity={0.32} />
            </linearGradient>
            <linearGradient id={`mb-s-${id}`} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="var(--primary)" stopOpacity={1} />
              <stop offset="100%" stopColor="var(--primary)" stopOpacity={0.6} />
            </linearGradient>
          </defs>
          <Bar dataKey="v" radius={[3, 3, 3, 3]} maxBarSize={7}>
            {points.map((p) => (
              <Cell key={p.i} fill={`url(#${p.i === last ? `mb-s-${id}` : `mb-l-${id}`})`} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

// 气泡内趋势：浅色渐变柱 + 高亮最新月 + 月份刻度 + 每月数值（最新月强调）
function BubbleBars({ data }: { data: readonly number[] }) {
  const id = React.useId().replace(/:/g, "")
  const last = data.length - 1
  const points = data.map((v, i) => ({ m: TREND_MONTHS[i] ?? "", v }))
  return (
    <div className="h-[92px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={points} margin={{ top: 18, right: 4, bottom: 0, left: 4 }}>
          <defs>
            <linearGradient id={`bb-l-${id}`} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="var(--primary-border)" stopOpacity={0.6} />
              <stop offset="100%" stopColor="var(--primary-border)" stopOpacity={0.32} />
            </linearGradient>
            <linearGradient id={`bb-s-${id}`} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="var(--primary)" stopOpacity={1} />
              <stop offset="100%" stopColor="var(--primary)" stopOpacity={0.6} />
            </linearGradient>
          </defs>
          <XAxis
            dataKey="m"
            interval={0}
            tick={{ fontSize: 10, fill: "var(--muted-foreground)" }}
            axisLine={false}
            tickLine={false}
            tickMargin={4}
          />
          <Bar dataKey="v" radius={[3, 3, 3, 3]} maxBarSize={14}>
            {points.map((p, i) => (
              <Cell key={i} fill={`url(#${i === last ? `bb-s-${id}` : `bb-l-${id}`})`} />
            ))}
            <LabelList
              dataKey="v"
              content={(p) => (
                <text
                  x={Number(p.x) + Number(p.width) / 2}
                  y={Number(p.y) - 4}
                  textAnchor="middle"
                  fontSize={10}
                  fontWeight={p.index === last ? 700 : 400}
                  fill={p.index === last ? "var(--primary)" : "var(--muted-foreground)"}
                >
                  {p.value}
                </text>
              )}
            />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

export interface KpiCompareRow {
  label: string
  value: string
  delta?: string
  pct?: string
}

export interface KpiCompare {
  rows: readonly KpiCompareRow[]
  trend: readonly number[]
  extra?: string
}

// hover「数据对比」气泡：真实数值表 + 带刻度趋势 + 上下文
function KpiCompareBubble({
  title,
  rows,
  trend,
  extra,
}: {
  title: string
  rows: readonly KpiCompareRow[]
  trend: readonly number[]
  extra?: string
}) {
  return (
    <div className="w-[248px] rounded-lg border border-border/50 bg-background p-[var(--space-3)] text-xs shadow-xl">
      <div className="mb-[var(--space-2)] text-[13px] font-semibold text-foreground">{title}</div>

      {/* 真实数值对比表：标签左，增量列 + 数值列各自右对齐 */}
      <div className="flex flex-col gap-[var(--space-1_5)] text-[12px]">
        {rows.map((r) => (
          <div
            key={r.label}
            className="grid items-baseline gap-x-[var(--space-3)]"
            style={{ gridTemplateColumns: "1fr auto auto" }}
          >
            <span className="text-muted-foreground">{r.label}</span>
            <span className="min-w-[88px] justify-self-end text-right text-[11px] font-medium tabular-nums text-success">
              {r.delta ? `↑${r.delta}（${r.pct}）` : ""}
            </span>
            <span className="min-w-[40px] justify-self-end text-right font-semibold tabular-nums text-foreground">
              {r.value}
            </span>
          </div>
        ))}
      </div>

      {/* 趋势：与卡面一致的圆角竖条 */}
      <div className="mt-[var(--space-2)] border-t border-border pt-[var(--space-1)]">
        <span className="text-[12px] text-muted-foreground">近 6 个月趋势</span>
        <BubbleBars data={trend} />
      </div>

      {extra && (
        <div className="mt-[var(--space-1)] border-t border-border pt-[var(--space-2)] text-[11px] text-muted-foreground">
          {extra}
        </div>
      )}
    </div>
  )
}

export interface KpiCardProps {
  label: string
  value: string
  trend: string
  trendDir?: "up" | "none"
  note?: string
  icon: LucideIcon
  series: readonly number[]
  /** 传入则启用 hover「数据对比」气泡；需置于 TooltipProvider 内 */
  compare?: KpiCompare
}

function KpiCard({
  label,
  value,
  trend,
  trendDir = "up",
  note,
  icon: Icon,
  series,
  compare,
}: KpiCardProps) {
  const card = (
    <div className="relative cursor-default overflow-hidden rounded-[var(--corner-xl)] border border-border bg-gradient-to-br from-primary-soft via-card to-primary-soft/40 p-[var(--space-5)] transition-shadow hover:shadow-[var(--shadow-card-hover)]">
      {/* icon + 标题（横排） */}
      <div className="flex items-center gap-[var(--space-2)]">
        {/* 玻璃质感 icon 块（可替换为切好的 PNG：<img src="/dashboard/xxx.png" className="size-7" />） */}
        <div className="flex size-7 shrink-0 items-center justify-center rounded-[var(--corner-sm)] bg-primary-soft/70">
          <Icon className="size-[16px] text-primary" strokeWidth={1.5} />
        </div>
        <p className="truncate text-[13px] font-normal text-muted-foreground">{label}</p>
      </div>

      {/* 大数字 */}
      <div className="mt-[var(--space-4)] text-[30px] font-bold leading-none tabular-nums text-foreground">
        {value}
      </div>

      {/* 趋势（左）+ 迷你柱图（右下）*/}
      <div className="mt-[var(--space-2)] flex items-end justify-between gap-[var(--space-2)]">
        <div className="flex items-center gap-[var(--space-1_5)]">
          {trendDir === "up" ? (
            <span className="flex items-center gap-[1px] text-[13px] font-semibold text-success">
              <ArrowUp className="size-[13px]" />
              {trend}
            </span>
          ) : (
            <span className="text-[13px] font-medium text-muted-foreground">{trend}</span>
          )}
          {note && <span className="text-[12px] text-muted-foreground">{note}</span>}
        </div>
        <MiniBars data={series} />
      </div>
    </div>
  )

  if (!compare) return card

  return (
    <Tooltip>
      <TooltipTrigger asChild>{card}</TooltipTrigger>
      <TooltipContent
        side="bottom"
        align="start"
        sideOffset={8}
        className="border-none bg-transparent p-0 shadow-none"
      >
        <KpiCompareBubble
          title={`${label} · 数据对比`}
          rows={compare.rows}
          trend={compare.trend}
          extra={compare.extra}
        />
      </TooltipContent>
    </Tooltip>
  )
}

export { KpiCard }
