import * as React from "react"

import { cn } from "@/lib/utils"

function TypographyH1({ className, ...props }: React.ComponentProps<"h1">) {
  return (
    <h1
      className={cn(
        "text-[20px] leading-[32px] font-bold text-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographyH2({ className, ...props }: React.ComponentProps<"h2">) {
  return (
    <h2
      className={cn(
        "text-[15px] leading-[24px] font-semibold text-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographyH3({ className, ...props }: React.ComponentProps<"h3">) {
  return (
    <h3
      className={cn(
        "text-[14px] leading-[22px] font-semibold text-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographyH4({ className, ...props }: React.ComponentProps<"h4">) {
  return (
    <h4
      className={cn(
        "text-[13px] leading-[20px] font-semibold text-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographyP({ className, ...props }: React.ComponentProps<"p">) {
  return (
    <p
      className={cn(
        "text-[12px] leading-[20px] font-normal text-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographyLarge({ className, ...props }: React.ComponentProps<"p">) {
  return (
    <p
      className={cn(
        "text-[13px] leading-[20px] font-normal text-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographyLabel({ className, ...props }: React.ComponentProps<"span">) {
  return (
    <span
      className={cn(
        "text-[12px] leading-[20px] font-medium text-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographySmall({
  className,
  ...props
}: React.ComponentProps<"small">) {
  return (
    <small
      className={cn(
        "text-[11px] leading-[16px] font-normal text-muted-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographyMuted({ className, ...props }: React.ComponentProps<"p">) {
  return (
    <p
      className={cn(
        "text-[12px] leading-[20px] font-normal text-muted-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographyDisplay({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      className={cn(
        "text-[28px] leading-[36px] font-bold text-foreground",
        className
      )}
      {...props}
    />
  )
}

function TypographyInlineCode({
  className,
  ...props
}: React.ComponentProps<"code">) {
  return (
    <code
      className={cn(
        "rounded-[var(--corner-xs)] bg-muted px-1 py-0.5 font-mono text-[12px] leading-[20px] font-normal text-foreground",
        className
      )}
      {...props}
    />
  )
}

export {
  TypographyH1,
  TypographyH2,
  TypographyH3,
  TypographyH4,
  TypographyP,
  TypographyLarge,
  TypographyLabel,
  TypographySmall,
  TypographyMuted,
  TypographyDisplay,
  TypographyInlineCode,
}
