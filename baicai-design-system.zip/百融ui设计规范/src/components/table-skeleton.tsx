import { cn } from "../lib/utils"
import { Skeleton } from "./skeleton"
import { TableRow, TableCell } from "./table"

interface TableSkeletonProps {
  columns: number
  rows?: number
  className?: string
}

function TableSkeleton({ columns, rows = 5, className }: TableSkeletonProps) {
  return (
    <>
      {Array.from({ length: rows }).map((_, i) => (
        <TableRow key={i} className={cn(className)}>
          {Array.from({ length: columns }).map((_, j) => (
            <TableCell key={j}>
              <Skeleton className="h-4 w-full" />
            </TableCell>
          ))}
        </TableRow>
      ))}
    </>
  )
}

export { TableSkeleton }
export type { TableSkeletonProps }
