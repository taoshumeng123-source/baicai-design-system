import * as React from "react"

import { cn } from "@/lib/utils"

const Table = React.forwardRef<
  HTMLTableElement,
  React.HTMLAttributes<HTMLTableElement>
>(({ className, ...props }, ref) => (
  <div className="relative w-full overflow-hidden rounded-lg border border-border bg-card">
    <table
      ref={ref}
      className={cn("w-full caption-bottom text-sm", className)}
      {...props}
    />
  </div>
))
Table.displayName = "Table"

const TableHeader = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <thead
    ref={ref}
    className={cn("[&_tr]:border-b [&_tr]:border-border", className)}
    {...props}
  />
))
TableHeader.displayName = "TableHeader"

const TableBody = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <tbody
    ref={ref}
    className={cn("[&_tr:last-child]:border-0", className)}
    {...props}
  />
))
TableBody.displayName = "TableBody"

const TableFooter = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <tfoot
    ref={ref}
    className={cn(
      "bg-secondary font-medium [&>tr]:last:border-b-0",
      className
    )}
    {...props}
  />
))
TableFooter.displayName = "TableFooter"

const TableRow = React.forwardRef<
  HTMLTableRowElement,
  React.HTMLAttributes<HTMLTableRowElement>
>(({ className, ...props }, ref) => (
  <tr
    ref={ref}
    className={cn(
      "border-b border-border transition-colors hover:bg-secondary data-[state=selected]:bg-secondary",
      className
    )}
    {...props}
  />
))
TableRow.displayName = "TableRow"

const TableHead = React.forwardRef<
  HTMLTableCellElement,
  React.ThHTMLAttributes<HTMLTableCellElement>
>(({ className, ...props }, ref) => (
  <th
    ref={ref}
    className={cn(
      "h-11 bg-background px-[var(--space-4)] text-left align-middle text-[12px] font-semibold tracking-[0.01em] text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className
    )}
    {...props}
  />
))
TableHead.displayName = "TableHead"

const TableCell = React.forwardRef<
  HTMLTableCellElement,
  React.TdHTMLAttributes<HTMLTableCellElement>
>(({ className, ...props }, ref) => (
  <td
    ref={ref}
    className={cn(
      "px-[var(--space-4)] py-[var(--space-3)] align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className
    )}
    {...props}
  />
))
TableCell.displayName = "TableCell"

const TableCaption = React.forwardRef<
  HTMLTableCaptionElement,
  React.HTMLAttributes<HTMLTableCaptionElement>
>(({ className, ...props }, ref) => (
  <caption
    ref={ref}
    className={cn("mt-[var(--space-4)] text-sm text-muted-foreground", className)}
    {...props}
  />
))
TableCaption.displayName = "TableCaption"

// 顶部覆盖式批量操作条：当 Table 选中行数 > 0 时，用本组件替换原过滤工具栏。
// 左侧显示「已选 N 项 · 取消」，右侧渲染 actions slot（按钮/分组等）。
interface TableSelectionBarProps extends React.HTMLAttributes<HTMLDivElement> {
  count: number
  onCancel?: () => void
  actions?: React.ReactNode
}

const TableSelectionBar = React.forwardRef<HTMLDivElement, TableSelectionBarProps>(
  ({ count, onCancel, actions, className, ...props }, ref) => (
    <div
      ref={ref}
      role="toolbar"
      aria-label="批量操作"
      className={cn(
        "flex h-[var(--control-height-xs)] items-center gap-[var(--space-6)] rounded-[var(--corner-md)] border border-border bg-background px-[var(--space-3)]",
        className
      )}
      {...props}
    >
      <span className="text-[12px] font-normal text-muted-foreground">
        已选 <span className="text-primary">{count}</span> 项
      </span>
      {onCancel && (
        <button
          type="button"
          onClick={onCancel}
          className="text-[12px] font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          取消
        </button>
      )}
      <div className="flex items-center gap-[var(--space-2)]">{actions}</div>
    </div>
  )
)
TableSelectionBar.displayName = "TableSelectionBar"

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableRow,
  TableCell,
  TableCaption,
  TableSelectionBar,
}
