"use client"

import * as React from "react"
import { Avatar as AvatarPrimitive } from "radix-ui"

import { cn } from "@/lib/utils"

const AvatarContext = React.createContext<{ name?: string }>({})
type AvatarBadgeVariant =
  | "default"
  | "success"
  | "warning"
  | "destructive"
  | "muted"

const avatarBadgeVariants: Record<AvatarBadgeVariant, string> = {
  default: "bg-primary text-primary-foreground",
  success: "bg-success text-success-foreground",
  warning: "bg-warning text-warning-foreground",
  destructive: "bg-destructive text-destructive-foreground",
  muted: "bg-muted-foreground text-card",
}

function getAvatarFallbackText(name?: string) {
  if (!name) return ""

  const normalized = name.trim()
  if (!normalized) return ""

  const [firstWord] = normalized.split(/\s+/)
  const [firstChar = ""] = Array.from(firstWord)
  return firstChar.toUpperCase()
}

function Avatar({
  className,
  size = "default",
  name,
  ...props
}: React.ComponentProps<typeof AvatarPrimitive.Root> & {
  size?: "default" | "sm" | "lg"
  name?: string
}) {
  return (
    <AvatarContext.Provider value={{ name }}>
      <AvatarPrimitive.Root
        data-slot="avatar"
        data-size={size}
        className={cn(
          "group/avatar relative isolate flex size-8 shrink-0 overflow-visible rounded-full select-none data-[size=lg]:size-10 data-[size=sm]:size-6",
          className
        )}
        {...props}
      />
    </AvatarContext.Provider>
  )
}

function AvatarImage({
  className,
  ...props
}: React.ComponentProps<typeof AvatarPrimitive.Image>) {
  return (
    <AvatarPrimitive.Image
      data-slot="avatar-image"
      className={cn("aspect-square size-full rounded-full object-cover", className)}
      {...props}
    />
  )
}

function AvatarFallback({
  className,
  children,
  name,
  ...props
}: React.ComponentProps<typeof AvatarPrimitive.Fallback> & {
  name?: string
}) {
  const context = React.useContext(AvatarContext)
  const fallbackText =
    children ?? getAvatarFallbackText(name ?? context.name)

  return (
    <AvatarPrimitive.Fallback
      data-slot="avatar-fallback"
      className={cn(
        "flex size-full items-center justify-center rounded-full bg-muted text-sm font-medium text-muted-foreground group-data-[size=sm]/avatar:text-xs",
        className
      )}
      {...props}
    >
      {fallbackText}
    </AvatarPrimitive.Fallback>
  )
}

function AvatarBadge({
  className,
  variant = "default",
  ...props
}: React.ComponentProps<"span"> & {
  variant?: AvatarBadgeVariant
}) {
  return (
    <span
      data-slot="avatar-badge"
      className={cn(
        "absolute right-[-1px] bottom-[-1px] z-20 inline-flex items-center justify-center rounded-full ring-2 ring-background select-none",
        "group-data-[size=sm]/avatar:size-2 group-data-[size=sm]/avatar:[&>svg]:hidden",
        "group-data-[size=default]/avatar:size-2.5 group-data-[size=default]/avatar:[&>svg]:size-2",
        "group-data-[size=lg]/avatar:size-3 group-data-[size=lg]/avatar:[&>svg]:size-2",
        avatarBadgeVariants[variant],
        className
      )}
      {...props}
    />
  )
}

function AvatarGroup({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="avatar-group"
      className={cn(
        "group/avatar-group flex -space-x-2 *:data-[slot=avatar]:ring-2 *:data-[slot=avatar]:ring-background",
        className
      )}
      {...props}
    />
  )
}

function AvatarGroupCount({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="avatar-group-count"
      className={cn(
        "relative flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-sm text-muted-foreground ring-2 ring-background group-has-data-[size=lg]/avatar-group:size-10 group-has-data-[size=sm]/avatar-group:size-6 [&>svg]:size-4 group-has-data-[size=lg]/avatar-group:[&>svg]:size-5 group-has-data-[size=sm]/avatar-group:[&>svg]:size-3",
        className
      )}
      {...props}
    />
  )
}

export {
  Avatar,
  AvatarImage,
  AvatarFallback,
  AvatarBadge,
  AvatarGroup,
  AvatarGroupCount,
}
export type { AvatarBadgeVariant }
