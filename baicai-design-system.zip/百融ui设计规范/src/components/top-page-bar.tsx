import * as React from "react"
import { ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

export type TopPageBarBreadcrumbItem = {
  icon?: React.ReactNode
  label: string
}

export interface TopPageBarProps {
  breadcrumb?: TopPageBarBreadcrumbItem[]
  title?: string
  unsaved?: boolean
  onSave?: () => void
  onDiscard?: () => void
  actions?: React.ReactNode
  elevated?: boolean
  className?: string
}

const TopPageBar = React.forwardRef<HTMLDivElement, TopPageBarProps>(
  (
    { breadcrumb, title, unsaved, onSave, onDiscard, actions, elevated, className },
    ref
  ) => {
    const hasBreadcrumb = breadcrumb && breadcrumb.length > 0

    if (hasBreadcrumb) {
      return (
        <div
          ref={ref}
          className={cn(
            "sticky top-0 z-20 shrink-0 border-b border-border bg-card/80 px-[var(--space-7)] backdrop-blur-md",
            className
          )}
        >
          <nav
            aria-label="Breadcrumb"
            className="flex h-[48px] items-center gap-[var(--space-2)] text-[13px]"
          >
            {breadcrumb.map((item, i) => {
              const isLast = i === breadcrumb.length - 1
              return (
                <React.Fragment key={i}>
                  {i > 0 && (
                    <ChevronRight className="size-[14px] shrink-0 text-muted-foreground/60" />
                  )}
                  <span
                    className={cn(
                      "flex items-center gap-[var(--space-1_5)]",
                      isLast ? "text-foreground" : "text-muted-foreground"
                    )}
                  >
                    {item.icon && (
                      <span className="flex size-[16px] shrink-0 items-center justify-center">
                        {item.icon}
                      </span>
                    )}
                    <span>{item.label}</span>
                  </span>
                </React.Fragment>
              )
            })}
          </nav>
        </div>
      )
    }

    return (
      <div
        ref={ref}
        className={cn(
          "sticky top-0 z-20 flex h-[48px] shrink-0 items-center gap-[var(--space-4)] border-b border-border bg-card/80 px-[var(--space-7)] backdrop-blur-md",
          className
        )}
      >
        {title && (
          <h1 className="text-[20px] font-bold leading-[32px] text-foreground">
            {title}
          </h1>
        )}

        <div className="flex flex-1 items-center justify-end gap-[var(--space-3)]">
          {unsaved && (
            <div className="flex items-center gap-[var(--space-2)]">
              <span className="text-[12px] text-muted-foreground">未保存的更改</span>
              {onDiscard && (
                <button
                  type="button"
                  onClick={onDiscard}
                  className="text-[12px] text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
                >
                  撤销
                </button>
              )}
            </div>
          )}

          {unsaved && onSave && (
            <button
              type="button"
              onClick={onSave}
              className="flex h-[var(--control-height-2xs)] items-center rounded-[var(--corner-sm)] bg-primary px-[var(--space-3)] text-[12px] font-medium text-primary-foreground transition-colors hover:bg-primary-hover active:bg-primary-active"
            >
              保存
            </button>
          )}

          {actions}
        </div>
      </div>
    )
  }
)
TopPageBar.displayName = "TopPageBar"

// ─── PageTitleHeader ──────────────────────────────────────────────────────────
// 内容区顶部的标题块（与说明文字、卡片同列对齐）。
// 用法：TopPageBar 提供面包屑导航条 → 内容区第一行用 PageTitleHeader 显示标题+操作。

export interface PageTitleHeaderProps {
  title: string
  description?: React.ReactNode
  unsaved?: boolean
  onSave?: () => void
  onDiscard?: () => void
  actions?: React.ReactNode
  className?: string
}

function PageTitleHeader({
  title,
  description,
  unsaved,
  onSave,
  onDiscard,
  actions,
  className,
}: PageTitleHeaderProps) {
  return (
    <div
      className={cn(
        "flex items-start justify-between gap-[var(--space-4)]",
        className
      )}
    >
      <div className="min-w-0">
        <h1 className="text-[20px] font-bold leading-[32px] text-foreground">
          {title}
        </h1>
        {description && (
          <p className="mt-[var(--space-1)] text-[13px] leading-[20px] text-muted-foreground">
            {description}
          </p>
        )}
      </div>

      <div className="flex shrink-0 items-center gap-[var(--space-3)]">
        {unsaved && (
          <div className="flex items-center gap-[var(--space-2)]">
            <span className="text-[12px] text-muted-foreground">未保存的更改</span>
            {onDiscard && (
              <button
                type="button"
                onClick={onDiscard}
                className="text-[12px] text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
              >
                撤销
              </button>
            )}
          </div>
        )}

        {unsaved && onSave && (
          <button
            type="button"
            onClick={onSave}
            className="flex h-[var(--control-height-2xs)] items-center rounded-[var(--corner-sm)] bg-primary px-[var(--space-3)] text-[12px] font-medium text-primary-foreground transition-colors hover:bg-primary-hover active:bg-primary-active"
          >
            保存
          </button>
        )}

        {actions}
      </div>
    </div>
  )
}

export { TopPageBar, PageTitleHeader }
