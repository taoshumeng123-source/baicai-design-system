import * as React from "react"
import { Check } from "lucide-react"

import { cn } from "@/lib/utils"

export interface ToggleChipProps {
  checked?: boolean
  defaultChecked?: boolean
  onCheckedChange?: (checked: boolean) => void
  children?: React.ReactNode
  className?: string
  disabled?: boolean
}

const ToggleChip = React.forwardRef<HTMLLabelElement, ToggleChipProps>(
  (
    {
      checked: checkedProp,
      defaultChecked = false,
      onCheckedChange,
      children,
      className,
      disabled,
    },
    ref
  ) => {
    const [internalChecked, setInternalChecked] = React.useState(defaultChecked)
    const isControlled = checkedProp !== undefined
    const checked = isControlled ? checkedProp : internalChecked

    function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
      if (disabled) return
      const next = e.target.checked
      if (!isControlled) setInternalChecked(next)
      onCheckedChange?.(next)
    }

    return (
      <label
        ref={ref}
        className={cn(
          "group inline-flex cursor-pointer items-center gap-[8px] text-[13px] font-normal leading-[20px] text-foreground transition-colors select-none whitespace-nowrap",
          disabled && "cursor-not-allowed opacity-45",
          className
        )}
      >
        <span
          className={cn(
            "flex size-[16px] shrink-0 items-center justify-center rounded-[var(--corner-xs)] border-[1.5px] transition-colors",
            checked
              ? "border-primary bg-primary"
              : "border-[#cecece] bg-card group-hover:border-primary"
          )}
        >
          {checked && <Check className="size-[10px] text-primary-foreground stroke-[2.5]" />}
        </span>
        <input
          type="checkbox"
          className="sr-only"
          checked={checked}
          disabled={disabled}
          onChange={handleChange}
        />
        {children}
      </label>
    )
  }
)
ToggleChip.displayName = "ToggleChip"

export { ToggleChip }
