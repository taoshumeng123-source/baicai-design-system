import * as React from "react"
import { cn } from "@/lib/utils"

// ─── CardIconBadge ────────────────────────────────────────────────────────────

export interface CardIconBadgeProps {
  icon: React.ReactNode
  variant?: "primary" | "destructive" | "success" | "warning" | "info"
  className?: string
}

const variantStyles: Record<NonNullable<CardIconBadgeProps["variant"]>, string> = {
  primary: "bg-primary-soft text-primary",
  destructive: "bg-destructive-soft text-destructive",
  success: "bg-success-soft text-success",
  warning: "bg-warning-soft text-warning",
  info: "bg-info-soft text-info",
}

function CardIconBadge({ icon, variant = "primary", className }: CardIconBadgeProps) {
  return (
    <div
      className={cn(
        "flex size-[36px] shrink-0 items-center justify-center rounded-[var(--corner-md)]",
        variantStyles[variant],
        className
      )}
    >
      {icon}
    </div>
  )
}

// ─── FieldRow ─────────────────────────────────────────────────────────────────

export interface FieldRowProps {
  label: string
  description?: string
  layout?: "default" | "split"
  children: React.ReactNode
  className?: string
}

function FieldRow({ label, description, layout = "split", children, className }: FieldRowProps) {
  if (layout === "split") {
    return (
      <div className={cn("flex items-center justify-between gap-[var(--space-6)] py-[var(--space-3)]", className)}>
        <div className="min-w-0 flex-1">
          <p className="text-[13px] font-medium text-foreground">{label}</p>
          {description && (
            <p className="mt-[2px] text-[12px] leading-[20px] text-muted-foreground">
              {description}
            </p>
          )}
        </div>
        <div className="flex shrink-0 items-center gap-[var(--space-3)]">
          {children}
        </div>
      </div>
    )
  }

  return (
    <div className={cn("flex items-center gap-[28px] py-[var(--space-3)]", className)}>
      <div className="w-[280px] shrink-0">
        <p className="text-[13px] font-medium text-foreground">{label}</p>
        {description && (
          <p className="mt-[2px] text-[12px] leading-[20px] text-muted-foreground">
            {description}
          </p>
        )}
      </div>
      <div className="flex flex-1 items-center gap-[var(--space-3)]">
        {children}
      </div>
    </div>
  )
}

// ─── SettingsCard ─────────────────────────────────────────────────────────────

export interface SettingsCardProps {
  title: string
  configCount?: number
  children?: React.ReactNode
  className?: string
}

const SettingsCard = React.forwardRef<HTMLDivElement, SettingsCardProps>(
  ({ title, configCount, children, className }, ref) => (
    <div
      ref={ref}
      className={cn(
        "overflow-hidden rounded-[var(--corner-lg)] border border-border bg-card shadow-[var(--shadow-control)]",
        className
      )}
    >
      <div className="flex h-[44px] items-center gap-[var(--space-2)] border-b border-border bg-background px-[var(--space-5)]">
        <p className="text-[14px] font-semibold text-foreground">{title}</p>
        {configCount !== undefined && (
          <span className="rounded-full bg-secondary px-[6px] py-[1px] text-[11px] font-medium text-muted-foreground">
            {configCount}
          </span>
        )}
      </div>

      {children && (
        <div className="px-[var(--space-5)]">
          {children}
        </div>
      )}
    </div>
  )
)
SettingsCard.displayName = "SettingsCard"

export { SettingsCard, CardIconBadge, FieldRow }
