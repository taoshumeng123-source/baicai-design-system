import * as React from "react"
import { Lock } from "lucide-react"

import { cn } from "@/lib/utils"

// SubNav · 三级导航（220px 宽左侧选择列表）
// 用于「角色管理」「部门树」等 master-detail 页面的左侧筛选/选择栏。
// 结构：Root 容器 → SubNavGroup（分组标题 + 可选操作）→ SubNavItem（条目，支持 count / lock / hover-actions）

interface SubNavProps extends React.HTMLAttributes<HTMLDivElement> {
  /** 自定义宽度，默认 220px */
  width?: number | string
  /** 静态置顶 header（如「公司名 + 邮箱 + 添加子部门」组合）。渲染在滚动区上方、不随 items 滚动 */
  header?: React.ReactNode
}

const SubNav = React.forwardRef<HTMLDivElement, SubNavProps>(
  ({ width = "220px", style, header, className, children, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="sub-nav"
      className={cn(
        "flex shrink-0 flex-col overflow-hidden border-r border-border bg-card",
        className
      )}
      style={{
        width: typeof width === "number" ? `${width}px` : width,
        ...style,
      }}
      {...props}
    >
      {header}
      <div className="flex-1 overflow-y-auto overscroll-none p-[var(--space-3)]">
        <div className="flex flex-col gap-[2px]">{children}</div>
      </div>
    </div>
  )
)
SubNav.displayName = "SubNav"

interface SubNavGroupProps {
  /** 分组标题（11px muted） */
  label: string
  /** 标题右侧操作按钮（可选，常用于「新建 +」icon-xs ghost Button + Tooltip） */
  action?: React.ReactNode
  children?: React.ReactNode
  className?: string
}

function SubNavGroup({ label, action, children, className }: SubNavGroupProps) {
  return (
    <div className={cn("mt-[var(--space-4)] first:mt-0", className)}>
      {action ? (
        <div className="mb-[var(--space-1)] flex items-center justify-between pl-[var(--space-3)] pr-[var(--space-1)]">
          <p className="text-[11px] font-medium text-muted-foreground">{label}</p>
          {action}
        </div>
      ) : (
        <p className="mb-[var(--space-1)] px-[var(--space-3)] pt-[var(--space-1)] text-[11px] font-medium text-muted-foreground">
          {label}
        </p>
      )}
      <div className="flex flex-col gap-[2px]">{children}</div>
    </div>
  )
}

export interface SubNavItemAction {
  icon: React.ReactNode
  /** 鼠标 hover 时显示的 native title 提示 */
  label: string
  onClick: () => void
  /** destructive 风格（hover 红色底） */
  destructive?: boolean
}

interface SubNavItemProps {
  /** 是否选中（高亮 bg-primary-soft + text-primary） */
  selected?: boolean
  onSelect?: () => void
  /** 右侧数字（成员数等），undefined 时不渲染 */
  count?: number
  /** 名称后跟随小锁 icon（系统/不可编辑项） */
  locked?: boolean
  /** hover 时替换 count 显示的图标操作（复制 / 删除等） */
  actions?: SubNavItemAction[]
  children: React.ReactNode
  className?: string
}

function SubNavItem({
  selected,
  onSelect,
  count,
  locked,
  actions,
  children,
  className,
}: SubNavItemProps) {
  const hasActions = !!actions && actions.length > 0
  const showRightSlot = count !== undefined || hasActions

  return (
    <button
      type="button"
      data-state={selected ? "active" : undefined}
      className={cn(
        "group flex h-[32px] w-full items-center gap-[var(--space-2)] rounded-[var(--corner-md)] px-[var(--space-3)] text-left transition-colors",
        selected
          ? "bg-primary-soft text-primary"
          : "text-foreground hover:bg-secondary",
        className
      )}
      onClick={onSelect}
    >
      {/* 名称 + 锁（锁紧跟名称后） */}
      <div className="flex min-w-0 flex-1 items-center gap-[var(--space-1)]">
        <span className="truncate text-[12px] font-medium">{children}</span>
        {locked && (
          <Lock
            className={cn(
              "size-[11px] shrink-0 opacity-40",
              selected ? "text-primary" : "text-muted-foreground"
            )}
          />
        )}
      </div>

      {/* 右侧固定容器：count 与 actions 通过 hover 切换，宽度恒定不抖 */}
      {showRightSlot && (
        <div className="relative flex h-[20px] w-[42px] shrink-0 items-center justify-end">
          {count !== undefined && (
            <span
              className={cn(
                "text-[11px] tabular-nums",
                selected ? "text-primary/70" : "text-muted-foreground",
                hasActions && "group-hover:invisible"
              )}
            >
              {count}
            </span>
          )}

          {hasActions && (
            <div className="absolute inset-y-0 left-0 right-[-4px] hidden items-center justify-end gap-[1px] group-hover:flex">
              {actions!.map((action, i) => (
                <button
                  key={i}
                  type="button"
                  title={action.label}
                  className={cn(
                    "flex size-[20px] items-center justify-center rounded-[var(--corner-xs)] text-muted-foreground",
                    action.destructive
                      ? "hover:bg-destructive-soft hover:text-destructive"
                      : "hover:bg-secondary hover:text-foreground"
                  )}
                  onClick={(e) => {
                    e.stopPropagation()
                    action.onClick()
                  }}
                >
                  {action.icon}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </button>
  )
}

export { SubNav, SubNavGroup, SubNavItem }
