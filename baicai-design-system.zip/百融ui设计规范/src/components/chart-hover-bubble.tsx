import * as React from "react"

// 图表 hover 气泡：复刻 ChartTooltipContent 的卡片样式（圆角 / border / shadow-xl）。
// 招聘趋势、招聘漏斗、招聘渠道等模块的轻量自定义 tooltip 统一复用本组件，
// 保证 hover 气泡外观一致。可选 color 渲染一个色点（段填充为渐变 url 时用纯色传入）。
export interface ChartHoverBubbleProps {
  title: string
  label: string
  value: number | string
  color?: string
}

function ChartHoverBubble({ title, label, value, color }: ChartHoverBubbleProps) {
  return (
    <div className="grid min-w-[8rem] items-start gap-1.5 rounded-lg border border-border/50 bg-background px-2.5 py-1.5 text-xs shadow-xl">
      <div className="font-medium text-foreground">{title}</div>
      <div className="flex w-full items-center gap-2">
        {color && (
          <div
            className="h-2.5 w-2.5 shrink-0 rounded-[var(--corner-xs)]"
            style={{ background: color }}
          />
        )}
        <div className="flex flex-1 items-center justify-between gap-3 leading-none">
          <span className="text-muted-foreground">{label}</span>
          <span className="font-mono font-medium tabular-nums text-foreground">
            {typeof value === "number" ? value.toLocaleString() : value}
          </span>
        </div>
      </div>
    </div>
  )
}

export { ChartHoverBubble }
