import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-md border border-transparent text-sm font-medium tracking-[0.01em] transition-[color,background-color,border-color,transform] duration-150 ease-out focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20 disabled:pointer-events-none disabled:opacity-45 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-primary text-primary-foreground hover:bg-primary-hover active:bg-primary-active",
        destructive:
          "bg-destructive text-destructive-foreground hover:bg-destructive-hover active:bg-destructive-active",
        outline:
          "border-input bg-card text-foreground hover:border-primary-border-hover hover:bg-primary-soft hover:text-primary-emphasis active:bg-primary-soft-hover",
        secondary:
          "bg-secondary text-secondary-foreground hover:bg-accent active:bg-primary-soft",
        ghost:
          "text-muted-foreground hover:bg-primary-soft hover:text-primary-emphasis active:bg-primary-soft-hover",
        link:
          "h-auto rounded-none border-transparent px-0 text-primary shadow-none hover:text-primary-hover hover:underline",
      },
      size: {
        default: "h-[var(--control-height-md)] px-[var(--space-4)]",
        sm: "h-[var(--control-height-xs)] rounded-sm px-[var(--space-3)] text-xs",
        lg: "h-[var(--control-height-lg)] rounded-xl px-[var(--space-6)] text-sm",
        icon: "size-[var(--control-height-md)]",
        "icon-sm": "size-[var(--control-height-xs)] rounded-sm",
        "icon-xs": "size-[var(--control-height-2xs)] rounded-sm",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
