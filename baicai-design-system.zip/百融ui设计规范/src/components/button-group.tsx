import { cva, type VariantProps } from "class-variance-authority"
import { Slot } from "radix-ui"

import { cn } from "@/lib/utils"
import { Separator } from "@/components/separator"

// 连体边框风格：相邻 button 共享边界，整体形成圆角矩形。
// aria-pressed=true 时 button 显示为 bg-primary-soft + text-primary。
const buttonGroupVariants = cva(
  "inline-flex w-fit items-center [&>*]:focus-visible:relative [&>*]:focus-visible:z-10 " +
    "[&>button]:h-8 [&>button]:px-[var(--space-3)] [&>button]:border [&>button]:border-input " +
    "[&>button]:bg-card [&>button]:text-foreground [&>button]:shadow-none [&>button]:transition-colors [&>button]:relative " +
    "[&>button:not(:first-child)]:-ml-px " +
    "[&>button:first-child]:rounded-l-[var(--corner-md)] [&>button:first-child]:rounded-r-none " +
    "[&>button:last-child]:rounded-r-[var(--corner-md)] [&>button:last-child]:rounded-l-none " +
    "[&>button:not(:first-child):not(:last-child)]:rounded-none " +
    "[&>button:hover]:bg-secondary [&>button:hover]:z-[1] " +
    "[&>button[aria-pressed=true]]:bg-primary-soft [&>button[aria-pressed=true]]:text-primary [&>button[aria-pressed=true]]:border-primary/40 [&>button[aria-pressed=true]]:z-[1]",
  {
    variants: {
      orientation: {
        horizontal: "",
        vertical: "flex-col [&>button]:w-full",
      },
    },
    defaultVariants: {
      orientation: "horizontal",
    },
  }
)

function ButtonGroup({
  className,
  orientation,
  ...props
}: React.ComponentProps<"div"> & VariantProps<typeof buttonGroupVariants>) {
  return (
    <div
      role="group"
      data-slot="button-group"
      data-orientation={orientation}
      className={cn(buttonGroupVariants({ orientation }), className)}
      {...props}
    />
  )
}

function ButtonGroupText({
  className,
  asChild = false,
  ...props
}: React.ComponentProps<"div"> & {
  asChild?: boolean
}) {
  const Comp = asChild ? Slot.Root : "div"

  return (
    <Comp
      className={cn(
        "flex items-center gap-2 rounded-lg border border-input bg-card px-4 text-sm font-medium [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    />
  )
}

function ButtonGroupSeparator({
  className,
  orientation = "vertical",
  ...props
}: React.ComponentProps<typeof Separator>) {
  return (
    <Separator
      data-slot="button-group-separator"
      orientation={orientation}
      className={cn(
        "relative m-0! self-stretch bg-border data-[orientation=vertical]:h-auto",
        className
      )}
      {...props}
    />
  )
}

export {
  ButtonGroup,
  ButtonGroupSeparator,
  ButtonGroupText,
  buttonGroupVariants,
}
