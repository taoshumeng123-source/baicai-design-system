import * as React from "react"
import { Cell, Pie, PieChart } from "recharts"

import {
  ChartContainer,
  ChartTooltip,
  type ChartConfig,
} from "@/components/chart"
import { ChartHoverBubble } from "@/components/chart-hover-bubble"

// 招聘渠道：环形图（每段竖向微弱渐变 opacity → opacity*0.78）+ 中心总计
// + 右侧图例列表（色点 / 名称 / 数量 / 占比）。颜色由调用方在 data 里给出，组件保持通用。

export interface ChannelDatum {
  label: string
  value: number
  /** 段填充基色 */
  color: string
  /** 基础不透明度（默认 1） */
  opacity?: number
  /** 图例 / tooltip 色点纯色（段填充为渐变 url，需单独给纯色；默认 = color） */
  dotColor?: string
}

export interface ChannelDonutProps {
  data: ChannelDatum[]
  /** 中心标题，默认「总计」 */
  centerLabel?: string
  /** hover 气泡内数值的标签，默认「数量」 */
  valueLabel?: string
}

// 环形图 Recharts 自定义 tooltip（与招聘趋势同款样式 + 渠道色点）
function ChannelTooltip(props: {
  active?: boolean
  payload?: Array<{ payload: ChannelDatum }>
  valueLabel?: string
}) {
  if (!props.active || !props.payload?.length) return null
  const item = props.payload[0].payload
  return (
    <ChartHoverBubble
      title={item.label}
      label={props.valueLabel ?? "数量"}
      value={item.value}
      color={item.dotColor ?? item.color}
    />
  )
}

function ChannelDonut({ data, centerLabel = "总计", valueLabel = "数量" }: ChannelDonutProps) {
  const uid = React.useId().replace(/:/g, "")
  const total = data.reduce((sum, d) => sum + d.value, 0)
  const config = { value: { label: valueLabel, color: "var(--chart-1)" } } satisfies ChartConfig

  return (
    <div className="flex flex-1 items-center justify-evenly">
      {/* 环形图 + 中心总计（总计置于图表底层，hover tooltip 在图表内最后渲染，覆盖其上）*/}
      <div className="relative size-[176px] shrink-0">
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-[12px] text-muted-foreground">{centerLabel}</span>
          <span className="text-[22px] font-bold tabular-nums text-foreground">
            {total.toLocaleString()}
          </span>
        </div>
        <ChartContainer config={config} className="!aspect-auto h-full w-full">
          <PieChart>
            <defs>
              {data.map((d, i) => {
                const op = d.opacity ?? 1
                return (
                  <linearGradient key={i} id={`cd-${uid}-${i}`} x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor={d.color} stopOpacity={op} />
                    <stop offset="100%" stopColor={d.color} stopOpacity={op * 0.78} />
                  </linearGradient>
                )
              })}
            </defs>
            <ChartTooltip content={<ChannelTooltip valueLabel={valueLabel} />} />
            <Pie
              data={data}
              dataKey="value"
              nameKey="label"
              innerRadius={56}
              outerRadius={84}
              paddingAngle={2}
              strokeWidth={0}
            >
              {data.map((d, i) => (
                <Cell key={d.label} fill={`url(#cd-${uid}-${i})`} />
              ))}
            </Pie>
          </PieChart>
        </ChartContainer>
      </div>

      {/* 右侧图例列表：色点 + 渠道 + 数量 + 占比（固定窄列紧凑排布）*/}
      <div className="flex shrink-0 flex-col gap-[var(--space-3)]">
        {data.map((d) => (
          <div
            key={d.label}
            className="grid items-center gap-[var(--space-3)]"
            style={{ gridTemplateColumns: "84px 48px 52px" }}
          >
            <span className="flex items-center gap-[var(--space-2)] text-[13px] text-foreground">
              <span
                className="size-2 shrink-0 rounded-full"
                style={{ background: d.color, opacity: d.opacity ?? 1 }}
              />
              {d.label}
            </span>
            <span className="text-right text-[13px] font-semibold tabular-nums text-foreground">
              {d.value.toLocaleString()}
            </span>
            <span className="text-right text-[12px] tabular-nums text-muted-foreground">
              {total > 0 ? ((d.value / total) * 100).toFixed(1) : "0.0"}%
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

export { ChannelDonut }
