import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-[var(--corner-xs)] border-0 font-medium tracking-[0.01em] transition-[color,background-color] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20",
  {
    variants: {
      variant: {
        default:
          "bg-primary-soft text-primary hover:bg-primary-soft-hover",
        secondary:
          "bg-secondary text-secondary-foreground hover:bg-accent",
        destructive:
          "bg-destructive-soft text-destructive hover:bg-destructive-soft-hover",
        outline: "bg-transparent text-foreground hover:bg-secondary",
        success:
          "bg-success-soft text-success-active hover:bg-success-soft-hover",
        warning:
          "bg-warning-soft text-warning hover:bg-warning-soft-hover",
        info:
          "bg-info-soft text-info hover:bg-info-soft-hover",
      },
      size: {
        sm: "px-[var(--space-2)] py-[2px] text-[11px]",
        default: "px-[var(--space-3)] py-[3px] text-xs",
        lg: "px-[var(--space-4)] py-[var(--space-1)] text-sm",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, size, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant, size }), className)} {...props} />
  )
}

export { Badge, badgeVariants }
