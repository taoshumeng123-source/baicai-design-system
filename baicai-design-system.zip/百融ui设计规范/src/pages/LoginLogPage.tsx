import * as React from "react"
import {
  AlertCircle,
  Bell,
  Briefcase,
  Code2,
  Database,
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  Link,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Network,
  Scale,
  Settings,
  Smartphone,
  Tablet,
  User,
  Users,
} from "lucide-react"

import { Alert, AlertDescription, AlertClose } from "@/components/alert"
import { Avatar, AvatarFallback } from "@/components/avatar"
import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { SystemNav } from "./SystemNav"
import { TopPageBar, PageTitleHeader } from "@/components/top-page-bar"
import { SearchInput } from "@/components/search-input"
import { Button } from "@/components/button"
import { Badge } from "@/components/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/table"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/sheet"
import { cn } from "@/lib/utils"

// ─── Types ────────────────────────────────────────────────────────────────────

interface LoginLog {
  id: string
  username: string
  user_email: string
  device_type: "desktop" | "mobile" | "tablet"
  device: { os: string; browser: string }
  status: "success" | "fail" | "blocked"
  method: "password" | "sso" | "mfa_totp" | "mfa_sms"
  ip: string
  geo: string
  fail_reason?: string
  risk_flags: string[]
  created_at: string
  user_agent: string
  request_id: string
  session_jti?: string
}

// ─── Constants ────────────────────────────────────────────────────────────────

const METHOD_LABELS: Record<LoginLog["method"], string> = {
  password: "密码",
  sso: "SSO",
  mfa_totp: "TOTP",
  mfa_sms: "短信 MFA",
}

// ─── Mock Data ────────────────────────────────────────────────────────────────

const MOCK_LOGS: LoginLog[] = [
  {
    id: "log_01",
    username: "张三",
    user_email: "zhangsan@br.com",
    device_type: "desktop",
    device: { os: "macOS", browser: "Chrome" },
    status: "success",
    method: "password",
    ip: "10.0.1.5",
    geo: "上海",
    risk_flags: [],
    created_at: "2026-05-25 09:12:33",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X) Chrome/124",
    request_id: "req_a1b2c3",
    session_jti: "jti-abc001",
  },
  {
    id: "log_02",
    username: "李四",
    user_email: "lisi@br.com",
    device_type: "desktop",
    device: { os: "Windows", browser: "Edge" },
    status: "success",
    method: "sso",
    ip: "10.0.1.12",
    geo: "北京",
    risk_flags: [],
    created_at: "2026-05-25 09:04:17",
    user_agent: "Mozilla/5.0 (Windows NT 10.0; Win64) Edge/124",
    request_id: "req_b2c3d4",
    session_jti: "jti-abc002",
  },
  {
    id: "log_03",
    username: "王五",
    user_email: "wangwu@br.com",
    device_type: "mobile",
    device: { os: "iOS", browser: "Safari" },
    status: "success",
    method: "mfa_totp",
    ip: "10.0.1.8",
    geo: "广州",
    risk_flags: [],
    created_at: "2026-05-25 08:55:40",
    user_agent: "Mozilla/5.0 (iPhone; CPU iPhone OS 17) AppleWebKit Safari",
    request_id: "req_c3d4e5",
    session_jti: "jti-abc003",
  },
  {
    id: "log_04",
    username: "赵六",
    user_email: "zhaoliu@br.com",
    device_type: "desktop",
    device: { os: "Windows", browser: "Chrome" },
    status: "fail",
    method: "password",
    ip: "203.0.113.5",
    geo: "境外",
    fail_reason: "密码错误",
    risk_flags: ["异地登录"],
    created_at: "2026-05-25 08:30:05",
    user_agent: "Mozilla/5.0 (Unknown Platform) Chrome/124",
    request_id: "req_d4e5f6",
  },
  {
    id: "log_05",
    username: "赵六",
    user_email: "zhaoliu@br.com",
    device_type: "desktop",
    device: { os: "Windows", browser: "Chrome" },
    status: "fail",
    method: "password",
    ip: "203.0.113.5",
    geo: "境外",
    fail_reason: "密码错误（第 2 次）",
    risk_flags: ["异地登录", "短时多次失败"],
    created_at: "2026-05-25 08:30:42",
    user_agent: "Mozilla/5.0 (Unknown Platform) Chrome/124",
    request_id: "req_e5f6a7",
  },
  {
    id: "log_06",
    username: "赵六",
    user_email: "zhaoliu@br.com",
    device_type: "desktop",
    device: { os: "Windows", browser: "Chrome" },
    status: "blocked",
    method: "password",
    ip: "203.0.113.5",
    geo: "境外",
    fail_reason: "连续失败超过阈值，账号已锁定 30 分钟",
    risk_flags: ["异地登录", "短时多次失败"],
    created_at: "2026-05-25 08:31:18",
    user_agent: "Mozilla/5.0 (Unknown Platform) Chrome/124",
    request_id: "req_f6a7b8",
  },
  {
    id: "log_07",
    username: "陈七",
    user_email: "chenqi@br.com",
    device_type: "desktop",
    device: { os: "macOS", browser: "Safari" },
    status: "success",
    method: "password",
    ip: "10.0.1.33",
    geo: "杭州",
    risk_flags: ["新设备"],
    created_at: "2026-05-24 18:30:22",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X) Safari/17",
    request_id: "req_a7b8c9",
    session_jti: "jti-abc007",
  },
  {
    id: "log_08",
    username: "林八",
    user_email: "linba@br.com",
    device_type: "tablet",
    device: { os: "iPad", browser: "Safari" },
    status: "success",
    method: "mfa_sms",
    ip: "10.0.1.44",
    geo: "成都",
    risk_flags: [],
    created_at: "2026-05-24 17:12:08",
    user_agent: "Mozilla/5.0 (iPad; CPU OS 17) AppleWebKit Safari",
    request_id: "req_b8c9d0",
    session_jti: "jti-abc008",
  },
  {
    id: "log_09",
    username: "周九",
    user_email: "zhoujiu@br.com",
    device_type: "desktop",
    device: { os: "Windows", browser: "Chrome" },
    status: "fail",
    method: "password",
    ip: "10.0.1.55",
    geo: "上海",
    fail_reason: "密码错误",
    risk_flags: [],
    created_at: "2026-05-24 16:45:55",
    user_agent: "Mozilla/5.0 (Windows NT 10.0; Win64) Chrome/124",
    request_id: "req_c9d0e1",
  },
  {
    id: "log_10",
    username: "吴十",
    user_email: "wushi@br.com",
    device_type: "desktop",
    device: { os: "macOS", browser: "Firefox" },
    status: "success",
    method: "sso",
    ip: "10.0.1.66",
    geo: "北京",
    risk_flags: [],
    created_at: "2026-05-24 14:20:11",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X) Firefox/125",
    request_id: "req_d0e1f2",
    session_jti: "jti-abc010",
  },
  {
    id: "log_11",
    username: "张三",
    user_email: "zhangsan@br.com",
    device_type: "mobile",
    device: { os: "Android", browser: "Chrome" },
    status: "success",
    method: "password",
    ip: "10.0.1.5",
    geo: "上海",
    risk_flags: [],
    created_at: "2026-05-24 11:33:48",
    user_agent: "Mozilla/5.0 (Linux; Android 14) Chrome/124",
    request_id: "req_e1f2a3",
    session_jti: "jti-abc011",
  },
  {
    id: "log_12",
    username: "陈七",
    user_email: "chenqi@br.com",
    device_type: "desktop",
    device: { os: "macOS", browser: "Safari" },
    status: "success",
    method: "mfa_totp",
    ip: "10.0.1.33",
    geo: "杭州",
    risk_flags: [],
    created_at: "2026-05-24 09:48:15",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X) Safari/17",
    request_id: "req_f2a3b4",
    session_jti: "jti-abc012",
  },
]

// ─── Helpers ──────────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: LoginLog["status"] }) {
  if (status === "success") return <Badge variant="success" size="sm">成功</Badge>
  if (status === "fail")    return <Badge variant="warning" size="sm">失败</Badge>
  return <Badge variant="destructive" size="sm">拦截</Badge>
}

function MethodBadge({ method }: { method: LoginLog["method"] }) {
  return <Badge variant="secondary" size="sm">{METHOD_LABELS[method]}</Badge>
}

function DeviceIcon({ type }: { type: LoginLog["device_type"] }) {
  if (type === "mobile") return <Smartphone className="size-[14px] text-muted-foreground" />
  if (type === "tablet") return <Tablet className="size-[14px] text-muted-foreground" />
  return <Monitor className="size-[14px] text-muted-foreground" />
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="mb-[var(--space-2)] text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
      {children}
    </p>
  )
}

function DetailRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-[var(--space-5)] py-[6px]">
      <span className="shrink-0 text-[12px] text-muted-foreground">{label}</span>
      <div className="flex min-w-0 flex-wrap items-center justify-end gap-[var(--space-1)] text-right text-[12px] text-foreground">
        {children}
      </div>
    </div>
  )
}

// ─── LoginLogPage ─────────────────────────────────────────────────────────────

export function LoginLogPage() {
  const [q, setQ] = React.useState("")
  const [timeRange, setTimeRange] = React.useState("7d")
  const [statusFilter, setStatusFilter] = React.useState("all")
  const [methodFilter, setMethodFilter] = React.useState("all")
  const [riskFilter, setRiskFilter] = React.useState("all")
  const [selectedLog, setSelectedLog] = React.useState<LoginLog | null>(null)
  const [riskBannerDismissed, setRiskBannerDismissed] = React.useState(false)
  const [barElevated, setBarElevated] = React.useState(false)
  const scrollRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => setBarElevated(el.scrollTop > 0)
    el.addEventListener("scroll", onScroll, { passive: true })
    return () => el.removeEventListener("scroll", onScroll)
  }, [])

  const filtered = React.useMemo(() => MOCK_LOGS.filter(log => {
    if (timeRange === "today" && !log.created_at.startsWith("2026-05-25")) return false
    if (statusFilter !== "all" && log.status !== statusFilter) return false
    if (methodFilter !== "all" && log.method !== methodFilter) return false
    if (riskFilter === "with" && log.risk_flags.length === 0) return false
    if (riskFilter === "none" && log.risk_flags.length > 0) return false
    if (q && ![log.username, log.user_email, log.ip].some(v => v.includes(q))) return false
    return true
  }), [q, timeRange, statusFilter, methodFilter, riskFilter])

  const riskLogs = MOCK_LOGS.filter(l => l.risk_flags.length > 0)
  const riskTypes = [...new Set(MOCK_LOGS.flatMap(l => l.risk_flags))]
  const showRiskBanner = !riskBannerDismissed && riskLogs.length > 0

  return (
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">

      {/* ── NarrowRail ── */}
      <NarrowRail
        logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── WideNav ── */}
      <SystemNav active="login-log" />

      {/* ── 右侧内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">

        <div ref={scrollRef} className="flex-1 overflow-y-auto overscroll-none bg-card">
          <TopPageBar
            breadcrumb={[
              { icon: <Settings className="size-[14px]" />, label: "系统管理" },
              { label: "登录日志" },
            ]}
            elevated={barElevated}
          />
          <div className="mx-auto flex max-w-[1280px] flex-col gap-[var(--space-4)] px-[var(--space-7)] py-[var(--space-5)] pb-10">

            <PageTitleHeader
              title="登录日志"
              actions={<Button variant="outline" size="sm">导出</Button>}
            />

            {/* ── 风险横幅 ── */}
            {showRiskBanner && (
              <Alert variant="warning">
                <AlertCircle />
                <AlertDescription>
                  检测到 {riskLogs.length} 条风险登录（{riskTypes.join(" · ")}），建议及时排查
                </AlertDescription>
                <AlertClose onClick={() => setRiskBannerDismissed(true)} />
              </Alert>
            )}

            {/* ── 过滤栏 ── */}
            <div className="flex items-center gap-[var(--space-3)]">
              <SearchInput
                placeholder="搜索用户名、邮箱或 IP"
                className="w-[240px]"
                onSearch={setQ}
              />
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-[100px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">今天</SelectItem>
                  <SelectItem value="7d">近 7 天</SelectItem>
                  <SelectItem value="30d">近 30 天</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[100px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="success">成功</SelectItem>
                  <SelectItem value="fail">失败</SelectItem>
                  <SelectItem value="blocked">拦截</SelectItem>
                </SelectContent>
              </Select>
              <Select value={methodFilter} onValueChange={setMethodFilter}>
                <SelectTrigger className="w-[110px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部方式</SelectItem>
                  <SelectItem value="password">密码</SelectItem>
                  <SelectItem value="sso">SSO</SelectItem>
                  <SelectItem value="mfa_totp">TOTP</SelectItem>
                  <SelectItem value="mfa_sms">短信 MFA</SelectItem>
                </SelectContent>
              </Select>
              <Select value={riskFilter} onValueChange={setRiskFilter}>
                <SelectTrigger className="w-[100px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部风险</SelectItem>
                  <SelectItem value="with">有风险</SelectItem>
                  <SelectItem value="none">无风险</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex-1" />
              <span className="text-[13px] text-muted-foreground">共 {filtered.length} 条记录</span>
            </div>

            {/* ── 表格 ── */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>时间</TableHead>
                  <TableHead>用户</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>方式</TableHead>
                  <TableHead>IP / 位置</TableHead>
                  <TableHead>设备</TableHead>
                  <TableHead>风险标记</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody className="[&_td]:py-[var(--space-3)]">
                {filtered.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="py-[var(--space-8)] text-center text-[13px] text-muted-foreground">
                      暂无符合条件的记录
                    </TableCell>
                  </TableRow>
                ) : (
                  filtered.map(log => (
                    <TableRow
                      key={log.id}
                      className="cursor-pointer"
                      onClick={() => setSelectedLog(log)}
                    >
                      <TableCell className="text-[12px] text-muted-foreground">
                        {log.created_at}
                      </TableCell>

                      <TableCell>
                        <div className="flex items-center gap-[var(--space-2)]">
                          <Avatar size="sm">
                            <AvatarFallback>{log.username[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-[13px] text-foreground">{log.username}</p>
                            <p className="text-[12px] text-muted-foreground">{log.user_email}</p>
                          </div>
                        </div>
                      </TableCell>

                      <TableCell>
                        <StatusBadge status={log.status} />
                      </TableCell>

                      <TableCell>
                        <MethodBadge method={log.method} />
                      </TableCell>

                      <TableCell>
                        <span className={cn(
                          "text-[13px]",
                          log.risk_flags.includes("异地登录") ? "text-destructive" : "text-foreground"
                        )}>
                          {log.ip}
                        </span>
                        <span className="text-[12px] text-muted-foreground"> · {log.geo}</span>
                      </TableCell>

                      <TableCell>
                        <div className="flex items-center gap-[var(--space-1_5)]">
                          <DeviceIcon type={log.device_type} />
                          <span className="text-[12px] text-foreground">
                            {log.device.os} · {log.device.browser}
                          </span>
                        </div>
                      </TableCell>

                      <TableCell>
                        {log.risk_flags.length > 0 ? (
                          <div className="flex flex-wrap gap-[var(--space-1)]">
                            {log.risk_flags.map((flag, i) => (
                              <Badge key={i} variant="warning" size="sm">{flag}</Badge>
                            ))}
                          </div>
                        ) : (
                          <span className="text-[12px] text-muted-foreground">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>

          </div>
        </div>
      </div>

      {/* ── 详情面板 ── */}
      <Sheet open={!!selectedLog} onOpenChange={(open) => { if (!open) setSelectedLog(null) }}>
        <SheetContent side="right" className="flex flex-col gap-0 overflow-y-hidden p-0">
          {selectedLog && (
            <>
              <SheetHeader className="shrink-0 border-b border-border px-[var(--space-5)] pb-[var(--space-4)] pt-[var(--space-5)] pr-14">
                <div className="flex items-center gap-[var(--space-2)]">
                  <StatusBadge status={selectedLog.status} />
                  <SheetTitle className="text-[15px] font-semibold leading-snug">
                    {selectedLog.username}
                  </SheetTitle>
                </div>
                <SheetDescription className="text-[12px]">
                  {selectedLog.created_at}
                </SheetDescription>
              </SheetHeader>

              <div className="flex-1 overflow-y-auto overscroll-none">

                {/* 登录摘要 */}
                <div className="border-b border-border px-[var(--space-5)] py-[var(--space-4)]">
                  <SectionLabel>登录摘要</SectionLabel>
                  <div className="divide-y divide-border">
                    <DetailRow label="用户">
                      <div className="flex items-center gap-[var(--space-2)]">
                        <Avatar size="sm">
                          <AvatarFallback>{selectedLog.username[0]}</AvatarFallback>
                        </Avatar>
                        <div className="text-left">
                          <p className="text-[12px] text-foreground">{selectedLog.username}</p>
                          <p className="text-[11px] text-muted-foreground">{selectedLog.user_email}</p>
                        </div>
                      </div>
                    </DetailRow>
                    <DetailRow label="状态">
                      <StatusBadge status={selectedLog.status} />
                    </DetailRow>
                    <DetailRow label="登录方式">
                      <MethodBadge method={selectedLog.method} />
                    </DetailRow>
                    <DetailRow label="时间">{selectedLog.created_at}</DetailRow>
                    {selectedLog.session_jti && (
                      <DetailRow label="会话 ID">
                        <span className="font-mono text-[11px]">{selectedLog.session_jti}</span>
                      </DetailRow>
                    )}
                  </div>
                </div>

                {/* 位置与设备 */}
                <div className={cn(
                  "px-[var(--space-5)] py-[var(--space-4)]",
                  (selectedLog.risk_flags.length > 0 || selectedLog.status !== "success") && "border-b border-border"
                )}>
                  <SectionLabel>位置与设备</SectionLabel>
                  <div className="divide-y divide-border">
                    <DetailRow label="来源 IP">
                      <span className={cn(
                        "font-mono text-[11px]",
                        selectedLog.risk_flags.includes("异地登录") ? "text-destructive" : ""
                      )}>
                        {selectedLog.ip}
                      </span>
                    </DetailRow>
                    <DetailRow label="地区">{selectedLog.geo}</DetailRow>
                    <DetailRow label="设备类型">
                      <div className="flex items-center gap-[var(--space-1)]">
                        <DeviceIcon type={selectedLog.device_type} />
                        <span>{selectedLog.device.os}</span>
                      </div>
                    </DetailRow>
                    <DetailRow label="浏览器">{selectedLog.device.browser}</DetailRow>
                    <DetailRow label="Request ID">
                      <span className="font-mono text-[11px]">{selectedLog.request_id}</span>
                    </DetailRow>
                    <DetailRow label="User-Agent">
                      <span className="break-all text-[11px] text-muted-foreground">
                        {selectedLog.user_agent}
                      </span>
                    </DetailRow>
                  </div>
                </div>

                {/* 风险标记 */}
                {selectedLog.risk_flags.length > 0 && (
                  <div className={cn(
                    "px-[var(--space-5)] py-[var(--space-4)]",
                    selectedLog.status !== "success" && "border-b border-border"
                  )}>
                    <SectionLabel>风险标记</SectionLabel>
                    <div className="flex flex-wrap gap-[var(--space-2)]">
                      {selectedLog.risk_flags.map((flag, i) => (
                        <Badge key={i} variant="warning">{flag}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* 失败原因 */}
                {selectedLog.status !== "success" && selectedLog.fail_reason && (
                  <div className="px-[var(--space-5)] py-[var(--space-4)]">
                    <SectionLabel>失败原因</SectionLabel>
                    <p className="text-[13px] text-foreground">{selectedLog.fail_reason}</p>
                  </div>
                )}

              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

    </div>
  )
}
