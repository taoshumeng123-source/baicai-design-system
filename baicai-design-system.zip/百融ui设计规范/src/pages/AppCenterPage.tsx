import * as React from "react"
import {
  BarChart3,
  Bell,
  Briefcase,
  Building2,
  ClipboardList,
  Code2,
  CodeXml,
  Database,
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  Link,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Network,
  Scale,
  Search,
  Settings,
  Target,
  User,
  Users,
  Video,
} from "lucide-react"

import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { SystemNav } from "./SystemNav"
import { TopPageBar, PageTitleHeader } from "@/components/top-page-bar"
import { AppCard } from "@/components/app-card"

// ─── Module data ──────────────────────────────────────────────────────────────

const MODULES = [
  {
    code: "coder",
    name: "智码",
    category: "编程测评",
    description: "Vibe Coding 测评，题库组卷与 AI 评分",
    iconBg: "bg-primary-soft",
    iconColor: "text-primary",
    icon: <CodeXml className="size-5" />,
    status: "enabled" as const,
  },
  {
    code: "scout",
    name: "智源",
    category: "人才识别",
    description: "简历解析、人才画像、智能匹配，快速识别目标候选人",
    iconBg: "bg-info-soft",
    iconColor: "text-info",
    icon: <Search className="size-5" />,
    status: "active" as const,
  },
  {
    code: "assess",
    name: "智面",
    category: "智能面试",
    description: "AI 驱动的智能面试，自动评估与反馈",
    iconBg: "bg-warning-soft",
    iconColor: "text-warning",
    icon: <Video className="size-5" />,
    status: "coming_soon" as const,
  },
  {
    code: "insight",
    name: "智策",
    category: "数据洞察",
    description: "招聘数据分析与可视化，决策支持",
    iconBg: "bg-destructive-soft",
    iconColor: "text-destructive",
    icon: <BarChart3 className="size-5" />,
    status: "coming_soon" as const,
  },
  {
    code: "seeker",
    name: "智寻",
    category: "寻源采集",
    description: "多平台招聘网站寻源，自动化简历采集与筛选",
    iconBg: "bg-info-soft",
    iconColor: "text-info",
    icon: <Target className="size-5" />,
    status: "coming_soon" as const,
  },
]

// ─── AppCenterPage ────────────────────────────────────────────────────────────

export function AppCenterPage() {
  const enabledModules = MODULES.filter((m) => m.status === "enabled")
  const otherModules = MODULES.filter((m) => m.status !== "enabled")
  const [barElevated, setBarElevated] = React.useState(false)
  const scrollRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => setBarElevated(el.scrollTop > 0)
    el.addEventListener("scroll", onScroll, { passive: true })
    return () => el.removeEventListener("scroll", onScroll)
  }, [])

  return (
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">

      {/* ── 一级侧导航 NarrowRail 56px ── */}
      <NarrowRail
        logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── 二级侧导航 WideNav 240px ── */}
      <SystemNav active="app-center" />

      {/* ── 右侧内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">

        <div ref={scrollRef} className="flex-1 overflow-y-auto overscroll-none bg-card">
          <TopPageBar
            breadcrumb={[
              { icon: <Settings className="size-[14px]" />, label: "系统管理" },
              { label: "应用中心" },
            ]}
            elevated={barElevated}
          />
          <div className="mx-auto max-w-[1280px] px-[var(--space-7)] py-[var(--space-5)]">

            <PageTitleHeader title="应用中心" className="mb-[var(--space-5)]" />

            {/* 已开通 */}
            <div>
              <h2 className="text-[15px] font-semibold text-foreground">已开通</h2>
              <div className="mt-[var(--space-4)] grid grid-cols-3 gap-[var(--space-4)]">
                {enabledModules.map((m) => (
                  <AppCard key={m.code} {...m} />
                ))}
              </div>
            </div>

            {/* 更多应用 */}
            <div className="mt-[var(--space-8)]">
              <h2 className="text-[15px] font-semibold text-foreground">更多应用</h2>
              <div className="mt-[var(--space-4)] grid grid-cols-3 gap-[var(--space-4)]">
                {otherModules.map((m) => (
                  <AppCard key={m.code} {...m} />
                ))}
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  )
}
