import * as React from "react"
import {
  Bell,
  Briefcase,
  Building2,
  ClipboardList,
  Code2,
  Database,
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  Link,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Plus,
  Scale,
  Settings,
  Trash2,
  User,
  Users,
} from "lucide-react"

import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { SystemNav } from "./SystemNav"
import { SubNav, SubNavItem } from "@/components/sub-nav"
import { TopPageBar, PageTitleHeader } from "@/components/top-page-bar"
import { SearchInput } from "@/components/search-input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"
import { Button } from "@/components/button"
import { Badge } from "@/components/badge"
import { Avatar, AvatarFallback } from "@/components/avatar"
import { Checkbox } from "@/components/checkbox"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableSelectionBar,
} from "@/components/table"
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/dialog"
import { Input } from "@/components/input"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/tooltip"
import { cn } from "@/lib/utils"

// ─── Types ────────────────────────────────────────────────────────────────────

interface Department {
  id: string
  name: string
  memberCount: number
}

interface MemberItem {
  id: string
  name: string
  email: string
  deptId: string
  deptName: string
  groups: { id: string; name: string }[]
  roles: { id: string; name: string }[]
  status: "active" | "disabled"
  joinedAt: string
}

// ─── Mock Data ────────────────────────────────────────────────────────────────

const MOCK_DEPTS: Department[] = [
  { id: "all", name: "全部成员", memberCount: 8 },
  { id: "tech", name: "技术部", memberCount: 3 },
  { id: "product", name: "产品部", memberCount: 2 },
  { id: "ops", name: "运营部", memberCount: 2 },
  { id: "mkt", name: "市场部", memberCount: 1 },
]

const MOCK_MEMBERS: MemberItem[] = [
  {
    id: "m1",
    name: "张伟",
    email: "zhangwei@br.com",
    deptId: "tech",
    deptName: "技术部",
    groups: [{ id: "dev", name: "开发团队" }],
    roles: [{ id: "admin", name: "管理员" }],
    status: "active",
    joinedAt: "2024-03-01",
  },
  {
    id: "m2",
    name: "李娜",
    email: "lina@br.com",
    deptId: "product",
    deptName: "产品部",
    groups: [{ id: "product", name: "产品团队" }],
    roles: [{ id: "pm", name: "产品经理" }],
    status: "active",
    joinedAt: "2024-03-15",
  },
  {
    id: "m3",
    name: "王芳",
    email: "wangfang@br.com",
    deptId: "tech",
    deptName: "技术部",
    groups: [{ id: "dev", name: "开发团队" }],
    roles: [{ id: "dev", name: "开发者" }],
    status: "active",
    joinedAt: "2024-04-01",
  },
  {
    id: "m4",
    name: "刘洋",
    email: "liuyang@br.com",
    deptId: "ops",
    deptName: "运营部",
    groups: [],
    roles: [{ id: "ops", name: "运营专员" }],
    status: "active",
    joinedAt: "2024-04-10",
  },
  {
    id: "m5",
    name: "陈静",
    email: "chenjing@br.com",
    deptId: "mkt",
    deptName: "市场部",
    groups: [],
    roles: [{ id: "mkt", name: "市场专员" }],
    status: "disabled",
    joinedAt: "2024-02-20",
  },
  {
    id: "m6",
    name: "杨磊",
    email: "yanglei@br.com",
    deptId: "tech",
    deptName: "技术部",
    groups: [
      { id: "dev", name: "开发团队" },
      { id: "arch", name: "架构组" },
    ],
    roles: [{ id: "dev", name: "开发者" }],
    status: "active",
    joinedAt: "2024-01-15",
  },
  {
    id: "m7",
    name: "赵霞",
    email: "zhaoxia@br.com",
    deptId: "product",
    deptName: "产品部",
    groups: [{ id: "product", name: "产品团队" }],
    roles: [{ id: "pm", name: "产品经理" }],
    status: "active",
    joinedAt: "2024-05-01",
  },
  {
    id: "m8",
    name: "周鑫",
    email: "zhouxin@br.com",
    deptId: "ops",
    deptName: "运营部",
    groups: [],
    roles: [{ id: "ops", name: "运营专员" }],
    status: "active",
    joinedAt: "2024-05-10",
  },
]


// ─── Page ─────────────────────────────────────────────────────────────────────

export function MembersPage() {
  const [selectedDept, setSelectedDept] = React.useState<string>("all")
  const [q, setQ] = React.useState("")
  const [groupFilter, setGroupFilter] = React.useState<string>("all")
  const [statusFilter, setStatusFilter] = React.useState<string>("all")
  const [selectedKeys, setSelectedKeys] = React.useState<Set<string>>(new Set())
  const [inviteOpen, setInviteOpen] = React.useState(false)
  const [barElevated, setBarElevated] = React.useState(false)
  const scrollRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const handler = () => setBarElevated(el.scrollTop > 0)
    el.addEventListener("scroll", handler, { passive: true })
    return () => el.removeEventListener("scroll", handler)
  }, [])

  const filtered = MOCK_MEMBERS.filter(m => {
    if (selectedDept !== "all" && m.deptId !== selectedDept) return false
    if (statusFilter !== "all" && m.status !== statusFilter) return false
    if (groupFilter !== "all" && !m.groups.some(g => g.id === groupFilter)) return false
    if (q && ![m.name, m.email].some(v => v.includes(q))) return false
    return true
  })

  const allSelected = selectedKeys.size > 0 && selectedKeys.size === filtered.length
  const someSelected = selectedKeys.size > 0 && selectedKeys.size < filtered.length

  function toggleRow(id: string) {
    setSelectedKeys(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <TooltipProvider delayDuration={300}>
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">

      {/* ── 一级侧导航 ── */}
      <NarrowRail
        logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── 二级侧导航 ── */}
      <SystemNav active="members" />

      {/* ── 右侧内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <TopPageBar
          breadcrumb={[
            { icon: <Settings className="size-[14px]" />, label: "系统管理" },
            { label: "成员" },
          ]}
          elevated={barElevated}
        />

        <div className="shrink-0 border-b border-border bg-card px-[var(--space-7)] py-[var(--space-4)]">
          <PageTitleHeader
            title="成员"
            actions={
              <Button size="sm" onClick={() => setInviteOpen(true)}>
                邀请成员
              </Button>
            }
          />
        </div>

        <div className="flex flex-1 overflow-hidden">

          {/* ── 左侧部门列表 · SubNav 三级导航 ── */}
          <SubNav
            header={
              <div className="flex items-start justify-between pl-[var(--space-6)] pr-[var(--space-3)] pt-[var(--space-5)] pb-[var(--space-1)]">
                <div className="min-w-0">
                  <p className="text-[13px] font-semibold text-foreground">百融云创</p>
                  <p className="text-[11px] text-muted-foreground">bairong.com</p>
                </div>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      aria-label="添加子部门"
                      onClick={() => console.log("添加子部门")}
                    >
                      <Plus className="size-[14px]" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="right" sideOffset={6}>添加子部门</TooltipContent>
                </Tooltip>
              </div>
            }
          >
            {MOCK_DEPTS.map(dept => (
              <SubNavItem
                key={dept.id}
                selected={selectedDept === dept.id}
                onSelect={() => {
                  setSelectedDept(dept.id)
                  setSelectedKeys(new Set())
                }}
                count={dept.memberCount}
                actions={
                  dept.id !== "all"
                    ? [
                        {
                          icon: <Trash2 className="size-[11px]" />,
                          label: "删除部门",
                          onClick: () => console.log("删除部门", dept.id),
                          destructive: true,
                        },
                      ]
                    : undefined
                }
              >
                {dept.name}
              </SubNavItem>
            ))}
          </SubNav>

          {/* ── 成员列表 ── */}
          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto overscroll-none bg-card"
          >
            <div className="flex flex-col gap-[var(--space-5)] px-[var(--space-6)] py-[var(--space-5)]">

              {/* 顶部工具栏：选中 > 0 时由 TableSelectionBar 覆盖 */}
              {selectedKeys.size > 0 ? (
                <TableSelectionBar
                  count={selectedKeys.size}
                  onCancel={() => setSelectedKeys(new Set())}
                  actions={
                    <>
                      <Button variant="ghost" size="sm" className="hover:bg-transparent hover:text-primary">
                        移动到部门
                      </Button>
                      <Button variant="ghost" size="sm" className="hover:bg-transparent hover:text-destructive">
                        批量移除
                      </Button>
                    </>
                  }
                />
              ) : (
                <div className="flex items-center gap-[var(--space-3)]">
                  <SearchInput
                    placeholder="搜索姓名或邮箱"
                    className="w-[240px]"
                    onSearch={setQ}
                  />
                  <Select value={groupFilter} onValueChange={setGroupFilter}>
                    <SelectTrigger className="w-[120px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部用户组</SelectItem>
                      <SelectItem value="dev">开发团队</SelectItem>
                      <SelectItem value="product">产品团队</SelectItem>
                      <SelectItem value="arch">架构组</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[100px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部状态</SelectItem>
                      <SelectItem value="active">正常</SelectItem>
                      <SelectItem value="disabled">禁用</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="flex-1" />
                  <span className="text-[12px] text-muted-foreground">
                    {filtered.length} 位成员
                  </span>
                </div>
              )}

              {/* 表格 */}
              <Table className="table-fixed">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40px]">
                      <Checkbox
                        size="sm"
                        checked={allSelected}
                        data-state={someSelected ? "indeterminate" : undefined}
                        onCheckedChange={checked => {
                          if (checked) setSelectedKeys(new Set(filtered.map(m => m.id)))
                          else setSelectedKeys(new Set())
                        }}
                      />
                    </TableHead>
                    <TableHead className="w-[25%]">成员</TableHead>
                    <TableHead className="w-[12%]">所属部门</TableHead>
                    <TableHead className="w-[18%]">用户组</TableHead>
                    <TableHead className="w-[12%]">角色</TableHead>
                    <TableHead className="w-[8%]">状态</TableHead>
                    <TableHead className="w-[12%]">加入时间</TableHead>
                    <TableHead className="w-[8%]">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map(row => (
                    <TableRow key={row.id}>
                      <TableCell className="w-[40px]">
                        <Checkbox
                          size="sm"
                          checked={selectedKeys.has(row.id)}
                          onCheckedChange={() => toggleRow(row.id)}
                        />
                      </TableCell>

                      {/* 成员 */}
                      <TableCell>
                        <div className="flex items-center gap-[var(--space-2)]">
                          <Avatar size="sm">
                            <AvatarFallback>{row.name[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="text-[12px] font-medium text-foreground">
                              {row.name}
                            </div>
                            <div className="text-[11px] text-muted-foreground">
                              {row.email}
                            </div>
                          </div>
                        </div>
                      </TableCell>

                      {/* 所属部门 */}
                      <TableCell>
                        <span className="text-[12px] text-foreground">{row.deptName}</span>
                      </TableCell>

                      {/* 用户组 */}
                      <TableCell>
                        {row.groups.length > 0 ? (
                          <div className="flex flex-wrap gap-[var(--space-1)]">
                            {row.groups.map(g => (
                              <Badge key={g.id} variant="secondary" size="sm">
                                {g.name}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <span className="text-[12px] text-muted-foreground">—</span>
                        )}
                      </TableCell>

                      {/* 角色 */}
                      <TableCell>
                        {row.roles.map(r => (
                          <Badge key={r.id} variant="outline" size="sm">
                            {r.name}
                          </Badge>
                        ))}
                      </TableCell>

                      {/* 状态 */}
                      <TableCell>
                        {row.status === "active" ? (
                          <Badge variant="success" size="sm">正常</Badge>
                        ) : (
                          <Badge variant="secondary" size="sm">禁用</Badge>
                        )}
                      </TableCell>

                      {/* 加入时间 */}
                      <TableCell>
                        <span className="text-[12px] text-foreground">{row.joinedAt}</span>
                      </TableCell>

                      {/* 操作 */}
                      <TableCell>
                        <button className="text-[12px] text-foreground transition-colors hover:text-primary">
                          编辑
                        </button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

            </div>
          </div>
        </div>
      </div>

      {/* ── 邀请成员对话框 ── */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent className="max-w-[440px]">
          <DialogHeader>
            <DialogTitle>邀请成员</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-[var(--space-4)]">
            <div className="flex flex-col gap-[var(--space-1_5)]">
              <label className="text-[12px] font-medium text-foreground">邮箱地址</label>
              <Input placeholder="输入邮箱，多个用逗号分隔" />
              <p className="text-[11px] text-muted-foreground">
                被邀请人将收到邮件邀请链接
              </p>
            </div>
            <div className="flex flex-col gap-[var(--space-1_5)]">
              <label className="text-[12px] font-medium text-foreground">所属部门</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="选择部门" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tech">技术部</SelectItem>
                  <SelectItem value="product">产品部</SelectItem>
                  <SelectItem value="ops">运营部</SelectItem>
                  <SelectItem value="mkt">市场部</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-[var(--space-1_5)]">
              <label className="text-[12px] font-medium text-foreground">分配角色</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="选择角色（可选）" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">管理员</SelectItem>
                  <SelectItem value="dev">开发者</SelectItem>
                  <SelectItem value="pm">产品经理</SelectItem>
                  <SelectItem value="ops-role">运营专员</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setInviteOpen(false)}>
              取消
            </Button>
            <Button size="sm">发送邀请</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
    </TooltipProvider>
  )
}
