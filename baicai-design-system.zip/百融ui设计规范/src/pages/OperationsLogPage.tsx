import * as React from "react"
import {
  AlertCircle,
  Bell,
  Briefcase,
  Code2,
  Database,
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  Link,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Scale,
  Settings,
  User,
  Users,
} from "lucide-react"

import { Alert, AlertDescription, AlertClose } from "@/components/alert"
import { Avatar, AvatarFallback } from "@/components/avatar"
import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { SystemNav } from "./SystemNav"
import { TopPageBar, PageTitleHeader } from "@/components/top-page-bar"
import { SearchInput } from "@/components/search-input"
import { Button } from "@/components/button"
import { Badge, type BadgeProps } from "@/components/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/table"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/sheet"
import { cn } from "@/lib/utils"

// ─── Types ────────────────────────────────────────────────────────────────────

interface AuditLog {
  id: string
  username: string
  user_email?: string
  actor_type: "user" | "system" | "cron"
  action: "create" | "update" | "delete" | "export" | "login_fail" | "revoke"
  resource_type: "member" | "role" | "permission" | "session"
  resource_name: string
  request_ip: string
  geo: string
  status_code: number
  risk_flags: string[]
  created_at: string
  description: string
  request_method: string
  request_path: string
  request_id: string
  user_agent: string
  diff: { field: string; before: unknown; after: unknown }[]
}

// ─── Constants ────────────────────────────────────────────────────────────────

const ACTION_CONFIG: Record<
  AuditLog["action"],
  { label: string; variant: BadgeProps["variant"] }
> = {
  create:     { label: "创建",   variant: "success" },
  update:     { label: "修改",   variant: "info" },
  delete:     { label: "删除",   variant: "destructive" },
  export:     { label: "导出",   variant: "secondary" },
  login_fail: { label: "登录失败", variant: "warning" },
  revoke:     { label: "撤销",   variant: "warning" },
}

const RESOURCE_TYPE_LABELS: Record<AuditLog["resource_type"], string> = {
  member:     "成员",
  role:       "角色",
  permission: "权限",
  session:    "会话",
}

// ─── Mock Data ────────────────────────────────────────────────────────────────

const MOCK_LOGS: AuditLog[] = [
  {
    id: "evt_01",
    username: "张三",
    user_email: "zhangsan@br.com",
    actor_type: "user",
    action: "create",
    resource_type: "member",
    resource_name: "李华",
    request_ip: "10.0.1.5",
    geo: "上海",
    status_code: 200,
    risk_flags: [],
    created_at: "2026-05-25 09:12:33",
    description: "创建成员账户",
    request_method: "POST",
    request_path: "/api/portal/members",
    request_id: "req_a1b2c3",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X) Chrome/124",
    diff: [
      { field: "name",  before: null, after: "李华" },
      { field: "email", before: null, after: "lihua@example.com" },
      { field: "role",  before: null, after: "普通成员" },
    ],
  },
  {
    id: "evt_02",
    username: "张三",
    user_email: "zhangsan@br.com",
    actor_type: "user",
    action: "update",
    resource_type: "role",
    resource_name: "HR专员",
    request_ip: "10.0.1.5",
    geo: "上海",
    status_code: 200,
    risk_flags: [],
    created_at: "2026-05-25 09:04:17",
    description: "修改角色权限配置",
    request_method: "PUT",
    request_path: "/api/portal/roles/r4",
    request_id: "req_b2c3d4",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X) Chrome/124",
    diff: [
      { field: "permissions.recruit.read",   before: true,  after: false },
      { field: "permissions.scout.export",   before: false, after: true },
    ],
  },
  {
    id: "evt_03",
    username: "李四",
    user_email: "lisi@br.com",
    actor_type: "user",
    action: "delete",
    resource_type: "member",
    resource_name: "王刚",
    request_ip: "10.0.1.12",
    geo: "北京",
    status_code: 200,
    risk_flags: ["批量删除"],
    created_at: "2026-05-25 08:55:40",
    description: "批量删除成员账户",
    request_method: "DELETE",
    request_path: "/api/portal/members/bulk",
    request_id: "req_c3d4e5",
    user_agent: "Mozilla/5.0 (Windows NT 10.0; Win64) Edge/124",
    diff: [],
  },
  {
    id: "evt_04",
    username: "system",
    actor_type: "cron",
    action: "export",
    resource_type: "member",
    resource_name: "全量导出",
    request_ip: "127.0.0.1",
    geo: "内部",
    status_code: 200,
    risk_flags: [],
    created_at: "2026-05-25 08:00:00",
    description: "定时全量导出成员数据",
    request_method: "GET",
    request_path: "/api/portal/members/export",
    request_id: "req_d4e5f6",
    user_agent: "CronJob/1.0",
    diff: [],
  },
  {
    id: "evt_05",
    username: "王五",
    user_email: "wangwu@br.com",
    actor_type: "user",
    action: "update",
    resource_type: "permission",
    resource_name: "招聘管理",
    request_ip: "10.0.1.8",
    geo: "广州",
    status_code: 200,
    risk_flags: ["权限提升"],
    created_at: "2026-05-24 18:30:22",
    description: "修改权限策略，新增写权限",
    request_method: "PUT",
    request_path: "/api/portal/permissions/recruit",
    request_id: "req_e5f6a7",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X) Safari/17",
    diff: [
      { field: "write", before: false, after: true },
      { field: "admin", before: false, after: true },
    ],
  },
  {
    id: "evt_06",
    username: "赵六",
    user_email: "zhaoliu@br.com",
    actor_type: "user",
    action: "login_fail",
    resource_type: "session",
    resource_name: "登录失败",
    request_ip: "203.0.113.5",
    geo: "境外",
    status_code: 401,
    risk_flags: ["异地登录"],
    created_at: "2026-05-24 17:12:08",
    description: "密码错误，连续失败 3 次",
    request_method: "POST",
    request_path: "/api/auth/login",
    request_id: "req_f6a7b8",
    user_agent: "Mozilla/5.0 (Unknown Platform) Chrome/124",
    diff: [],
  },
  {
    id: "evt_07",
    username: "陈七",
    user_email: "chenqi@br.com",
    actor_type: "user",
    action: "revoke",
    resource_type: "session",
    resource_name: "林八的会话",
    request_ip: "10.0.1.33",
    geo: "杭州",
    status_code: 200,
    risk_flags: [],
    created_at: "2026-05-24 16:45:55",
    description: "管理员强制下线用户会话",
    request_method: "DELETE",
    request_path: "/api/portal/sessions/jti_lba",
    request_id: "req_a7b8c9",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X) Safari/17",
    diff: [],
  },
  {
    id: "evt_08",
    username: "system",
    actor_type: "system",
    action: "create",
    resource_type: "role",
    resource_name: "外部访客",
    request_ip: "127.0.0.1",
    geo: "内部",
    status_code: 200,
    risk_flags: [],
    created_at: "2026-05-24 14:20:11",
    description: "系统初始化内置角色",
    request_method: "POST",
    request_path: "/api/portal/roles",
    request_id: "req_b8c9d0",
    user_agent: "System/1.0",
    diff: [
      { field: "name", before: null, after: "外部访客" },
      { field: "type", before: null, after: "system" },
    ],
  },
  {
    id: "evt_09",
    username: "林八",
    user_email: "linba@br.com",
    actor_type: "user",
    action: "update",
    resource_type: "member",
    resource_name: "周九",
    request_ip: "10.0.1.44",
    geo: "成都",
    status_code: 200,
    risk_flags: [],
    created_at: "2026-05-24 11:33:48",
    description: "更新成员基本信息",
    request_method: "PUT",
    request_path: "/api/portal/members/m_zhou",
    request_id: "req_c9d0e1",
    user_agent: "Mozilla/5.0 (iPad; CPU OS 17) AppleWebKit Safari",
    diff: [
      { field: "phone",      before: "138****0001", after: "139****0002" },
      { field: "department", before: "研发部",       after: "产品部" },
    ],
  },
  {
    id: "evt_10",
    username: "周九",
    user_email: "zhoujiu@br.com",
    actor_type: "user",
    action: "delete",
    resource_type: "role",
    resource_name: "测试角色",
    request_ip: "10.0.1.55",
    geo: "上海",
    status_code: 200,
    risk_flags: [],
    created_at: "2026-05-24 10:05:29",
    description: "删除自定义角色",
    request_method: "DELETE",
    request_path: "/api/portal/roles/r_test",
    request_id: "req_d0e1f2",
    user_agent: "Mozilla/5.0 (Windows NT 10.0; Win64) Chrome/124",
    diff: [],
  },
  {
    id: "evt_11",
    username: "吴十",
    user_email: "wushi@br.com",
    actor_type: "user",
    action: "export",
    resource_type: "member",
    resource_name: "筛选导出",
    request_ip: "10.0.1.66",
    geo: "北京",
    status_code: 200,
    risk_flags: [],
    created_at: "2026-05-24 09:48:15",
    description: "按条件筛选导出成员列表",
    request_method: "GET",
    request_path: "/api/portal/members/export?dept=tech",
    request_id: "req_e1f2a3",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X) Firefox/125",
    diff: [],
  },
  {
    id: "evt_12",
    username: "system",
    actor_type: "cron",
    action: "update",
    resource_type: "session",
    resource_name: "批量续期",
    request_ip: "127.0.0.1",
    geo: "内部",
    status_code: 500,
    risk_flags: [],
    created_at: "2026-05-24 03:00:02",
    description: "定时任务批量刷新活跃会话令牌失败",
    request_method: "POST",
    request_path: "/api/portal/sessions/refresh-batch",
    request_id: "req_f2a3b4",
    user_agent: "CronJob/1.0",
    diff: [],
  },
]

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatDiffValue(v: unknown): string {
  if (v === null || v === undefined) return "—"
  if (typeof v === "boolean") return v ? "是" : "否"
  return String(v)
}

function ActionBadge({ action, riskFlags = [] }: { action: AuditLog["action"]; riskFlags?: string[] }) {
  const label = ACTION_CONFIG[action].label
  if (riskFlags.length === 0) {
    return <Badge variant="secondary" size="sm">{label}</Badge>
  }
  const variant = "warning"
  return <Badge variant={variant} size="sm">{label}</Badge>
}

function StatusBadge({ code }: { code: number }) {
  if (code >= 200 && code < 300) return <Badge variant="success" size="sm">成功</Badge>
  if (code >= 400 && code < 500) return <Badge variant="warning" size="sm">拒绝</Badge>
  return <Badge variant="destructive" size="sm">错误</Badge>
}

// ─── Detail panel sub-components ──────────────────────────────────────────────

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="mb-[var(--space-2)] text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
      {children}
    </p>
  )
}

function DetailRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-[var(--space-5)] py-[6px]">
      <span className="shrink-0 text-[12px] text-muted-foreground">{label}</span>
      <div className="flex min-w-0 flex-wrap items-center justify-end gap-[var(--space-1)] text-right text-[12px] text-foreground">
        {children}
      </div>
    </div>
  )
}

// ─── OperationsLogPage ────────────────────────────────────────────────────────

export function OperationsLogPage() {
  const [q, setQ] = React.useState("")
  const [timeRange, setTimeRange] = React.useState("7d")
  const [actionFilter, setActionFilter] = React.useState("all")
  const [resourceTypeFilter, setResourceTypeFilter] = React.useState("all")
  const [riskFilter, setRiskFilter] = React.useState("all")
  const [selectedLog, setSelectedLog] = React.useState<AuditLog | null>(null)
  const [riskBannerDismissed, setRiskBannerDismissed] = React.useState(false)
  const [barElevated, setBarElevated] = React.useState(false)
  const scrollRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => setBarElevated(el.scrollTop > 0)
    el.addEventListener("scroll", onScroll, { passive: true })
    return () => el.removeEventListener("scroll", onScroll)
  }, [])

  const filtered = React.useMemo(() => {
    return MOCK_LOGS.filter(log => {
      if (timeRange === "today" && !log.created_at.startsWith("2026-05-25")) return false
      if (actionFilter !== "all" && log.action !== actionFilter) return false
      if (resourceTypeFilter !== "all" && log.resource_type !== resourceTypeFilter) return false
      if (riskFilter === "with" && log.risk_flags.length === 0) return false
      if (riskFilter === "none" && log.risk_flags.length > 0) return false
      if (q && ![log.username, log.resource_name].some(v => v.includes(q))) return false
      return true
    })
  }, [q, timeRange, actionFilter, resourceTypeFilter, riskFilter])

  const riskLogs = MOCK_LOGS.filter(l => l.risk_flags.length > 0)
  const riskTypes = [...new Set(MOCK_LOGS.flatMap(l => l.risk_flags))]
  const showRiskBanner = !riskBannerDismissed && riskLogs.length > 0

  return (
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">

      {/* ── NarrowRail ── */}
      <NarrowRail
        logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── WideNav ── */}
      <SystemNav active="operations-log" />

      {/* ── 右侧内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">

        <div ref={scrollRef} className="flex-1 overflow-y-auto overscroll-none bg-card">
          <TopPageBar
            breadcrumb={[
              { icon: <Settings className="size-[14px]" />, label: "系统管理" },
              { label: "操作日志" },
            ]}
            elevated={barElevated}
          />
          <div className="mx-auto flex max-w-[1280px] flex-col gap-[var(--space-4)] px-[var(--space-7)] py-[var(--space-5)] pb-10">

            <PageTitleHeader
              title="操作日志"
              actions={<Button variant="outline" size="sm">导出</Button>}
            />

            {/* ── 风险横幅 ── */}
            {showRiskBanner && (
              <Alert variant="warning">
                <AlertCircle />
                <AlertDescription>
                  检测到 {riskLogs.length} 条高风险操作（{riskTypes.join(" · ")}），建议及时排查
                </AlertDescription>
                <AlertClose onClick={() => setRiskBannerDismissed(true)} />
              </Alert>
            )}

            {/* ── 过滤栏 ── */}
            <div className="flex items-center gap-[var(--space-3)]">
              <SearchInput
                placeholder="搜索用户名或资源名"
                className="w-[220px]"
                onSearch={setQ}
              />
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-[100px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">今天</SelectItem>
                  <SelectItem value="7d">近 7 天</SelectItem>
                  <SelectItem value="30d">近 30 天</SelectItem>
                </SelectContent>
              </Select>
              <Select value={actionFilter} onValueChange={setActionFilter}>
                <SelectTrigger className="w-[110px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部操作</SelectItem>
                  <SelectItem value="create">创建</SelectItem>
                  <SelectItem value="update">修改</SelectItem>
                  <SelectItem value="delete">删除</SelectItem>
                  <SelectItem value="export">导出</SelectItem>
                  <SelectItem value="login_fail">登录失败</SelectItem>
                  <SelectItem value="revoke">撤销</SelectItem>
                </SelectContent>
              </Select>
              <Select value={resourceTypeFilter} onValueChange={setResourceTypeFilter}>
                <SelectTrigger className="w-[110px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部对象</SelectItem>
                  <SelectItem value="member">成员</SelectItem>
                  <SelectItem value="role">角色</SelectItem>
                  <SelectItem value="permission">权限</SelectItem>
                  <SelectItem value="session">会话</SelectItem>
                </SelectContent>
              </Select>
              <Select value={riskFilter} onValueChange={setRiskFilter}>
                <SelectTrigger className="w-[100px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部风险</SelectItem>
                  <SelectItem value="with">有风险</SelectItem>
                  <SelectItem value="none">无风险</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex-1" />
              <span className="text-[13px] text-muted-foreground">共 {filtered.length} 条记录</span>
            </div>

            {/* ── 表格 ── */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>时间</TableHead>
                  <TableHead>操作人</TableHead>
                  <TableHead>操作</TableHead>
                  <TableHead>对象</TableHead>
                  <TableHead>风险标记</TableHead>
                  <TableHead>来源</TableHead>
                  <TableHead className="text-right">状态</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody className="[&_td]:py-[var(--space-3)]">
                {filtered.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="py-[var(--space-8)] text-center text-[13px] text-muted-foreground">
                      暂无符合条件的记录
                    </TableCell>
                  </TableRow>
                ) : (
                  filtered.map(log => (
                    <TableRow
                      key={log.id}
                      className="cursor-pointer"
                      onClick={() => setSelectedLog(log)}
                    >
                      <TableCell className="text-[12px] text-muted-foreground">
                        {log.created_at}
                      </TableCell>

                      <TableCell>
                        {log.actor_type === "user" ? (
                          <div className="flex items-center gap-[var(--space-2)]">
                            <Avatar size="sm">
                              <AvatarFallback>{log.username[0]}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-[13px] text-foreground">{log.username}</p>
                              {log.user_email && (
                                <p className="text-[12px] text-muted-foreground">{log.user_email}</p>
                              )}
                            </div>
                          </div>
                        ) : (
                          <span className="text-[13px] text-muted-foreground">
                            {log.actor_type === "cron" ? "定时任务" : "系统"}
                          </span>
                        )}
                      </TableCell>

                      <TableCell>
                        <ActionBadge action={log.action} riskFlags={log.risk_flags} />
                      </TableCell>

                      <TableCell>
                        <span className="text-[13px] text-foreground">
                          <span className="text-muted-foreground">{RESOURCE_TYPE_LABELS[log.resource_type]} · </span>
                          {log.resource_name}
                        </span>
                      </TableCell>

                      <TableCell>
                        {log.risk_flags.length > 0 ? (
                          <div className="flex flex-wrap gap-[var(--space-1)]">
                            {log.risk_flags.map((flag, i) => (
                              <Badge key={i} variant="warning" size="sm">{flag}</Badge>
                            ))}
                          </div>
                        ) : (
                          <span className="text-[12px] text-muted-foreground">—</span>
                        )}
                      </TableCell>

                      <TableCell>
                        <span className={cn(
                          "text-[13px]",
                          log.risk_flags.includes("异地登录") ? "text-destructive" : "text-foreground"
                        )}>
                          {log.request_ip}
                        </span>
                        <span className="text-[12px] text-muted-foreground"> · {log.geo}</span>
                      </TableCell>

                      <TableCell className="text-right">
                        <StatusBadge code={log.status_code} />
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>

          </div>
        </div>
      </div>

      {/* ── 详情面板 ── */}
      <Sheet open={!!selectedLog} onOpenChange={(open) => { if (!open) setSelectedLog(null) }}>
        <SheetContent side="right" className="flex flex-col gap-0 overflow-y-hidden p-0">
          {selectedLog && (
            <>
              {/* 面板标题 */}
              <SheetHeader className="shrink-0 border-b border-border px-[var(--space-5)] pb-[var(--space-4)] pt-[var(--space-5)] pr-14">
                <div className="flex items-center gap-[var(--space-2)]">
                  <ActionBadge action={selectedLog.action} riskFlags={selectedLog.risk_flags} />
                  <SheetTitle className="text-[15px] font-semibold leading-snug">
                    {selectedLog.description}
                  </SheetTitle>
                </div>
                <SheetDescription className="text-[12px]">
                  {selectedLog.created_at}
                </SheetDescription>
              </SheetHeader>

              {/* 面板内容（可滚动）*/}
              <div className="flex-1 overflow-y-auto overscroll-none">

                {/* 操作摘要 */}
                <div className="border-b border-border px-[var(--space-5)] py-[var(--space-4)]">
                  <SectionLabel>操作摘要</SectionLabel>
                  <div className="divide-y divide-border">
                    <DetailRow label="操作人">
                      {selectedLog.actor_type === "user"
                        ? selectedLog.username
                        : selectedLog.actor_type === "cron"
                          ? "定时任务"
                          : "系统"}
                    </DetailRow>
                    <DetailRow label="操作类型">
                      <ActionBadge action={selectedLog.action} riskFlags={selectedLog.risk_flags} />
                    </DetailRow>
                    <DetailRow label="对象类型">
                      {RESOURCE_TYPE_LABELS[selectedLog.resource_type]}
                    </DetailRow>
                    <DetailRow label="对象名称">{selectedLog.resource_name}</DetailRow>
                    <DetailRow label="状态">
                      <StatusBadge code={selectedLog.status_code} />
                      <span className="text-[12px] text-muted-foreground">{selectedLog.status_code}</span>
                    </DetailRow>
                  </div>
                </div>

                {/* 请求信息 */}
                <div className={cn(
                  "px-[var(--space-5)] py-[var(--space-4)]",
                  (selectedLog.diff.length > 0 || selectedLog.risk_flags.length > 0) && "border-b border-border"
                )}>
                  <SectionLabel>请求信息</SectionLabel>
                  <div className="divide-y divide-border">
                    <DetailRow label="方法 / 路径">
                      <span className="break-all font-mono text-[11px]">
                        {selectedLog.request_method} {selectedLog.request_path}
                      </span>
                    </DetailRow>
                    <DetailRow label="来源 IP">
                      {selectedLog.request_ip}
                      <span className="text-muted-foreground">({selectedLog.geo})</span>
                    </DetailRow>
                    <DetailRow label="Request ID">
                      <span className="font-mono text-[11px]">{selectedLog.request_id}</span>
                    </DetailRow>
                    <DetailRow label="User-Agent">
                      <span className="break-all text-[11px] text-muted-foreground">
                        {selectedLog.user_agent}
                      </span>
                    </DetailRow>
                  </div>
                </div>

                {/* 变更详情 */}
                {selectedLog.diff.length > 0 && (
                  <div className={cn(
                    "px-[var(--space-5)] py-[var(--space-4)]",
                    selectedLog.risk_flags.length > 0 && "border-b border-border"
                  )}>
                    <SectionLabel>变更详情</SectionLabel>
                    <div className="overflow-hidden rounded-[var(--corner-md)] border border-border">
                      <table className="w-full text-[12px]">
                        <thead>
                          <tr className="border-b border-border bg-background">
                            <th className="px-[var(--space-3)] py-[var(--space-2)] text-left font-semibold text-muted-foreground">字段</th>
                            <th className="px-[var(--space-3)] py-[var(--space-2)] text-left font-semibold text-muted-foreground">变更前</th>
                            <th className="px-[var(--space-3)] py-[var(--space-2)] text-left font-semibold text-muted-foreground">变更后</th>
                          </tr>
                        </thead>
                        <tbody>
                          {selectedLog.diff.map((d, i) => (
                            <tr key={i} className="border-b border-border last:border-0">
                              <td className="px-[var(--space-3)] py-[var(--space-2)] font-mono text-foreground">{d.field}</td>
                              <td className="px-[var(--space-3)] py-[var(--space-2)] text-muted-foreground">{formatDiffValue(d.before)}</td>
                              <td className="px-[var(--space-3)] py-[var(--space-2)] text-foreground">{formatDiffValue(d.after)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* 风险标记 */}
                {selectedLog.risk_flags.length > 0 && (
                  <div className="px-[var(--space-5)] py-[var(--space-4)]">
                    <SectionLabel>风险标记</SectionLabel>
                    <div className="flex flex-wrap gap-[var(--space-2)]">
                      {selectedLog.risk_flags.map((flag, i) => (
                        <Badge key={i} variant="warning">{flag}</Badge>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

    </div>
  )
}
