import * as React from "react"
import {
  Bell,
  Briefcase,
  Building2,
  CircleCheck,
  ClipboardCheck,
  ClipboardList,
  Code2,
  Database,
  FileText,
  LayoutDashboard,
  MapPin,
  Send,
  Settings,
  User,
  UserPlus,
  Users,
  Workflow,
  type LucideIcon,
} from "lucide-react"

import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { WideNav, WideNavHeader, NavGroup, NavItem } from "@/components/wide-nav"
import { TopPageBar, PageTitleHeader } from "@/components/top-page-bar"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/card"
import { KpiCard } from "@/components/kpi-card"
import { TrendComboChart } from "@/components/trend-combo-chart"
import { FunnelBars } from "@/components/funnel-bars"
import { ChannelDonut } from "@/components/channel-donut"
import { TooltipProvider } from "@/components/tooltip"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"
import { cn } from "@/lib/utils"

// ─── Mock 数据 ────────────────────────────────────────────────────────────────

// 招聘趋势：分组柱（投递/面试/入职数）+ 面试通过率折线（右轴 %）
type TrendPoint = {
  month: string
  applied: number
  interview: number
  hired: number
  rate: number
}

// 招聘趋势按日期范围切换的数据集（滚动回看，截至今日）
// 近 7 天 → 按日（日期）；近 1 个月 → 按周（周结束日期）；近 3/6 个月 → 按月
const TREND_BY_RANGE: Record<string, TrendPoint[]> = {
  "7d": [
    { month: "05-22", applied: 38, interview: 12, hired: 3, rate: 24 },
    { month: "05-23", applied: 45, interview: 15, hired: 2, rate: 30 },
    { month: "05-24", applied: 41, interview: 13, hired: 4, rate: 28 },
    { month: "05-25", applied: 52, interview: 18, hired: 3, rate: 33 },
    { month: "05-26", applied: 48, interview: 16, hired: 5, rate: 30 },
    { month: "05-27", applied: 22, interview: 7,  hired: 1, rate: 26 },
    { month: "05-28", applied: 19, interview: 6,  hired: 2, rate: 28 },
  ],
  "1m": [
    { month: "05-07", applied: 142, interview: 48, hired: 12, rate: 24 },
    { month: "05-14", applied: 168, interview: 55, hired: 15, rate: 28 },
    { month: "05-21", applied: 155, interview: 52, hired: 13, rate: 26 },
    { month: "05-28", applied: 196, interview: 66, hired: 17, rate: 33 },
  ],
  "3m": [
    { month: "3月", applied: 210, interview: 71, hired: 20, rate: 27 },
    { month: "4月", applied: 196, interview: 66, hired: 17, rate: 31 },
    { month: "5月", applied: 248, interview: 84, hired: 23, rate: 34 },
  ],
  "6m": [
    { month: "12月", applied: 185, interview: 62, hired: 18, rate: 16 },
    { month: "1月",  applied: 142, interview: 48, hired: 12, rate: 20 },
    { month: "2月",  applied: 168, interview: 55, hired: 15, rate: 19 },
    { month: "3月",  applied: 210, interview: 71, hired: 20, rate: 27 },
    { month: "4月",  applied: 196, interview: 66, hired: 17, rate: 31 },
    { month: "5月",  applied: 248, interview: 84, hired: 23, rate: 34 },
  ],
}

// 全局日期范围选项（页头筛选器，驱动整页数据）
const DATE_RANGES = [
  { key: "7d", label: "近 7 天" },
  { key: "1m", label: "近 1 个月" },
  { key: "3m", label: "近 3 个月" },
  { key: "6m", label: "近 6 个月" },
] as const

type FunnelStage = { key: string; label: string; value: number }

const FUNNEL_BY_RANGE: Record<string, FunnelStage[]> = {
  "7d": [
    { key: "applied",   label: "简历投递", value: 38 },
    { key: "screened",  label: "初筛通过", value: 21 },
    { key: "interview", label: "面试邀约", value: 12 },
    { key: "offer",     label: "Offer",   value: 4  },
    { key: "hired",     label: "成功入职", value: 1  },
  ],
  "1m": [
    { key: "applied",   label: "简历投递", value: 248 },
    { key: "screened",  label: "初筛通过", value: 128 },
    { key: "interview", label: "面试邀约", value: 84  },
    { key: "offer",     label: "Offer",   value: 23  },
    { key: "hired",     label: "成功入职", value: 6   },
  ],
  "3m": [
    { key: "applied",   label: "简历投递", value: 654 },
    { key: "screened",  label: "初筛通过", value: 338 },
    { key: "interview", label: "面试邀约", value: 210 },
    { key: "offer",     label: "Offer",   value: 58  },
    { key: "hired",     label: "成功入职", value: 14  },
  ],
  "6m": [
    { key: "applied",   label: "简历投递", value: 1149 },
    { key: "screened",  label: "初筛通过", value: 592  },
    { key: "interview", label: "面试邀约", value: 388  },
    { key: "offer",     label: "Offer",   value: 96   },
    { key: "hired",     label: "成功入职", value: 23   },
  ],
}

const SOURCE_BY_RANGE: Record<string, { source: string; count: number }[]> = {
  "7d": [
    { source: "BOSS直聘", count: 18 },
    { source: "内推",     count: 9  },
    { source: "猎头",     count: 6  },
    { source: "智联",     count: 4  },
    { source: "校招",     count: 1  },
  ],
  "1m": [
    { source: "BOSS直聘", count: 96 },
    { source: "内推",     count: 58 },
    { source: "猎头",     count: 42 },
    { source: "智联",     count: 35 },
    { source: "校招",     count: 17 },
  ],
  "3m": [
    { source: "BOSS直聘", count: 280 },
    { source: "内推",     count: 165 },
    { source: "猎头",     count: 120 },
    { source: "智联",     count: 98  },
    { source: "校招",     count: 44  },
  ],
  "6m": [
    { source: "BOSS直聘", count: 520 },
    { source: "内推",     count: 310 },
    { source: "猎头",     count: 228 },
    { source: "智联",     count: 180 },
    { source: "校招",     count: 92  },
  ],
}

// 最近动态：活动流。图标/配色按「业务阶段组」划分（详见 docs/dashboard-activity-logic.md）
// 阶段组：resume(投递/初筛 灰) · interview(面试/评价/推进 蓝) · result(Offer/入职 绿)
type ActivityType =
  | "applied" | "screen"            // 简历组
  | "interview" | "evaluate" | "advance"  // 面试组
  | "offer" | "onboard"             // 结果组

type ActivityGroup = "resume" | "interview" | "result"

const ACTIVITY_GROUP: Record<ActivityType, ActivityGroup> = {
  applied: "resume",
  screen: "resume",
  interview: "interview",
  evaluate: "interview",
  advance: "interview",
  offer: "result",
  onboard: "result",
}

// 阶段组 → 图标 + 配色（灰 → 蓝 → 绿，由浅入深表达推进）
const GROUP_STYLE: Record<
  ActivityGroup,
  { Icon: LucideIcon; bg: string; fg: string }
> = {
  resume: { Icon: FileText, bg: "bg-secondary", fg: "text-muted-foreground" },
  interview: { Icon: ClipboardCheck, bg: "bg-info-soft", fg: "text-info" },
  result: { Icon: CircleCheck, bg: "bg-success-soft", fg: "text-success" },
}

const RECENT_ACTIVITIES: {
  id: number
  name: string
  action: string
  role: string
  stage?: string
  time: string
  type: ActivityType
}[] = [
  { id: 1, name: "Jerome Bell",    action: "完成了面试评价", role: "产品经理",       stage: "二面", time: "2 分钟前",  type: "evaluate" },
  { id: 2, name: "Annette Black",  action: "推进了候选人",   role: "高级前端工程师", stage: "一面", time: "15 分钟前", type: "advance" },
  { id: 3, name: "Onyama Limba",   action: "安排了面试",     role: "数据分析师",     stage: "一面", time: "30 分钟前", type: "interview" },
  { id: 4, name: "Courtney Henry", action: "发起了 Offer",   role: "后端开发工程师",               time: "1 小时前",  type: "offer" },
  { id: 5, name: "Dianne Russell", action: "候选人入职",     role: "市场专员",                     time: "2 小时前",  type: "onboard" },
]


// KPI 玻璃卡（固定「本月」口径，统一样式，不带筛选）
// rows：hover「数据对比」气泡的真实数值表（本月基准 + 上月/去年同期及其增量）
// series：6 个月真实序列，供卡面迷你柱图 + 气泡带刻度趋势复用
const KPI_CARDS = [
  {
    label: "本月简历投递", value: "248", trend: "+12%", trendDir: "up", note: "较上月", icon: Send, extra: "近 6 月峰值 248（5月）· 均值 192",
    rows: [
      { label: "本月", value: "248" },
      { label: "上月", value: "221", delta: "+27", pct: "+12%" },
      { label: "去年同期", value: "210", delta: "+38", pct: "+18%" },
    ],
    series: [185, 142, 168, 210, 196, 248],
  },
  {
    label: "在招职位数", value: "18", trend: "+5", trendDir: "up", note: "本月新开", icon: Briefcase, extra: "目标 20 · 缺口 2",
    rows: [
      { label: "本月", value: "18" },
      { label: "上月", value: "13", delta: "+5", pct: "+38%" },
      { label: "去年同期", value: "15", delta: "+3", pct: "+20%" },
    ],
    series: [12, 13, 14, 15, 16, 18],
  },
  {
    label: "面试通过率", value: "34%", trend: "+5%", trendDir: "up", note: "较上月", icon: CircleCheck, extra: "行业基准 28%",
    rows: [
      { label: "本月", value: "34%" },
      { label: "上月", value: "32.4%", delta: "+1.6pt", pct: "+5%" },
      { label: "去年同期", value: "30.4%", delta: "+3.6pt", pct: "+12%" },
    ],
    series: [28, 30, 29, 32, 31, 34],
  },
  {
    label: "本月入职", value: "6", trend: "75%", trendDir: "none", note: "目标完成率", icon: UserPlus, extra: "目标 8 · 缺口 2",
    rows: [
      { label: "本月", value: "6" },
      { label: "上月", value: "5", delta: "+1", pct: "+20%" },
      { label: "去年同期", value: "4", delta: "+2", pct: "+50%" },
    ],
    series: [3, 4, 5, 4, 6, 6],
  },
] as const

// ─── 招聘趋势：柱 + 折线配置（传给 TrendComboChart）──────────────────────────────
// 简历投递数用 --primary-border 浅紫、面试数用 --info-hover、入职数用 --primary（高亮）
const TREND_BARS = [
  { key: "applied",   label: "简历投递数", color: "var(--primary-border)", gradient: { from: 1, to: 0.55 } },
  { key: "interview", label: "面试数",     color: "var(--info-hover)",     gradient: { from: 1, to: 0.8 } },
  { key: "hired",     label: "入职数",     color: "var(--primary)",        gradient: { from: 0.95, to: 0.5 } },
]
const TREND_LINE = { key: "rate", label: "面试通过率", color: "var(--chart-1)" }

// ─── 招聘渠道配色 ──────────────────────────────────────────────────────────────
// 招聘渠道环形图：品牌色 opacity 阶梯（按占比从高到低，深 → 浅）
const SOURCE_OPACITY = [0.95, 0.78, 0.62, 0.48, 0.36, 0.28]

// 渠道配色：内推用 info 色、校招用浅紫、猎头加深，其余走品牌色阶梯
function sourceSegStyle(source: string, i: number): { fill: string; opacity: number } {
  if (source === "内推") return { fill: "var(--info-hover)", opacity: 1 }
  if (source === "猎头") return { fill: "var(--primary)", opacity: 0.82 }
  if (source === "校招") return { fill: "var(--primary)", opacity: 0.3 }
  return { fill: "var(--primary)", opacity: SOURCE_OPACITY[i] ?? 0.28 }
}

// ─── DashboardPage ────────────────────────────────────────────────────────────

export function DashboardPage() {
  const [barElevated, setBarElevated] = React.useState(false)
  const [trendRange, setTrendRange] = React.useState<string>("6m")
  const [funnelRange, setFunnelRange] = React.useState<string>("1m")
  const [sourceRange, setSourceRange] = React.useState<string>("1m")
  const scrollRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => setBarElevated(el.scrollTop > 0)
    el.addEventListener("scroll", onScroll, { passive: true })
    return () => el.removeEventListener("scroll", onScroll)
  }, [])

  const trendData = TREND_BY_RANGE[trendRange]
  const funnelData = FUNNEL_BY_RANGE[funnelRange]
  const sourceData = SOURCE_BY_RANGE[sourceRange]

  return (
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">

      {/* ── NarrowRail ── */}
      <NarrowRail
        logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" active />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── 二级导航 WideNav（招聘套件）── */}
      <WideNav header={<WideNavHeader title="招聘中心" />}>
        <NavGroup label="工作台">
          <NavItem icon={<LayoutDashboard className="size-[14px]" />} active>数据看板</NavItem>
          <NavItem icon={<ClipboardList className="size-[14px]" />}>任务</NavItem>
        </NavGroup>
        <NavGroup label="招聘管理">
          <NavItem icon={<Building2 className="size-[14px]" />}>公司</NavItem>
          <NavItem icon={<FileText className="size-[14px]" />}>需求</NavItem>
          <NavItem icon={<MapPin className="size-[14px]" />}>岗位</NavItem>
        </NavGroup>
        <NavGroup label="人才">
          <NavItem icon={<User className="size-[14px]" />}>候选人</NavItem>
          <NavItem icon={<Users className="size-[14px]" />}>人才库</NavItem>
        </NavGroup>
        <NavGroup label="配置">
          <NavItem icon={<Workflow className="size-[14px]" />}>招聘流程</NavItem>
          <NavItem icon={<ClipboardCheck className="size-[14px]" />}>评价模板</NavItem>
        </NavGroup>
      </WideNav>

      {/* ── 内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <div ref={scrollRef} className="flex-1 overflow-y-auto overscroll-none bg-card">
          <TopPageBar
            breadcrumb={[
              { icon: <Briefcase className="size-[14px]" />, label: "招聘中心" },
              { label: "数据看板" },
            ]}
            elevated={barElevated}
          />
          <div className="mx-auto flex max-w-[1280px] flex-col gap-[var(--space-5)] px-[var(--space-7)] py-[var(--space-5)] pb-10">

            <PageTitleHeader title="数据看板" />

            {/* ── Row 1: KPI 玻璃卡（统一样式，一排 4 个，hover 弹「数据对比」气泡）── */}
            <TooltipProvider delayDuration={150}>
              <div className="grid grid-cols-4 gap-[var(--space-4)]">
                {KPI_CARDS.map(({ label, value, trend, trendDir, note, icon, rows, series, extra }) => (
                  <KpiCard
                    key={label}
                    label={label}
                    value={value}
                    trend={trend}
                    trendDir={trendDir}
                    note={note}
                    icon={icon}
                    series={series}
                    compare={{ rows, trend: series, extra }}
                  />
                ))}
              </div>
            </TooltipProvider>

            {/* ── Row 2: 趋势 + 漏斗 ── */}
            <div className="grid grid-cols-5 gap-[var(--space-4)]">

              {/* 招聘趋势 */}
              <Card className="col-span-3">
                <CardHeader>
                  <div className="flex items-center justify-between gap-[var(--space-4)]">
                    <CardTitle>招聘趋势</CardTitle>
                    <Select value={trendRange} onValueChange={setTrendRange}>
                      <SelectTrigger className="w-[120px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {DATE_RANGES.map((r) => (
                          <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <TrendComboChart
                    data={trendData}
                    bars={TREND_BARS}
                    line={TREND_LINE}
                    xKey="month"
                    rightDomain={[0, 50]}
                    rightTicks={[0, 10, 20, 30, 40, 50]}
                  />
                </CardContent>
              </Card>

              {/* 招聘漏斗 · 横向条形 */}
              <Card className="col-span-2 flex flex-col">
                <CardHeader>
                  <div className="flex items-center justify-between gap-[var(--space-3)]">
                    <CardTitle>招聘漏斗</CardTitle>
                    <Select value={funnelRange} onValueChange={setFunnelRange}>
                      <SelectTrigger className="w-[100px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {DATE_RANGES.map((r) => (
                          <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent className="flex flex-1 flex-col">
                  <FunnelBars data={funnelData} footer={{ label: "整体转化（投递 → 入职）" }} />
                </CardContent>
              </Card>
            </div>

            {/* ── Row 3: 渠道 + 动态（各占一半）── */}
            <div className="grid grid-cols-2 gap-[var(--space-4)]">

              {/* 渠道来源 */}
              <Card className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center justify-between gap-[var(--space-3)]">
                    <CardTitle>招聘渠道</CardTitle>
                    <Select value={sourceRange} onValueChange={setSourceRange}>
                      <SelectTrigger className="w-[100px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {DATE_RANGES.map((r) => (
                          <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent className="flex flex-1 items-center justify-evenly">
                  <ChannelDonut
                    valueLabel="候选人数"
                    data={sourceData.map((d, i) => {
                      const s = sourceSegStyle(d.source, i)
                      return {
                        label: d.source,
                        value: d.count,
                        color: s.fill,
                        opacity: s.opacity,
                        dotColor: d.source === "内推" ? "var(--info-hover)" : "var(--primary)",
                      }
                    })}
                  />
                </CardContent>
              </Card>

              {/* 最近动态 · 活动流列表 */}
              <Card className="flex flex-col">
                <CardHeader>
                  <CardTitle>最近动态</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-1 flex-col justify-center gap-[var(--space-4)]">
                  {RECENT_ACTIVITIES.map((a) => {
                    const g = GROUP_STYLE[ACTIVITY_GROUP[a.type]]
                    return (
                    <div
                      key={a.id}
                      className="grid items-center gap-[var(--space-4)]"
                      style={{ gridTemplateColumns: "28px minmax(0,1.4fr) minmax(0,1fr) auto" }}
                    >
                      <div className={cn("flex size-7 shrink-0 items-center justify-center rounded-[var(--corner-md)]", g.bg)}>
                        <g.Icon className={cn("size-[15px]", g.fg)} />
                      </div>
                      <div className="truncate text-[13px]">
                        <span className="font-semibold text-foreground">{a.name}</span>
                        <span className="ml-[var(--space-2)] text-muted-foreground">{a.action}</span>
                      </div>
                      <div className="truncate text-[12px] text-muted-foreground">
                        {a.role}{a.stage ? ` · ${a.stage}` : ""}
                      </div>
                      <span className="justify-self-end text-[12px] text-muted-foreground">{a.time}</span>
                    </div>
                    )
                  })}
                </CardContent>
              </Card>
            </div>

          </div>
        </div>
      </div>
    </div>
  )
}
