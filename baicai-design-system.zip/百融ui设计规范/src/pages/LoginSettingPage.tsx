import * as React from "react"
import {
  Bell,
  Briefcase,
  Building2,
  ClipboardList,
  Clock,
  Code2,
  Database,
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  Link,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Network,
  Scale,
  Settings,
  ShieldCheck,
  User,
  Users,
} from "lucide-react"

import { Button } from "@/components/button"
import { Switch } from "@/components/switch"
import { Textarea } from "@/components/textarea"
import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { SystemNav } from "./SystemNav"
import { TopPageBar, PageTitleHeader } from "@/components/top-page-bar"
import { SettingsCard, FieldRow as BaseFieldRow } from "@/components/settings-card"
import { NumberInput } from "@/components/number-input"
import { ToggleChip } from "@/components/toggle-chip"
import { RadioPill } from "@/components/radio-pill"

// 本页设置项统一右对齐：标签居左、控件靠右（FieldRow split 布局）
function FieldRow(props: React.ComponentProps<typeof BaseFieldRow>) {
  return <BaseFieldRow {...props} layout={props.layout ?? "split"} />
}

// ─── 初始表单状态 ─────────────────────────────────────────────────────────────

const INITIAL = {
  minLength: 8,
  uppercase: true,
  lowercase: true,
  digit: true,
  symbol: false,
  rotationDays: 90,
  historyCount: 5,
  mfaEnabled: false,
  enforceScope: "admin_only" as "all" | "admin_only" | "voluntary",
  mfaMethods: ["totp", "email"] as string[],
  defaultTtl: 24,
  idleTimeout: 30,
  rememberMeDays: 30,
  maxDevices: 5,
  lockoutThreshold: 5,
  lockoutWindow: 30,
  ipWhitelist: "",
  adminOnly: false,
  timeWindow: "all_day" as "all_day" | "workday_09_21" | "custom",
}

const MFA_METHODS = [
  { key: "totp", label: "TOTP 验证器" },
  { key: "sms", label: "短信" },
  { key: "email", label: "邮件" },
  { key: "webauthn", label: "WebAuthn" },
]

// ─── LoginSettingPage ─────────────────────────────────────────────────────────

export function LoginSettingPage() {
  const [s, setS] = React.useState(INITIAL)
  const [isDirty, setIsDirty] = React.useState(false)
  const [saving, setSaving] = React.useState(false)
  const [barElevated, setBarElevated] = React.useState(false)
  const scrollRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => setBarElevated(el.scrollTop > 0)
    el.addEventListener("scroll", onScroll, { passive: true })
    return () => el.removeEventListener("scroll", onScroll)
  }, [])

  function set<K extends keyof typeof INITIAL>(key: K, value: (typeof INITIAL)[K]) {
    setS((prev) => ({ ...prev, [key]: value }))
    setIsDirty(true)
  }

  function handleSave() {
    setSaving(true)
    setTimeout(() => {
      setSaving(false)
      setIsDirty(false)
    }, 600)
  }

  function handleDiscard() {
    setS(INITIAL)
    setIsDirty(false)
  }

  return (
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">

      {/* ── 一级侧导航 NarrowRail 56px ── */}
      <NarrowRail
        logo={
          <img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />
        }
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── 二级侧导航 WideNav 240px ── */}
      <SystemNav active="login-setting" />

      {/* ── 右侧内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">

        {/* 可滚动内容（TopPageBar sticky 于此容器内，内容从其下方穿过实现高斯模糊）*/}
        <div ref={scrollRef} className="flex-1 overflow-y-auto overscroll-none bg-card">
          <TopPageBar
            breadcrumb={[
              { icon: <Settings className="size-[14px]" />, label: "系统管理" },
              { label: "登录设置" },
            ]}
            elevated={barElevated}
          />
          <div className="mx-auto max-w-[1280px] px-[var(--space-7)] py-[var(--space-5)]">

            <PageTitleHeader
              title="登录设置"
              unsaved={isDirty}
              onSave={handleSave}
              onDiscard={handleDiscard}
              className="mb-[var(--space-5)]"
            />

            <div className="flex flex-col gap-5 pb-10">

              {/* ── 密码策略 ── */}
              <SettingsCard title="密码策略">
                <FieldRow label="最小长度" description="密码至少需要包含的字符数，建议 8 位以上">
                  <NumberInput
                    value={s.minLength}
                    onChange={(e) => set("minLength", Number(e.target.value))}
                    unit="位"
                  />
                </FieldRow>

                <FieldRow
                  label="复杂度要求"
                  description="密码必须包含以下类型的字符"
                >
                  <div className="flex flex-wrap gap-4">
                    <ToggleChip checked={s.uppercase} onCheckedChange={(v) => set("uppercase", v)}>大写字母</ToggleChip>
                    <ToggleChip checked={s.lowercase} onCheckedChange={(v) => set("lowercase", v)}>小写字母</ToggleChip>
                    <ToggleChip checked={s.digit} onCheckedChange={(v) => set("digit", v)}>数字</ToggleChip>
                    <ToggleChip checked={s.symbol} onCheckedChange={(v) => set("symbol", v)}>特殊符号</ToggleChip>
                  </div>
                </FieldRow>

                <FieldRow label="密码轮换周期" description="超出周期后强制重置密码，0 表示不限制">
                  <NumberInput
                    value={s.rotationDays}
                    onChange={(e) => set("rotationDays", Number(e.target.value))}
                    unit="天"
                  />
                </FieldRow>

                <FieldRow label="历史密码不重复">
                  <span className="text-[13px] text-foreground">不能与最近</span>
                  <NumberInput
                    value={s.historyCount}
                    onChange={(e) => set("historyCount", Number(e.target.value))}
                    unit="次"
                    unitWidth="w-[32px]"
                  />
                  <span className="text-[13px] text-foreground">密码相同</span>
                </FieldRow>
              </SettingsCard>

              {/* ── 多因素认证 MFA ── */}
              <SettingsCard title="多因素认证（MFA）">
                <FieldRow label="启用 MFA" description="开启后，用户登录时需通过额外验证">
                  <Switch
                    checked={s.mfaEnabled}
                    onCheckedChange={(v) => set("mfaEnabled", v)}
                  />
                  <span className="text-[13px] text-muted-foreground">
                    {s.mfaEnabled ? "已开启" : "已关闭"}
                  </span>
                </FieldRow>

                <FieldRow label="强制范围" description="指定哪些用户必须完成 MFA 验证">
                  <div className="flex flex-wrap gap-4">
                    <RadioPill
                      active={s.enforceScope === "all"}
                      label="全员"
                      onSelect={() => set("enforceScope", "all")}
                    />
                    <RadioPill
                      active={s.enforceScope === "admin_only"}
                      label="仅管理员"
                      onSelect={() => set("enforceScope", "admin_only")}
                    />
                    <RadioPill
                      active={s.enforceScope === "voluntary"}
                      label="自愿"
                      onSelect={() => set("enforceScope", "voluntary")}
                    />
                  </div>
                </FieldRow>

                <FieldRow
                  label="支持方式"
                  description="允许用户选择的 MFA 验证方式"
                >
                  <div className="flex flex-wrap gap-4">
                    {MFA_METHODS.map(({ key, label }) => (
                      <ToggleChip
                        key={key}
                        checked={s.mfaMethods.includes(key)}
                        onCheckedChange={(v) =>
                          set(
                            "mfaMethods",
                            v
                              ? [...s.mfaMethods, key]
                              : s.mfaMethods.filter((m) => m !== key)
                          )
                        }
                      >
                        {label}
                      </ToggleChip>
                    ))}
                  </div>
                </FieldRow>

                <FieldRow label="豁免组" description="这些用户组无需强制完成 MFA">
                  <Button variant="outline" size="sm">+ 添加</Button>
                </FieldRow>
              </SettingsCard>

              {/* ── 会话策略 ── */}
              <SettingsCard title="会话策略">
                <FieldRow label="默认会话时长" description="Token 有效时间，超时后需重新登录，建议 8–24 小时">
                  <NumberInput
                    value={s.defaultTtl}
                    onChange={(e) => set("defaultTtl", Number(e.target.value))}
                    unit="小时"
                    unitWidth="w-[40px]"
                  />
                </FieldRow>

                <FieldRow label="空闲超时" description="超过该时长无操作后自动登出">
                  <NumberInput
                    value={s.idleTimeout}
                    onChange={(e) => set("idleTimeout", Number(e.target.value))}
                    unit="分钟"
                    unitWidth="w-[40px]"
                  />
                </FieldRow>

                <FieldRow label="记住我时长" description="勾选「记住我」后 Token 的有效期">
                  <NumberInput
                    value={s.rememberMeDays}
                    onChange={(e) => set("rememberMeDays", Number(e.target.value))}
                    unit="天"
                  />
                </FieldRow>

                <FieldRow label="最大并发设备" description="同一账号允许同时在线的设备数，0 不限">
                  <NumberInput
                    value={s.maxDevices}
                    onChange={(e) => set("maxDevices", Number(e.target.value))}
                    unit="台"
                  />
                </FieldRow>
              </SettingsCard>

              {/* ── 登录限制 ── */}
              <SettingsCard title="登录限制">
                <FieldRow label="失败锁定">
                  <span className="text-[13px] text-foreground">连续</span>
                  <NumberInput
                    value={s.lockoutThreshold}
                    onChange={(e) => set("lockoutThreshold", Number(e.target.value))}
                    unit="次"
                    unitWidth="w-[32px]"
                  />
                  <span className="text-[13px] text-foreground">失败，锁定</span>
                  <NumberInput
                    value={s.lockoutWindow}
                    onChange={(e) => set("lockoutWindow", Number(e.target.value))}
                    unit="分钟"
                    unitWidth="w-[40px]"
                  />
                </FieldRow>

                <FieldRow
                  label="IP 白名单"
                  description="仅允许列表内 IP 访问，每行一条"
                  className="items-start"
                >
                  <div className="flex w-[360px] flex-col gap-[var(--space-2)]">
                    <Textarea
                      value={s.ipWhitelist}
                      onChange={(e) => set("ipWhitelist", e.target.value)}
                      placeholder={"192.168.1.0/24\n10.0.0.1"}
                      className="min-h-[84px] font-mono text-xs"
                    />
                    <ToggleChip
                      checked={s.adminOnly}
                      onCheckedChange={(v) => set("adminOnly", v)}
                    >
                      仅管理员豁免（白名单对管理员不生效）
                    </ToggleChip>
                  </div>
                </FieldRow>

                <FieldRow label="登录时段" description="限制用户只能在指定时段内登录">
                  <div className="flex flex-wrap gap-4">
                    <RadioPill
                      active={s.timeWindow === "all_day"}
                      label="全天"
                      onSelect={() => set("timeWindow", "all_day")}
                    />
                    <RadioPill
                      active={s.timeWindow === "workday_09_21"}
                      label="工作日 09-21"
                      onSelect={() => set("timeWindow", "workday_09_21")}
                    />
                    <RadioPill
                      active={s.timeWindow === "custom"}
                      label="自定义"
                      onSelect={() => set("timeWindow", "custom")}
                    />
                  </div>
                </FieldRow>
              </SettingsCard>

            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
