import {
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  Link,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Network,
  Scale,
  Settings,
  Users,
  type LucideIcon,
} from "lucide-react"
import { WideNav, WideNavHeader, NavGroup, NavItem } from "@/components/wide-nav"

// 「系统管理」二级侧导航的共享配置。key 与路由 hash 一一对应；
// 8 个 key 有实现页面，6 个 key（idp/departments/user-groups/permissions/permission-policy/notification-template）暂为占位。
type SystemNavEntry = { key: string; label: string; icon: LucideIcon }

const NAV_GROUPS: { label: string; items: SystemNavEntry[] }[] = [
  {
    label: "应用与接入",
    items: [
      { key: "app-center", label: "应用中心", icon: LayoutDashboard },
      { key: "login-setting", label: "登录设置", icon: Lock },
      { key: "idp", label: "身份提供商", icon: Link },
      { key: "sessions", label: "会话管理", icon: Monitor },
    ],
  },
  {
    label: "组织与授权",
    items: [
      { key: "members", label: "成员", icon: Users },
      { key: "departments", label: "部门", icon: Network },
      { key: "user-groups", label: "用户组", icon: Layers },
      { key: "roles", label: "角色", icon: KeyRound },
      { key: "permissions", label: "权限项", icon: List },
      { key: "permission-policy", label: "权限策略", icon: Scale },
    ],
  },
  {
    label: "审计与风险",
    items: [
      { key: "operations-log", label: "操作日志", icon: History },
      { key: "login-log", label: "登录日志", icon: LogIn },
    ],
  },
  {
    label: "租户设置",
    items: [
      { key: "general-settings", label: "通用设置", icon: Settings },
      { key: "notification-template", label: "通知模板", icon: Mail },
    ],
  },
]

/** key → 中文标题，供占位页面包屑 / TopPageBar 使用 */
export const SYSTEM_NAV_TITLES: Record<string, string> = Object.fromEntries(
  NAV_GROUPS.flatMap((g) => g.items.map((i) => [i.key, i.label]))
)

export interface SystemNavProps {
  /** 当前激活的 key（= 路由 hash） */
  active: string
}

/** 系统管理二级导航。点击任意 item 通过 hash 路由切换页面。 */
export function SystemNav({ active }: SystemNavProps) {
  return (
    <WideNav header={<WideNavHeader title="系统管理" />}>
      {NAV_GROUPS.map((group) => (
        <NavGroup key={group.label} label={group.label}>
          {group.items.map((item) => {
            const Icon = item.icon
            return (
              <NavItem
                key={item.key}
                icon={<Icon className="size-[14px]" />}
                active={active === item.key}
                onClick={() => {
                  window.location.hash = item.key
                }}
              >
                {item.label}
              </NavItem>
            )
          })}
        </NavGroup>
      ))}
    </WideNav>
  )
}
