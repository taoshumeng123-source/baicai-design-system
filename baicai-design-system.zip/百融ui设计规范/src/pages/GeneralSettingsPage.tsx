import * as React from "react"
import {
  Bell,
  Briefcase,
  Check,
  Code2,
  Database,
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  Link,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Network,
  Plus,
  RefreshCw,
  Scale,
  Settings,
  Trash2,
  Upload,
  User,
  Users,
} from "lucide-react"

import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { SystemNav } from "./SystemNav"
import { TopPageBar, PageTitleHeader } from "@/components/top-page-bar"
import { SettingsCard, FieldRow as BaseFieldRow } from "@/components/settings-card"
import { Input } from "@/components/input"
import { Textarea } from "@/components/textarea"
import { RadioPill } from "@/components/radio-pill"
import { ToggleChip } from "@/components/toggle-chip"
import { Button } from "@/components/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"

// 本页设置项统一右对齐：标签居左、控件靠右（FieldRow split 布局）
function FieldRow(props: React.ComponentProps<typeof BaseFieldRow>) {
  return <BaseFieldRow {...props} layout={props.layout ?? "split"} />
}

// ─── 选项数据（与基准页 /admin/settings 同步） ────────────────────────────────

type Industry = "internet" | "manufacturing" | "finance" | "education" | "healthcare" | "other"

const INDUSTRY_OPTIONS: { value: Industry; label: string }[] = [
  { value: "internet",      label: "互联网" },
  { value: "manufacturing", label: "制造业" },
  { value: "finance",       label: "金融" },
  { value: "education",     label: "教育" },
  { value: "healthcare",    label: "医疗" },
  { value: "other",         label: "其他" },
]

const TIMEZONE_OPTIONS = [
  "Asia/Shanghai",
  "Asia/Hong_Kong",
  "Asia/Tokyo",
  "Asia/Singapore",
  "Europe/London",
  "America/New_York",
  "America/Los_Angeles",
  "UTC",
]

// 第一个色卡固定为规范品牌色（--primary token）；其余为用户自定义色值。
const BRAND_PRIMARY = "var(--primary)"

// ─── 初始表单状态 ─────────────────────────────────────────────────────────────

const INITIAL = {
  companyName:       "百融云创",
  logoUrl:           null as string | null,
  industry:          "" as Industry | "",
  timezone:          "Asia/Shanghai",

  brandColor:        BRAND_PRIMARY,
  brandColors:       [BRAND_PRIMARY] as string[],
  loginLogoUrl:      null as string | null,
  emailFooter:       "",

  defaultLocale:     "zh-CN" as "zh-CN" | "en-US" | "auto",

  auditRetention:    90 as 30 | 90 | 180 | 365,

  activationChannels: ["sms"] as ("sms" | "email")[],
}

// ─── LogoField：Logo 上传（预览 / 替换 / 移除），复用 Button 与 token ──────────

function LogoField({
  value,
  onChange,
}: {
  value: string | null
  onChange: (v: string | null) => void
}) {
  const inputRef = React.useRef<HTMLInputElement>(null)

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) onChange(URL.createObjectURL(file))
    e.target.value = ""
  }

  return (
    <div className="flex flex-col gap-2">
      <input
        ref={inputRef}
        type="file"
        accept=".png,.jpg,.jpeg,.svg"
        className="hidden"
        onChange={handleFile}
      />

      {value ? (
        <div className="flex items-center gap-3">
          <div className="flex size-[56px] shrink-0 items-center justify-center overflow-hidden rounded-lg border border-border bg-muted">
            <img src={value} alt="logo" className="size-full object-contain" />
          </div>
          <div className="flex gap-2">
            <Button type="button" variant="outline" size="sm" onClick={() => inputRef.current?.click()}>
              <RefreshCw />
              替换
            </Button>
            <Button type="button" variant="ghost" size="sm" onClick={() => onChange(null)}>
              <Trash2 className="text-destructive" />
              移除
            </Button>
          </div>
        </div>
      ) : (
        <Button type="button" variant="outline" size="sm" className="w-fit" onClick={() => inputRef.current?.click()}>
          <Upload />
          上传图片
        </Button>
      )}
    </div>
  )
}

// ─── GeneralSettingsPage ──────────────────────────────────────────────────────

export function GeneralSettingsPage() {
  const [s, setS] = React.useState(INITIAL)
  const [isDirty, setIsDirty] = React.useState(false)
  const [saving, setSaving] = React.useState(false)  // tracks in-flight save
  const [barElevated, setBarElevated] = React.useState(false)
  const scrollRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => setBarElevated(el.scrollTop > 0)
    el.addEventListener("scroll", onScroll, { passive: true })
    return () => el.removeEventListener("scroll", onScroll)
  }, [])

  function set<K extends keyof typeof INITIAL>(key: K, value: (typeof INITIAL)[K]) {
    setS(prev => ({ ...prev, [key]: value }))
    setIsDirty(true)
  }

  // 激活通道：可多选，至少保留一项（取消最后一个时不更新）。
  function toggleChannel(channel: "sms" | "email", checked: boolean) {
    const next = checked
      ? [...s.activationChannels.filter(c => c !== channel), channel]
      : s.activationChannels.filter(c => c !== channel)
    if (next.length === 0) return
    set("activationChannels", next)
  }

  // 主色：添加自定义色值（已存在则仅选中），并设为当前选中。
  function addColor(value: string) {
    setS(prev => ({
      ...prev,
      brandColors: prev.brandColors.includes(value) ? prev.brandColors : [...prev.brandColors, value],
      brandColor: value,
    }))
    setIsDirty(true)
  }

  function handleSave() {
    setSaving(true)
    setTimeout(() => { setSaving(false); setIsDirty(false) }, 600)
  }

  function handleDiscard() {
    setS(INITIAL)
    setIsDirty(false)
  }

  return (
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">

      {/* ── NarrowRail ── */}
      <NarrowRail
        logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── WideNav ── */}
      <SystemNav active="general-settings" />

      {/* ── 右侧内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">

        <div ref={scrollRef} className="flex-1 overflow-y-auto overscroll-none bg-card">
          <TopPageBar
            breadcrumb={[
              { icon: <Settings className="size-[14px]" />, label: "系统管理" },
              { label: "通用设置" },
            ]}
            elevated={barElevated}
          />
          <div className="mx-auto max-w-[1280px] px-[var(--space-7)] py-[var(--space-5)]">
            <PageTitleHeader
              title="通用设置"
              unsaved={isDirty}
              onSave={handleSave}
              onDiscard={handleDiscard}
              className="mb-[var(--space-5)]"
            />
            <div className="flex flex-col gap-5 pb-10">

              {/* ── 租户基本信息 ── */}
              <SettingsCard title="租户基本信息">
                <FieldRow label="企业名称">
                  <Input
                    value={s.companyName}
                    onChange={e => set("companyName", e.target.value)}
                    placeholder="企业名称"
                    maxLength={100}
                    className="w-[320px]"
                  />
                </FieldRow>

                <FieldRow label="企业 Logo" description="支持 PNG/JPG/SVG，不超过 2 MB" className="items-start">
                  <LogoField value={s.logoUrl} onChange={v => set("logoUrl", v)} />
                </FieldRow>

                <FieldRow label="行业">
                  <Select
                    value={s.industry}
                    onValueChange={v => set("industry", v as Industry | "")}
                  >
                    <SelectTrigger className="w-[240px]">
                      <SelectValue placeholder="请选择" />
                    </SelectTrigger>
                    <SelectContent>
                      {INDUSTRY_OPTIONS.map(opt => (
                        <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FieldRow>

                <FieldRow label="时区">
                  <Select value={s.timezone} onValueChange={v => set("timezone", v)}>
                    <SelectTrigger className="w-[240px]">
                      <SelectValue placeholder="请选择时区" />
                    </SelectTrigger>
                    <SelectContent>
                      {TIMEZONE_OPTIONS.map(tz => (
                        <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FieldRow>
              </SettingsCard>

              {/* ── 品牌定制 ── */}
              <SettingsCard title="品牌定制">
                <FieldRow label="主色" description="默认使用规范品牌色，可添加自定义色值" className="items-start">
                  <div className="flex flex-wrap items-center gap-2">
                    {s.brandColors.map(c => {
                      const selected = s.brandColor === c
                      const isBrand = c === BRAND_PRIMARY
                      return (
                        <button
                          key={c}
                          type="button"
                          aria-label={isBrand ? "规范品牌色" : c}
                          aria-pressed={selected}
                          title={isBrand ? "规范品牌色" : c}
                          onClick={() => set("brandColor", c)}
                          className="relative size-8 rounded-[var(--corner-md)] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                          style={{
                            backgroundColor: c,
                            boxShadow: selected ? `0 0 0 2px var(--card), 0 0 0 4px ${c}` : undefined,
                          }}
                        >
                          {selected && (
                            <span className="absolute inset-0 flex items-center justify-center">
                              <Check className="size-4 text-card drop-shadow-sm" />
                            </span>
                          )}
                        </button>
                      )
                    })}

                    {/* 添加自定义色值 */}
                    <label
                      title="添加自定义色值"
                      className="ml-3 flex size-10 cursor-pointer items-center justify-center rounded-[var(--corner-md)] border border-dashed border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                    >
                      <Plus className="size-5" />
                      <input
                        type="color"
                        className="sr-only"
                        onChange={e => addColor(e.target.value)}
                      />
                    </label>
                  </div>
                </FieldRow>

                <FieldRow label="登录页 Logo" description="建议上传白底透明 PNG，不超过 2 MB" className="items-start">
                  <LogoField value={s.loginLogoUrl} onChange={v => set("loginLogoUrl", v)} />
                </FieldRow>

                <FieldRow label="邮件页脚" description="支持 Markdown 链接，最多 500 字符" className="items-start">
                  <Textarea
                    value={s.emailFooter}
                    onChange={e => set("emailFooter", e.target.value)}
                    placeholder="示例：感谢您使用 Acme 招聘平台"
                    maxLength={500}
                    className="w-[360px] min-h-[80px]"
                  />
                </FieldRow>
              </SettingsCard>

              {/* ── 偏好与策略 ── */}
              <SettingsCard title="偏好与策略">
                <FieldRow label="默认语言" description="新用户首次登录时的默认语言">
                  <div className="flex gap-4">
                    <RadioPill
                      active={s.defaultLocale === "zh-CN"}
                      label="简体中文"
                      onSelect={() => set("defaultLocale", "zh-CN")}
                    />
                    <RadioPill
                      active={s.defaultLocale === "en-US"}
                      label="English"
                      onSelect={() => set("defaultLocale", "en-US")}
                    />
                    <RadioPill
                      active={s.defaultLocale === "auto"}
                      label="跟随系统"
                      onSelect={() => set("defaultLocale", "auto")}
                    />
                  </div>
                </FieldRow>

                <FieldRow label="数据保留" description="审计与登录日志保留天数；变更后下次清理作业生效" className="items-start">
                  <div className="flex flex-wrap gap-4">
                    <RadioPill active={s.auditRetention === 30}  label="30 天"        onSelect={() => set("auditRetention", 30)} />
                    <RadioPill active={s.auditRetention === 90}  label="90 天（推荐）" onSelect={() => set("auditRetention", 90)} />
                    <RadioPill active={s.auditRetention === 180} label="180 天"       onSelect={() => set("auditRetention", 180)} />
                    <RadioPill active={s.auditRetention === 365} label="365 天"       onSelect={() => set("auditRetention", 365)} />
                  </div>
                </FieldRow>

                <FieldRow label="激活通知通道" description="邀请新成员的通知通道，可多选、至少一项；按勾选顺序优先，无手机号时跳过 SMS" className="items-start">
                  <div className="flex flex-wrap gap-6">
                    <ToggleChip
                      checked={s.activationChannels.includes("sms")}
                      onCheckedChange={c => toggleChannel("sms", c)}
                    >
                      SMS（短信验证码）
                    </ToggleChip>
                    <ToggleChip
                      checked={s.activationChannels.includes("email")}
                      onCheckedChange={c => toggleChannel("email", c)}
                    >
                      Email（邮件激活链接）
                    </ToggleChip>
                  </div>
                </FieldRow>
              </SettingsCard>

            </div>
          </div>
        </div>
      </div>

    </div>
  )
}
