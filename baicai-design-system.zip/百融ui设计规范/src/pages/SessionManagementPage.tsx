import * as React from "react"
import {
  Bell,
  Briefcase,
  Building2,
  ClipboardList,
  Code2,
  Database,
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  Link,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Network,
  Scale,
  Settings,
  Smartphone,
  Tablet,
  User,
  Users,
} from "lucide-react"

import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { SystemNav } from "./SystemNav"
import { TopPageBar, PageTitleHeader } from "@/components/top-page-bar"
import { SearchInput } from "@/components/search-input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"
import { Button } from "@/components/button"
import { Badge } from "@/components/badge"
import { Avatar, AvatarFallback } from "@/components/avatar"
import { Checkbox } from "@/components/checkbox"
import { StatCard } from "@/components/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableSelectionBar,
} from "@/components/table"
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/dialog"
import { cn } from "@/lib/utils"

// ─── Types ────────────────────────────────────────────────────────────────────

interface SessionItem {
  jti: string
  user_display_name: string
  user_email: string
  device: { os: string; browser: string }
  device_type: "desktop" | "mobile" | "tablet"
  ip: string
  geo: string
  login_at: string
  last_active_at: string
  status: "active" | "idle"
  is_current: boolean
  is_remember_me: boolean
}

// ─── Mock data ─────────────────────────────────────────────────────────────────

const MOCK_SESSIONS: SessionItem[] = [
  {
    jti: "jti-1",
    user_display_name: "张三",
    user_email: "zhangsan@br.com",
    device: { os: "macOS", browser: "Chrome" },
    device_type: "desktop",
    ip: "10.0.1.5",
    geo: "上海",
    login_at: "今天 08:30",
    last_active_at: "刚刚",
    status: "active",
    is_current: true,
    is_remember_me: false,
  },
  {
    jti: "jti-2",
    user_display_name: "李四",
    user_email: "lisi@br.com",
    device: { os: "Windows", browser: "Edge" },
    device_type: "desktop",
    ip: "10.0.1.12",
    geo: "北京",
    login_at: "今天 09:15",
    last_active_at: "3 分钟前",
    status: "active",
    is_current: false,
    is_remember_me: true,
  },
  {
    jti: "jti-3",
    user_display_name: "王五",
    user_email: "wangwu@br.com",
    device: { os: "iOS", browser: "Safari" },
    device_type: "mobile",
    ip: "10.0.1.8",
    geo: "广州",
    login_at: "今天 07:00",
    last_active_at: "22 分钟前",
    status: "idle",
    is_current: false,
    is_remember_me: false,
  },
  {
    jti: "jti-4",
    user_display_name: "赵六",
    user_email: "zhaoliu@br.com",
    device: { os: "Android", browser: "Chrome" },
    device_type: "mobile",
    ip: "10.0.1.20",
    geo: "深圳",
    login_at: "今天 10:00",
    last_active_at: "1 分钟前",
    status: "active",
    is_current: false,
    is_remember_me: false,
  },
  {
    jti: "jti-5",
    user_display_name: "陈七",
    user_email: "chenqi@br.com",
    device: { os: "macOS", browser: "Safari" },
    device_type: "desktop",
    ip: "10.0.1.33",
    geo: "杭州",
    login_at: "昨天 18:40",
    last_active_at: "45 分钟前",
    status: "idle",
    is_current: false,
    is_remember_me: true,
  },
  {
    jti: "jti-6",
    user_display_name: "林八",
    user_email: "linba@br.com",
    device: { os: "iPad", browser: "Safari" },
    device_type: "tablet",
    ip: "10.0.1.44",
    geo: "成都",
    login_at: "今天 09:50",
    last_active_at: "8 分钟前",
    status: "active",
    is_current: false,
    is_remember_me: false,
  },
  {
    jti: "jti-7",
    user_display_name: "周九",
    user_email: "zhoujiu@br.com",
    device: { os: "Windows", browser: "Chrome" },
    device_type: "desktop",
    ip: "10.0.1.55",
    geo: "上海",
    login_at: "今天 08:00",
    last_active_at: "2 分钟前",
    status: "active",
    is_current: false,
    is_remember_me: false,
  },
  {
    jti: "jti-8",
    user_display_name: "吴十",
    user_email: "wushi@br.com",
    device: { os: "macOS", browser: "Firefox" },
    device_type: "desktop",
    ip: "10.0.1.66",
    geo: "北京",
    login_at: "今天 10:10",
    last_active_at: "刚刚",
    status: "active",
    is_current: false,
    is_remember_me: false,
  },
]

// ─── Device icon ───────────────────────────────────────────────────────────────

function DeviceIcon({ type }: { type: SessionItem["device_type"] }) {
  if (type === "mobile") return <Smartphone className="size-[14px] text-muted-foreground" />
  if (type === "tablet") return <Tablet className="size-[14px] text-muted-foreground" />
  return <Monitor className="size-[14px] text-muted-foreground" />
}

// ─── SessionManagementPage ─────────────────────────────────────────────────────

export function SessionManagementPage() {
  const [deviceType, setDeviceType] = React.useState<"all" | "desktop" | "mobile" | "tablet">("all")
  const [status, setStatus] = React.useState<"all" | "active" | "idle">("all")
  const [q, setQ] = React.useState("")
  const [selectedKeys, setSelectedKeys] = React.useState<Set<string>>(new Set())
  const [revokeTarget, setRevokeTarget] = React.useState<SessionItem | null>(null)
  const [showBulkDialog, setShowBulkDialog] = React.useState(false)
  const [barElevated, setBarElevated] = React.useState(false)
  const scrollRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => setBarElevated(el.scrollTop > 0)
    el.addEventListener("scroll", onScroll, { passive: true })
    return () => el.removeEventListener("scroll", onScroll)
  }, [])

  const filtered = MOCK_SESSIONS.filter((s) => {
    if (deviceType !== "all" && s.device_type !== deviceType) return false
    if (status !== "all" && s.status !== status) return false
    if (q && ![s.user_display_name, s.user_email, s.ip].some((v) => v.includes(q))) return false
    return true
  })

  const allSelected = selectedKeys.size > 0 && selectedKeys.size === filtered.length
  const someSelected = selectedKeys.size > 0 && selectedKeys.size < filtered.length

  function toggleAll(checked: boolean) {
    if (checked) setSelectedKeys(new Set(filtered.map((s) => s.jti)))
    else setSelectedKeys(new Set())
  }

  function toggleRow(jti: string, checked: boolean) {
    setSelectedKeys((prev) => {
      const next = new Set(prev)
      if (checked) next.add(jti)
      else next.delete(jti)
      return next
    })
  }

  return (
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">

      {/* ── 一级侧导航 NarrowRail ── */}
      <NarrowRail
        logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── 二级侧导航 WideNav ── */}
      <SystemNav active="sessions" />

      {/* ── 右侧内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <div ref={scrollRef} className="flex-1 overflow-y-auto overscroll-none bg-card">
          <TopPageBar
            breadcrumb={[
              { icon: <Settings className="size-[14px]" />, label: "系统管理" },
              { label: "在线设备" },
            ]}
            elevated={barElevated}
          />
          <div className="mx-auto flex max-w-[1280px] flex-col gap-[var(--space-5)] px-[var(--space-7)] py-[var(--space-5)]">

            <PageTitleHeader title="在线设备" />

            {/* 统计卡 */}
            <div className="grid grid-cols-4 gap-[var(--space-4)]">
              {[
                { label: "在线设备", value: 128 },
                { label: "活跃用户", value: 89 },
                { label: "5 分钟内活跃", value: 34 },
                { label: "空闲设备", value: 39 },
              ].map(({ label, value }) => (
                <StatCard key={label} label={label} value={value} />
              ))}
            </div>

            {/* 顶部工具栏：选中 > 0 时由 TableSelectionBar 覆盖 */}
            {selectedKeys.size > 0 ? (
              <TableSelectionBar
                count={selectedKeys.size}
                onCancel={() => setSelectedKeys(new Set())}
                actions={
                  <Button
                    variant="ghost"
                    size="sm"
                    className="hover:bg-transparent hover:text-destructive"
                    onClick={() => setShowBulkDialog(true)}
                  >
                    批量退出登录
                  </Button>
                }
              />
            ) : (
              <div className="flex items-center gap-[var(--space-3)]">
                <SearchInput
                  placeholder="搜索用户名、邮箱或 IP"
                  className="w-[280px]"
                  onSearch={setQ}
                />
                <Select value={deviceType} onValueChange={(v) => setDeviceType(v as typeof deviceType)}>
                  <SelectTrigger className="w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部设备</SelectItem>
                    <SelectItem value="desktop">桌面端</SelectItem>
                    <SelectItem value="mobile">移动端</SelectItem>
                    <SelectItem value="tablet">平板</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
                  <SelectTrigger className="w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="active">活跃</SelectItem>
                    <SelectItem value="idle">空闲</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex-1" />
                <span className="text-[12px] text-muted-foreground">{filtered.length} 台设备在线</span>
              </div>
            )}

            {/* 表格 */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[40px]">
                    <Checkbox size="sm"
                      checked={allSelected}
                      data-state={someSelected ? "indeterminate" : undefined}
                      onCheckedChange={(checked) => toggleAll(!!checked)}
                    />
                  </TableHead>
                  <TableHead>用户</TableHead>
                  <TableHead>设备</TableHead>
                  <TableHead>IP / 位置</TableHead>
                  <TableHead>登录时间</TableHead>
                  <TableHead>最近活跃</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((row) => (
                  <TableRow
                    key={row.jti}
                    className={undefined}
                  >
                    <TableCell>
                      <Checkbox size="sm"
                        checked={selectedKeys.has(row.jti)}
                        onCheckedChange={(checked) => toggleRow(row.jti, !!checked)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-[var(--space-2)]">
                        <Avatar size="sm" name={row.user_display_name}>
                          <AvatarFallback />
                        </Avatar>
                        <div className="min-w-0">
                          <div className="flex items-center gap-[var(--space-1)]">
                            <span className="text-[12px] font-medium text-foreground">
                              {row.user_display_name}
                            </span>
                            {row.is_current && (
                              <Badge variant="default" size="sm" className="bg-primary-soft text-primary">当前</Badge>
                            )}
                          </div>
                          <span className="text-[11px] text-muted-foreground">{row.user_email}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-[var(--space-1_5)]">
                        <DeviceIcon type={row.device_type} />
                        <span className="text-[12px] text-foreground">
                          {row.device.os} · {row.device.browser}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="block text-[12px] text-foreground">{row.ip}</span>
                      <span className="text-[11px] text-muted-foreground">{row.geo}</span>
                    </TableCell>
                    <TableCell>
                      <span className="text-[12px] text-foreground">{row.login_at}</span>
                    </TableCell>
                    <TableCell>
                      <span className="text-[12px] text-foreground">{row.last_active_at}</span>
                    </TableCell>
                    <TableCell>
                      {row.status === "active" ? (
                        <Badge variant="success" size="sm">活跃</Badge>
                      ) : (
                        <Badge variant="secondary" size="sm">空闲</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <button
                        className="text-[12px] text-foreground transition-colors hover:text-destructive"
                        onClick={() => setRevokeTarget(row)}
                      >
                        退出登录
                      </button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>


          </div>
        </div>
      </div>

      {/* ── 单条下线对话框 ── */}
      <Dialog open={!!revokeTarget} onOpenChange={() => setRevokeTarget(null)}>
        <DialogContent className="max-w-[400px]">
          <DialogHeader>
            <DialogTitle>强制退出登录</DialogTitle>
          </DialogHeader>
          <p className="text-[12px] text-muted-foreground">
            {revokeTarget?.is_current
              ? "你正在退出自己的当前登录，操作后将立即退出。所有未保存的工作将会丢失。"
              : `将强制退出 ${revokeTarget?.user_display_name} 的登录，该用户需重新登录。`}
          </p>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setRevokeTarget(null)}>
              取消
            </Button>
            <Button variant="destructive" size="sm">
              {revokeTarget?.is_current ? "退出当前登录" : "确认退出"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── 批量下线对话框 ── */}
      <Dialog open={showBulkDialog} onOpenChange={setShowBulkDialog}>
        <DialogContent className="max-w-[400px]">
          <DialogHeader>
            <DialogTitle>批量退出登录</DialogTitle>
          </DialogHeader>
          <p className="text-[12px] text-muted-foreground">
            将强制退出 {selectedKeys.size} 台设备的登录，这些用户需重新登录。
          </p>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setShowBulkDialog(false)}>
              取消
            </Button>
            <Button variant="destructive" size="sm">
              确认退出
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  )
}
