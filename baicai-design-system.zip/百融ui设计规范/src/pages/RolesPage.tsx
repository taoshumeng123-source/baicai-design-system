import * as React from "react"
import {
  Bell,
  Briefcase,
  ChevronDown,
  ChevronRight,
  Code2,
  Copy,
  Database,
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  Link,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Plus,
  Scale,
  Settings,
  Trash2,
  User,
  Users,
} from "lucide-react"

import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { SystemNav } from "./SystemNav"
import { SubNav, SubNavGroup, SubNavItem } from "@/components/sub-nav"
import { TopPageBar, PageTitleHeader } from "@/components/top-page-bar"
import { SearchInput } from "@/components/search-input"
import { Button } from "@/components/button"
import { Badge } from "@/components/badge"
import { Checkbox } from "@/components/checkbox"
import { Input } from "@/components/input"
import { Textarea } from "@/components/textarea"
import { RadioPill } from "@/components/radio-pill"
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/tooltip"
import { cn } from "@/lib/utils"

// ─── Types ────────────────────────────────────────────────────────────────────

type DataScope = "tenant" | "department" | "personal"
type RoleType = "system" | "custom"

interface RoleItem {
  id: string
  code: string
  name: string
  type: RoleType
  dataScope: DataScope
  memberCount: number
}

interface PermAction {
  key: string
  label: string
}

interface PermResource {
  code: string
  name: string
  actions: Record<string, boolean | null>
}

interface PermModule {
  code: string
  name: string
  actions: PermAction[]
  resources: PermResource[]
}

// moduleCode → resourceCode → actionKey → boolean | null (null = 不适用)
type PermMap = Record<string, Record<string, Record<string, boolean | null>>>

// ─── Mock 数据 ────────────────────────────────────────────────────────────────

const ROLES: RoleItem[] = [
  { id: "r1", code: "system:owner", name: "超级管理员", type: "system", dataScope: "tenant", memberCount: 2 },
  { id: "r2", code: "system:admin", name: "管理员", type: "system", dataScope: "tenant", memberCount: 8 },
  { id: "r3", code: "system:member", name: "普通成员", type: "system", dataScope: "personal", memberCount: 156 },
  { id: "r4", code: "workspace:hr", name: "HR 专员", type: "custom", dataScope: "tenant", memberCount: 23 },
  { id: "r5", code: "workspace:dept_head", name: "部门负责人", type: "custom", dataScope: "department", memberCount: 12 },
  { id: "r6", code: "workspace:interviewer", name: "面试官", type: "custom", dataScope: "personal", memberCount: 45 },
  { id: "r7", code: "workspace:vendor", name: "外部顾问", type: "custom", dataScope: "personal", memberCount: 3 },
  { id: "r8", code: "custom:analyst", name: "数据分析师", type: "custom", dataScope: "tenant", memberCount: 5 },
]

const DATA_SCOPE_LABELS: Record<DataScope, string> = {
  tenant: "全租户",
  department: "本部门",
  personal: "个人",
}

const PERM_MODULES: PermModule[] = [
  {
    code: "recruit",
    name: "招聘管理",
    actions: [
      { key: "view", label: "查看" },
      { key: "create", label: "新建" },
      { key: "edit", label: "编辑" },
      { key: "delete", label: "删除" },
      { key: "export", label: "导出" },
      { key: "approve", label: "审批" },
    ],
    resources: [
      { code: "job", name: "职位管理", actions: { view: true, create: true, edit: true, delete: false, export: true, approve: null } },
      { code: "resume", name: "简历库", actions: { view: true, create: true, edit: true, delete: false, export: true, approve: null } },
      { code: "interview", name: "面试安排", actions: { view: true, create: true, edit: true, delete: false, export: null, approve: true } },
      { code: "offer", name: "Offer 管理", actions: { view: true, create: false, edit: true, delete: false, export: true, approve: true } },
    ],
  },
  {
    code: "scout",
    name: "智源·简历",
    actions: [
      { key: "view", label: "查看" },
      { key: "create", label: "新建" },
      { key: "edit", label: "编辑" },
      { key: "export", label: "导出" },
    ],
    resources: [
      { code: "search", name: "简历搜索", actions: { view: true, create: null, edit: null, export: true } },
      { code: "favorites", name: "人才收藏夹", actions: { view: true, create: true, edit: true, export: false } },
      { code: "library", name: "简历库管理", actions: { view: true, create: false, edit: false, export: true } },
    ],
  },
  {
    code: "assess",
    name: "智面·面试",
    actions: [
      { key: "view", label: "查看" },
      { key: "create", label: "新建" },
      { key: "edit", label: "编辑" },
      { key: "delete", label: "删除" },
    ],
    resources: [
      { code: "questions", name: "题库管理", actions: { view: true, create: false, edit: false, delete: false } },
      { code: "plans", name: "评测方案", actions: { view: true, create: false, edit: false, delete: false } },
      { code: "reports", name: "面试报告", actions: { view: true, create: null, edit: null, delete: null } },
    ],
  },
  {
    code: "admin_mgmt",
    name: "系统管理",
    actions: [
      { key: "view", label: "查看" },
      { key: "create", label: "新建" },
      { key: "edit", label: "编辑" },
      { key: "delete", label: "删除" },
    ],
    resources: [
      { code: "members", name: "成员管理", actions: { view: false, create: false, edit: false, delete: false } },
      { code: "roles_mgmt", name: "角色管理", actions: { view: false, create: false, edit: false, delete: false } },
      { code: "audit", name: "审计日志", actions: { view: false, create: null, edit: null, delete: null } },
    ],
  },
]

// ─── 帮助函数 ─────────────────────────────────────────────────────────────────

function derivePerms(roleId: string): PermMap {
  const base: PermMap = {}
  for (const mod of PERM_MODULES) {
    base[mod.code] = {}
    for (const res of mod.resources) {
      base[mod.code][res.code] = { ...res.actions }
    }
  }

  const setAll = (value: boolean | ((actKey: string) => boolean)) => {
    for (const mod of PERM_MODULES) {
      for (const res of mod.resources) {
        for (const act of mod.actions) {
          if (base[mod.code][res.code][act.key] !== null) {
            base[mod.code][res.code][act.key] =
              typeof value === "function" ? value(act.key) : value
          }
        }
      }
    }
  }

  if (roleId === "r1") {
    setAll(true)
  } else if (roleId === "r2") {
    setAll((k) => k !== "approve")
    for (const res of PERM_MODULES.find(m => m.code === "admin_mgmt")!.resources) {
      for (const k of ["view", "create", "edit", "delete"]) {
        if (base["admin_mgmt"][res.code][k] !== null) {
          base["admin_mgmt"][res.code][k] = true
        }
      }
    }
  } else if (roleId === "r3") {
    setAll((k) => k === "view")
  } else if (roleId === "r5") {
    setAll((k) => k === "view" || k === "edit")
  } else if (roleId === "r6") {
    setAll(false)
    // 面试官仅有招聘管理的查看权限
    for (const res of PERM_MODULES.find(m => m.code === "recruit")!.resources) {
      if (base["recruit"][res.code]["view"] !== null) base["recruit"][res.code]["view"] = true
    }
    for (const res of PERM_MODULES.find(m => m.code === "assess")!.resources) {
      if (base["assess"][res.code]["view"] !== null) base["assess"][res.code]["view"] = true
    }
  } else if (roleId === "r7") {
    setAll(false)
    for (const res of PERM_MODULES.find(m => m.code === "scout")!.resources) {
      if (base["scout"][res.code]["view"] !== null) base["scout"][res.code]["view"] = true
    }
  } else if (roleId === "r8") {
    setAll((k) => k === "view" || k === "export")
  }
  // r4 (HR 专员) 直接使用 PERM_MODULES 默认值

  return base
}

function getModuleStats(mod: PermModule, perms: PermMap) {
  let granted = 0, total = 0
  for (const res of mod.resources) {
    for (const act of mod.actions) {
      const val = perms[mod.code]?.[res.code]?.[act.key]
      if (val !== null && val !== undefined) {
        total++
        if (val === true) granted++
      }
    }
  }
  return { granted, total }
}

function getResourceCheckState(mod: PermModule, resCode: string, perms: PermMap): boolean | "indeterminate" {
  let checked = 0, total = 0
  for (const act of mod.actions) {
    const val = perms[mod.code]?.[resCode]?.[act.key]
    if (val !== null && val !== undefined) {
      total++
      if (val === true) checked++
    }
  }
  if (total === 0 || checked === 0) return false
  if (checked === total) return true
  return "indeterminate"
}

function countGranted(perms: PermMap) {
  let count = 0
  for (const mod of Object.values(perms)) {
    for (const res of Object.values(mod)) {
      for (const val of Object.values(res)) {
        if (val === true) count++
      }
    }
  }
  return count
}

// ─── ModuleCard ───────────────────────────────────────────────────────────────

interface ModuleCardProps {
  mod: PermModule
  perms: PermMap
  isReadOnly: boolean
  expanded: boolean
  onToggle: () => void
  onCellChange: (resCode: string, actKey: string, value: boolean) => void
  onSelectAll: () => void
  onViewOnly: () => void
  onClearAll: () => void
}

function ModuleCard({ mod, perms, isReadOnly, expanded, onToggle, onCellChange, onSelectAll, onViewOnly, onClearAll }: ModuleCardProps) {
  const { granted, total } = getModuleStats(mod, perms)

  return (
    <div className="overflow-hidden rounded-[var(--corner-lg)] border border-border">
      {/* 模块头部 */}
      <div className="flex items-center gap-[var(--space-3)] bg-background px-[var(--space-5)] py-[10px]">
        <button
          type="button"
          className="flex flex-1 items-center gap-[var(--space-3)] text-left"
          onClick={onToggle}
        >
          {expanded
            ? <ChevronDown className="size-[14px] shrink-0 text-muted-foreground" />
            : <ChevronRight className="size-[14px] shrink-0 text-muted-foreground" />
          }
          <span className="text-[14px] font-semibold text-foreground">{mod.name}</span>
        </button>
        {!isReadOnly && expanded && (
          <div className="flex items-center gap-[var(--space-1)]">
            <Button variant="ghost" size="sm" onClick={onSelectAll}>全选</Button>
            <Button variant="ghost" size="sm" onClick={onViewOnly}>仅查看</Button>
            <Button variant="ghost" size="sm" className="text-muted-foreground" onClick={onClearAll}>清空</Button>
          </div>
        )}
        <span className="shrink-0 text-[12px] text-muted-foreground">已授权 {granted}/{total}</span>
      </div>

      {/* 权限表格 */}
      {expanded && (
        <div className="overflow-x-auto">
          <table className="w-full table-fixed border-t border-border">
            <thead>
              <tr className="bg-secondary/30">
                <th className="px-[var(--space-5)] py-[var(--space-3)] text-left text-[11px] font-medium text-muted-foreground">
                  资源
                </th>
                {mod.actions.map(act => (
                  <th
                    key={act.key}
                    className="px-[var(--space-3)] py-[var(--space-3)] text-center text-[11px] font-medium text-muted-foreground"
                  >
                    {act.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {mod.resources.map((res) => {
                const rowState = getResourceCheckState(mod, res.code, perms)
                return (
                  <tr key={res.code} className="border-t border-border">
                    <td className="px-[var(--space-5)] py-[var(--space-3)]">
                      <div className="flex items-center gap-[var(--space-2)]">
                        <Checkbox
                          size="sm"
                          checked={rowState}
                          disabled={isReadOnly}
                          onCheckedChange={(checked) => {
                            for (const act of mod.actions) {
                              const val = perms[mod.code]?.[res.code]?.[act.key]
                              if (val !== null && val !== undefined) {
                                onCellChange(res.code, act.key, checked === true)
                              }
                            }
                          }}
                        />
                        <span className="text-[13px] text-foreground">{res.name}</span>
                      </div>
                    </td>
                    {mod.actions.map(act => {
                      const val = perms[mod.code]?.[res.code]?.[act.key]
                      return (
                        <td key={act.key} className="px-[var(--space-3)] py-[var(--space-3)] text-center">
                          {val === null ? (
                            <span className="text-[13px] text-muted-foreground/30">—</span>
                          ) : (
                            <Checkbox
                              size="sm"
                              checked={val === true}
                              disabled={isReadOnly}
                              onCheckedChange={(checked) => onCellChange(res.code, act.key, checked === true)}
                            />
                          )}
                        </td>
                      )
                    })}
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

// ─── RolesPage ────────────────────────────────────────────────────────────────

export function RolesPage() {
  const [selectedId, setSelectedId] = React.useState<string>("r4")
  const [permQ, setPermQ] = React.useState("")
  const [expandedModules, setExpandedModules] = React.useState<Set<string>>(
    () => new Set(PERM_MODULES.map(m => m.code))
  )
  const [savedPerms, setSavedPerms] = React.useState<PermMap>(() => derivePerms("r4"))
  const [editedPerms, setEditedPerms] = React.useState<PermMap>(() => derivePerms("r4"))
  const [isDirty, setIsDirty] = React.useState(false)

  // 对话框状态
  const [createOpen, setCreateOpen] = React.useState(false)
  const [editOpen, setEditOpen] = React.useState(false)
  const [deleteTarget, setDeleteTarget] = React.useState<RoleItem | null>(null)
  const [cloneOpen, setCloneOpen] = React.useState(false)
  const [cloneSourceId, setCloneSourceId] = React.useState("")

  // 新建角色表单
  const [createForm, setCreateForm] = React.useState({
    name: "",
    code: "",
    dataScope: "tenant" as DataScope,
    description: "",
  })

  function selectRole(id: string) {
    const perms = derivePerms(id)
    setSelectedId(id)
    setSavedPerms(perms)
    setEditedPerms(perms)
    setIsDirty(false)
  }

  function toggleModule(code: string) {
    setExpandedModules(prev => {
      const next = new Set(prev)
      next.has(code) ? next.delete(code) : next.add(code)
      return next
    })
  }

  function handleCellChange(modCode: string, resCode: string, actKey: string, value: boolean) {
    setEditedPerms(prev => ({
      ...prev,
      [modCode]: {
        ...prev[modCode],
        [resCode]: { ...prev[modCode][resCode], [actKey]: value },
      },
    }))
    setIsDirty(true)
  }

  function handleModuleAction(mod: PermModule, mode: "all" | "view" | "clear") {
    setEditedPerms(prev => {
      const next = { ...prev, [mod.code]: { ...prev[mod.code] } }
      for (const res of mod.resources) {
        next[mod.code][res.code] = { ...next[mod.code][res.code] }
        for (const act of mod.actions) {
          if (next[mod.code][res.code][act.key] !== null) {
            next[mod.code][res.code][act.key] =
              mode === "all" ? true : mode === "view" ? act.key === "view" : false
          }
        }
      }
      return next
    })
    setIsDirty(true)
  }

  function handleSave() {
    setSavedPerms(editedPerms)
    setIsDirty(false)
  }

  function handleDiscard() {
    setEditedPerms(savedPerms)
    setIsDirty(false)
  }

  function handleClone() {
    if (!cloneSourceId) return
    const perms = derivePerms(cloneSourceId)
    setEditedPerms(perms)
    setIsDirty(true)
    setCloneOpen(false)
    setCloneSourceId("")
  }

  const selectedRole = ROLES.find(r => r.id === selectedId) ?? null
  const isReadOnly = selectedRole?.type === "system"
  const grantedCount = countGranted(editedPerms)

  const systemRoles = ROLES.filter(r => r.type === "system")
  const customRoles = ROLES.filter(r => r.type === "custom")

  const visibleModules = React.useMemo(() => {
    if (!permQ) return PERM_MODULES
    const lq = permQ.toLowerCase()
    return PERM_MODULES
      .map(mod => {
        if (mod.name.toLowerCase().includes(lq)) return mod
        const matched = mod.resources.filter(r => r.name.toLowerCase().includes(lq))
        if (!matched.length) return null
        return { ...mod, resources: matched }
      })
      .filter(Boolean) as PermModule[]
  }, [permQ])

  return (
    <TooltipProvider delayDuration={300}>
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">

      {/* ── 一级侧导航 ── */}
      <NarrowRail
        logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── 二级侧导航 ── */}
      <SystemNav active="roles" />

      {/* ── 右侧内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <TopPageBar
          breadcrumb={[
            { icon: <Settings className="size-[14px]" />, label: "系统管理" },
            { label: "角色" },
          ]}
        />

        <div className="shrink-0 border-b border-border bg-card px-[var(--space-7)] py-[var(--space-4)]">
          <PageTitleHeader
            title="角色"
            actions={
              isDirty && !isReadOnly ? (
                <div className="flex items-center gap-[var(--space-2)]">
                  <span className="text-[12px] text-muted-foreground">已修改</span>
                  <Button variant="ghost" size="sm" onClick={handleDiscard}>放弃</Button>
                  <Button size="sm" onClick={handleSave}>保存权限</Button>
                </div>
              ) : undefined
            }
          />
        </div>

        {/* 主从面板 */}
        <div className="flex flex-1 overflow-hidden">

          {/* 左侧角色列表 · SubNav 三级导航 */}
          <SubNav>
            <SubNavGroup label="系统角色">
              {systemRoles.map(role => (
                <SubNavItem
                  key={role.id}
                  selected={selectedId === role.id}
                  onSelect={() => selectRole(role.id)}
                  count={role.memberCount}
                  locked
                >
                  {role.name}
                </SubNavItem>
              ))}
            </SubNavGroup>

            <SubNavGroup
              label="自定义角色"
              action={
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      aria-label="新建角色"
                      onClick={() => setCreateOpen(true)}
                    >
                      <Plus className="size-[14px]" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="right" sideOffset={6}>新建角色</TooltipContent>
                </Tooltip>
              }
            >
              {customRoles.map(role => (
                <SubNavItem
                  key={role.id}
                  selected={selectedId === role.id}
                  onSelect={() => selectRole(role.id)}
                  count={role.memberCount}
                  actions={[
                    {
                      icon: <Copy className="size-[11px]" />,
                      label: "复制权限",
                      onClick: () => { setCloneSourceId(role.id); setCloneOpen(true) },
                    },
                    {
                      icon: <Trash2 className="size-[11px]" />,
                      label: "删除角色",
                      onClick: () => setDeleteTarget(role),
                      destructive: true,
                    },
                  ]}
                >
                  {role.name}
                </SubNavItem>
              ))}
            </SubNavGroup>
          </SubNav>

          {/* 右侧权限详情 */}
          <div className="flex flex-1 flex-col overflow-hidden">
            {/* 角色信息头 — 始终显示 */}
            <div className="shrink-0 bg-card px-[var(--space-6)] py-[var(--space-4)]">
              {/* 第一行：角色名/提示 + 角色操作 */}
              <div className="flex items-center gap-[var(--space-2)]">
                {selectedRole ? (
                  <>
                    <h2 className="text-[15px] font-semibold text-foreground">{selectedRole.name}</h2>
                    {selectedRole.type === "system"
                      ? <Badge variant="info" size="sm">系统</Badge>
                      : <Badge variant="default" size="sm">自定义</Badge>
                    }
                    <Badge variant="secondary" size="sm">{DATA_SCOPE_LABELS[selectedRole.dataScope]}</Badge>
                  </>
                ) : (
                  <span className="text-[13px] text-muted-foreground">选择左侧角色查看权限</span>
                )}

                <div className="flex-1" />

                {selectedRole && isReadOnly && (
                  <div className="flex items-center gap-[var(--space-2)] text-[12px] text-muted-foreground">
                    <Lock className="size-[12px]" />
                    权限不可修改
                  </div>
                )}

                {selectedRole && !isReadOnly && (
                  <>
                    <Button variant="outline" size="sm" onClick={() => setCloneOpen(true)}>
                      复制权限自其他角色
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setEditOpen(true)}>
                      编辑角色信息
                    </Button>
                  </>
                )}
              </div>

              {/* 第二行：搜索 + 统计 */}
              {selectedRole && (
                <div className="mt-[var(--space-2)] flex items-center gap-[var(--space-3)]">
                  <SearchInput
                    placeholder="搜索权限"
                    className="w-[200px]"
                    onSearch={setPermQ}
                  />
                  <span className="flex-1 text-right text-[12px] text-muted-foreground">
                    已授权 {grantedCount} 项权限 · {selectedRole.memberCount} 名成员使用
                  </span>
                </div>
              )}
            </div>

            {/* 权限矩阵 / 空态 */}
            {!selectedRole ? (
              <div className="flex flex-1 items-center justify-center">
                <div className="flex flex-col items-center gap-[var(--space-3)]">
                  <div className="flex size-12 items-center justify-center rounded-[var(--corner-lg)] bg-secondary">
                    <KeyRound className="size-5 text-muted-foreground" />
                  </div>
                  <p className="text-[13px] text-muted-foreground">从左侧选择角色，或新建一个角色</p>
                </div>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto overscroll-none bg-card px-[var(--space-6)] py-[var(--space-5)]">
                <div className="flex flex-col gap-[var(--space-4)] pb-10">
                  {visibleModules.map(mod => (
                    <ModuleCard
                      key={mod.code}
                      mod={mod}
                      perms={editedPerms}
                      isReadOnly={!!isReadOnly}
                      expanded={expandedModules.has(mod.code)}
                      onToggle={() => toggleModule(mod.code)}
                      onCellChange={(resCode, actKey, value) =>
                        handleCellChange(mod.code, resCode, actKey, value)
                      }
                      onSelectAll={() => handleModuleAction(mod, "all")}
                      onViewOnly={() => handleModuleAction(mod, "view")}
                      onClearAll={() => handleModuleAction(mod, "clear")}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── 新建角色对话框 ── */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-[460px]">
          <DialogHeader>
            <DialogTitle>新建角色</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-[var(--space-4)]">
            <div className="flex flex-col gap-[var(--space-2)]">
              <label className="text-[13px] font-medium text-foreground">
                角色名称 <span className="text-destructive">*</span>
              </label>
              <Input
                placeholder="例如：招聘专员"
                value={createForm.name}
                onChange={e => setCreateForm(p => ({ ...p, name: e.target.value }))}
              />
            </div>
            <div className="flex flex-col gap-[var(--space-2)]">
              <label className="text-[13px] font-medium text-foreground">
                角色标识符 <span className="text-destructive">*</span>
              </label>
              <Input
                placeholder="例如：workspace:recruiter"
                className="font-mono"
                value={createForm.code}
                onChange={e => setCreateForm(p => ({ ...p, code: e.target.value }))}
              />
              <p className="text-[12px] text-muted-foreground">仅支持字母、数字、冒号和下划线，创建后不可修改</p>
            </div>
            <div className="flex flex-col gap-[var(--space-2)]">
              <label className="text-[13px] font-medium text-foreground">数据范围</label>
              <div className="flex gap-[var(--space-4)]">
                <RadioPill active={createForm.dataScope === "tenant"} label="全租户" onSelect={() => setCreateForm(p => ({ ...p, dataScope: "tenant" }))} />
                <RadioPill active={createForm.dataScope === "department"} label="本部门" onSelect={() => setCreateForm(p => ({ ...p, dataScope: "department" }))} />
                <RadioPill active={createForm.dataScope === "personal"} label="个人" onSelect={() => setCreateForm(p => ({ ...p, dataScope: "personal" }))} />
              </div>
              <p className="text-[12px] text-muted-foreground">决定该角色成员可访问的数据范围</p>
            </div>
            <div className="flex flex-col gap-[var(--space-2)]">
              <label className="text-[13px] font-medium text-foreground">
                描述
                <span className="ml-[var(--space-2)] text-[12px] font-normal text-muted-foreground">可选</span>
              </label>
              <Textarea
                placeholder="简要描述该角色的职责..."
                className="min-h-[80px] resize-none"
                value={createForm.description}
                onChange={e => setCreateForm(p => ({ ...p, description: e.target.value }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setCreateOpen(false)}>取消</Button>
            <Button size="sm" disabled={!createForm.name || !createForm.code}>创建角色</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── 编辑角色对话框 ── */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-[460px]">
          <DialogHeader>
            <DialogTitle>编辑角色信息</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-[var(--space-4)]">
            <div className="flex flex-col gap-[var(--space-2)]">
              <label className="text-[13px] font-medium text-foreground">
                角色名称 <span className="text-destructive">*</span>
              </label>
              <Input defaultValue={selectedRole?.name} />
            </div>
            <div className="flex flex-col gap-[var(--space-2)]">
              <label className="text-[13px] font-medium text-foreground">角色标识符</label>
              <div className="flex h-[var(--control-height-sm)] items-center rounded-[var(--corner-sm)] border border-input bg-secondary px-[var(--space-3)] font-mono text-[13px] text-muted-foreground">
                {selectedRole?.code}
              </div>
              <p className="text-[12px] text-muted-foreground">角色标识符创建后不可修改</p>
            </div>
            <div className="flex flex-col gap-[var(--space-2)]">
              <label className="text-[13px] font-medium text-foreground">数据范围</label>
              <div className="flex gap-[var(--space-4)]">
                <RadioPill active={selectedRole?.dataScope === "tenant"} label="全租户" onSelect={() => {}} />
                <RadioPill active={selectedRole?.dataScope === "department"} label="本部门" onSelect={() => {}} />
                <RadioPill active={selectedRole?.dataScope === "personal"} label="个人" onSelect={() => {}} />
              </div>
            </div>
            <div className="flex flex-col gap-[var(--space-2)]">
              <label className="text-[13px] font-medium text-foreground">
                描述
                <span className="ml-[var(--space-2)] text-[12px] font-normal text-muted-foreground">可选</span>
              </label>
              <Textarea placeholder="简要描述该角色的职责..." className="min-h-[80px] resize-none" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setEditOpen(false)}>取消</Button>
            <Button size="sm">保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── 删除确认对话框 ── */}
      <Dialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <DialogContent className="max-w-[400px]">
          <DialogHeader>
            <DialogTitle>删除角色</DialogTitle>
          </DialogHeader>
          <p className="text-[13px] leading-[22px] text-muted-foreground">
            将删除角色{" "}
            <span className="font-medium text-foreground">「{deleteTarget?.name}」</span>，此操作不可撤销。
            {deleteTarget && deleteTarget.memberCount > 0 && (
              <>该角色下 <span className="font-medium text-foreground">{deleteTarget.memberCount} 名成员</span> 将失去相关权限，请谨慎操作。</>
            )}
          </p>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>取消</Button>
            <Button variant="destructive" size="sm">删除角色</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── 复制权限对话框 ── */}
      <Dialog open={cloneOpen} onOpenChange={(v) => { setCloneOpen(v); if (!v) setCloneSourceId("") }}>
        <DialogContent className="max-w-[400px]">
          <DialogHeader>
            <DialogTitle>复制权限自其他角色</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-[var(--space-3)]">
            <p className="text-[13px] text-muted-foreground">
              选择来源角色后，当前角色的权限配置将被覆盖。
            </p>
            <Select value={cloneSourceId} onValueChange={setCloneSourceId}>
              <SelectTrigger>
                <SelectValue placeholder="选择来源角色" />
              </SelectTrigger>
              <SelectContent>
                {ROLES.filter(r => r.id !== selectedId).map(r => (
                  <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => { setCloneOpen(false); setCloneSourceId("") }}>取消</Button>
            <Button size="sm" disabled={!cloneSourceId} onClick={handleClone}>复制权限</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
    </TooltipProvider>
  )
}
