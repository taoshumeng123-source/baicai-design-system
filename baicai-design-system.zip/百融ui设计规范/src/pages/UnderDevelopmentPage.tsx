import {
  Bell,
  Briefcase,
  Code2,
  Database,
  Settings,
  User,
} from "lucide-react"
import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { TopPageBar } from "@/components/top-page-bar"
import { EmptyState } from "@/components/empty-state"
import { SystemNav, SYSTEM_NAV_TITLES } from "./SystemNav"

export interface UnderDevelopmentPageProps {
  /** 当前激活的导航 key（= 路由 hash） */
  activeKey: string
}

/** 「系统管理」下尚未实现的模块占位页：标准 App Shell + 居中「功能开发中」空状态。 */
export function UnderDevelopmentPage({ activeKey }: UnderDevelopmentPageProps) {
  const title = SYSTEM_NAV_TITLES[activeKey] ?? "功能"

  return (
    <div className="flex h-screen min-w-[1200px] overflow-hidden overscroll-none bg-background text-foreground">
      {/* ── 一级侧导航 NarrowRail ── */}
      <NarrowRail
        logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
        topItems={
          <>
            <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
            <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
            <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
          </>
        }
        bottomItems={
          <>
            <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
            <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
            <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
          </>
        }
      />

      {/* ── 二级侧导航 SystemNav ── */}
      <SystemNav active={activeKey} />

      {/* ── 右侧内容区 ── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <div className="flex flex-1 flex-col overflow-y-auto overscroll-none bg-card">
          <TopPageBar
            breadcrumb={[
              { icon: <Settings className="size-[14px]" />, label: "系统管理" },
              { label: title },
            ]}
          />
          <div className="flex flex-1 items-center justify-center px-[var(--space-7)] py-[var(--space-5)]">
            <EmptyState
              title="功能开发中"
              description={`${title}模块正在设计与开发中，敬请期待`}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
