import * as React from "react"
import { cn } from "@/lib/utils"

export interface ShowcaseSection {
  label: string
  description?: string
  children: React.ReactNode
}

export interface ComponentShowcaseProps {
  id: string
  title: string
  source: string
  description?: string
  sections: ShowcaseSection[]
  colSpan?: 1 | 2
  className?: string
}

function ComponentShowcase({
  id,
  title,
  source,
  description,
  sections,
  colSpan = 1,
  className,
}: ComponentShowcaseProps) {
  return (
    <section
      id={id}
      className={cn(
        "scroll-mt-[80px] overflow-hidden rounded-[var(--corner-lg)] border border-border bg-card",
        colSpan === 2 && "xl:col-span-2",
        className
      )}
    >
      <header className="flex items-baseline gap-[var(--space-3)] border-b border-border px-[var(--space-5)] py-[var(--space-3)]">
        <h3 className="text-[15px] font-semibold leading-[24px] text-foreground">
          {title}
        </h3>
        <span className="truncate font-mono text-[12px] text-muted-foreground">
          {source}
        </span>
      </header>

      {description && (
        <p className="px-[var(--space-5)] pt-[var(--space-3)] text-[13px] leading-[20px] text-muted-foreground">
          {description}
        </p>
      )}

      <div className="flex flex-col gap-[var(--space-5)] px-[var(--space-5)] py-[var(--space-5)]">
        {sections.map((section) => (
          <div key={section.label} className="flex flex-col gap-[var(--space-3)]">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                {section.label}
              </p>
              {section.description && (
                <p className="mt-[2px] text-[12px] leading-[18px] text-muted-foreground/80">
                  {section.description}
                </p>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-[var(--space-3)] rounded-[var(--corner-md)] border border-border bg-background px-[var(--space-4)] py-[var(--space-4)]">
              {section.children}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

export { ComponentShowcase }
