import * as React from "react"
import { ColorsFoundation } from "./colors"
import { TypographyFoundation } from "./typography"
import { CornersFoundation } from "./corners"
import { SpacingFoundation } from "./spacing"

type Sub = {
  id: string
  title: string
  description: string
  node: React.ReactNode
}

const SUBS: Sub[] = [
  {
    id: "foundations-colors",
    title: "Colors",
    description: "按语义分组的颜色 token，对应 globals.css 中的 CSS 变量。",
    node: <ColorsFoundation />,
  },
  {
    id: "foundations-typography",
    title: "Typography",
    description: "字号与字重阶梯（项目内统一用 text-[Npx] 语法）。",
    node: <TypographyFoundation />,
  },
  {
    id: "foundations-corners",
    title: "Corners",
    description: "圆角 token，5 档覆盖控件 / 卡片 / 大型表面。",
    node: <CornersFoundation />,
  },
  {
    id: "foundations-spacing",
    title: "Spacing",
    description: "间距 token，13 档覆盖 padding / gap / margin。",
    node: <SpacingFoundation />,
  },
]

function Foundations() {
  return (
    <div className="flex flex-col gap-[var(--space-8)]">
      {SUBS.map((sub) => (
        <section
          key={sub.id}
          id={sub.id}
          className="scroll-mt-[80px] rounded-[var(--corner-lg)] border border-border bg-card px-[var(--space-6)] py-[var(--space-5)]"
        >
          <header className="mb-[var(--space-4)]">
            <h3 className="text-[18px] font-semibold leading-[28px] text-foreground">
              {sub.title}
            </h3>
            <p className="mt-[var(--space-1)] text-[13px] text-muted-foreground">
              {sub.description}
            </p>
          </header>
          {sub.node}
        </section>
      ))}
    </div>
  )
}

export { Foundations }
