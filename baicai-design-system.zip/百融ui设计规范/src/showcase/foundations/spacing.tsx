import * as React from "react"

const SPACES = [
  { token: "--space-0", value: "0px", px: 0 },
  { token: "--space-0_5", value: "2px", px: 2 },
  { token: "--space-1", value: "4px", px: 4 },
  { token: "--space-1_5", value: "6px", px: 6 },
  { token: "--space-2", value: "8px", px: 8 },
  { token: "--space-3", value: "12px", px: 12 },
  { token: "--space-4", value: "16px", px: 16 },
  { token: "--space-5", value: "20px", px: 20 },
  { token: "--space-6", value: "24px", px: 24 },
  { token: "--space-7", value: "28px", px: 28 },
  { token: "--space-8", value: "32px", px: 32 },
  { token: "--space-10", value: "40px", px: 40 },
  { token: "--space-12", value: "48px", px: 48 },
]

function SpacingFoundation() {
  return (
    <div className="flex flex-col gap-[var(--space-4)]">
      <p className="text-[12px] text-muted-foreground">
        间距共 13 档（0–48px），用 <code className="font-mono">var(--space-*)</code> 控制 padding / gap / margin，不写 hex。
      </p>
      <div className="flex flex-col gap-[var(--space-2)] rounded-[var(--corner-md)] border border-border bg-card px-[var(--space-5)] py-[var(--space-4)]">
        {SPACES.map((s) => (
          <div key={s.token} className="flex items-center gap-[var(--space-4)]">
            <span className="w-[110px] font-mono text-[11px] text-foreground">{s.token}</span>
            <span className="w-[40px] font-mono text-[11px] text-muted-foreground">{s.value}</span>
            <div className="h-[12px] rounded-[var(--corner-xs)] bg-primary-soft" style={{ width: s.px || 1 }} />
          </div>
        ))}
      </div>
    </div>
  )
}

export { SpacingFoundation }
