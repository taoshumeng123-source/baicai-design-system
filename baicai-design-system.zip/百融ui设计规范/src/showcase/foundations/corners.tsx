import * as React from "react"

const CORNERS = [
  { token: "--corner-xs", value: "4px", css: "rounded-[var(--corner-xs)]" },
  { token: "--corner-sm", value: "6px", css: "rounded-[var(--corner-sm)]" },
  { token: "--corner-md", value: "8px", css: "rounded-[var(--corner-md)]" },
  { token: "--corner-lg", value: "10px", css: "rounded-[var(--corner-lg)]" },
  { token: "--corner-xl", value: "12px", css: "rounded-[var(--corner-xl)]" },
]

function CornersFoundation() {
  return (
    <div className="flex flex-col gap-[var(--space-4)]">
      <p className="text-[12px] text-muted-foreground">
        圆角共 5 档（xs / sm / md / lg / xl），统一用 <code className="font-mono">var(--corner-*)</code> token 引用，不写 hex 数值。
      </p>
      <div className="flex flex-wrap gap-[var(--space-5)]">
        {CORNERS.map((c) => (
          <div key={c.token} className="flex w-[96px] flex-col items-center gap-[var(--space-2)]">
            <div
              className={`size-[64px] border border-border bg-primary-soft ${c.css}`}
            />
            <div className="flex flex-col items-center">
              <span className="font-mono text-[11px] text-foreground">{c.token}</span>
              <span className="font-mono text-[10px] text-muted-foreground">{c.value}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export { CornersFoundation }
