import * as React from "react"

type TypeSpec = {
  label: string
  className: string
  spec: string
  sample: string
}

const SAMPLES: TypeSpec[] = [
  {
    label: "Display / H1",
    className: "text-[32px] leading-[40px] font-bold tracking-[-0.01em]",
    spec: "32 / 40 · Bold",
    sample: "百融 UI 设计规范",
  },
  {
    label: "Section / H2",
    className: "text-[24px] leading-[32px] font-bold tracking-[-0.01em]",
    spec: "24 / 32 · Bold",
    sample: "Foundations",
  },
  {
    label: "PageTitle / H3",
    className: "text-[20px] leading-[32px] font-bold",
    spec: "20 / 32 · Bold",
    sample: "通用设置",
  },
  {
    label: "Card Title / H4",
    className: "text-[15px] leading-[24px] font-semibold",
    spec: "15 / 24 · Semibold",
    sample: "租户基本信息",
  },
  {
    label: "Field Label",
    className: "text-[14px] leading-[20px] font-semibold",
    spec: "14 / 20 · Semibold",
    sample: "密码策略",
  },
  {
    label: "Body",
    className: "text-[13px] leading-[20px] text-foreground",
    spec: "13 / 20 · Regular",
    sample: "用户在登录系统时需要遵循的安全策略与密码规范。",
  },
  {
    label: "Body · Muted",
    className: "text-[13px] leading-[20px] text-muted-foreground",
    spec: "13 / 20 · Regular · muted-foreground",
    sample: "用户在登录系统时需要遵循的安全策略与密码规范。",
  },
  {
    label: "Small",
    className: "text-[12px] leading-[18px] text-muted-foreground",
    spec: "12 / 18 · Regular",
    sample: "影响全局展示的企业身份信息",
  },
  {
    label: "Caption",
    className: "text-[11px] leading-[16px] font-semibold uppercase tracking-wider text-muted-foreground",
    spec: "11 / 16 · Semibold · uppercase · tracking-wider",
    sample: "TENANT BASIC INFO",
  },
  {
    label: "Mono",
    className: "font-mono text-[12px] leading-[18px] text-foreground",
    spec: "12 / 18 · Mono",
    sample: "src/components/button.tsx",
  },
]

function TypographyFoundation() {
  return (
    <div className="flex flex-col gap-[var(--space-4)]">
      <p className="text-[12px] text-muted-foreground">
        字号阶梯沿用项目内 hex 字号习惯（<code className="font-mono">text-[20px]</code> 等），不引入 font-size token。font-family 由
        <code className="font-mono"> --font-sans-base / --font-mono-base </code>提供。
      </p>
      <div className="flex flex-col divide-y divide-border rounded-[var(--corner-md)] border border-border bg-card">
        {SAMPLES.map((s) => (
          <div
            key={s.label}
            className="grid grid-cols-[180px_180px_1fr] items-baseline gap-[var(--space-4)] px-[var(--space-5)] py-[var(--space-4)]"
          >
            <span className="text-[12px] font-medium text-foreground">{s.label}</span>
            <span className="font-mono text-[11px] text-muted-foreground">{s.spec}</span>
            <span className={s.className}>{s.sample}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export { TypographyFoundation }
