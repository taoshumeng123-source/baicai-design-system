import * as React from "react"
import { showSuccessToast } from "@/components/sonner"
import { cn } from "@/lib/utils"

type Swatch = {
  name: string
  hex: string
  fg?: "light" | "dark"
}

type Group = {
  title: string
  description?: string
  swatches: Swatch[]
}

const GROUPS: Group[] = [
  {
    title: "Primary",
    description: "品牌主色与衍生（hover / active / soft / border / emphasis）",
    swatches: [
      { name: "--primary", hex: "#423eec", fg: "light" },
      { name: "--primary-hover", hex: "#717ffc", fg: "light" },
      { name: "--primary-active", hex: "#3833ca", fg: "light" },
      { name: "--primary-soft", hex: "#ecf0fe", fg: "dark" },
      { name: "--primary-soft-hover", hex: "#dce4fd", fg: "dark" },
      { name: "--primary-border", hex: "#c0cdfc", fg: "dark" },
      { name: "--primary-border-hover", hex: "#9aacfd", fg: "dark" },
      { name: "--primary-emphasis", hex: "#2e2c9c", fg: "light" },
    ],
  },
  {
    title: "Neutral · Background / Surface",
    description: "页面底色与表面（card / popover / muted）",
    swatches: [
      { name: "--background", hex: "#f9f9f9", fg: "dark" },
      { name: "--card", hex: "#ffffff", fg: "dark" },
      { name: "--popover", hex: "#ffffff", fg: "dark" },
      { name: "--secondary", hex: "#f3f3f3", fg: "dark" },
      { name: "--muted", hex: "#f3f3f3", fg: "dark" },
      { name: "--accent", hex: "#f3f3f3", fg: "dark" },
      { name: "--surface-disabled", hex: "#f3f3f3", fg: "dark" },
    ],
  },
  {
    title: "Neutral · Foreground / Border",
    description: "文字与边框",
    swatches: [
      { name: "--foreground", hex: "#171717", fg: "light" },
      { name: "--muted-foreground", hex: "#686868", fg: "light" },
      { name: "--border", hex: "#ebebeb", fg: "dark" },
      { name: "--border-strong", hex: "#686868", fg: "light" },
      { name: "--input", hex: "#e1e1e1", fg: "dark" },
      { name: "--ring", hex: "#9aacfd", fg: "dark" },
    ],
  },
  {
    title: "Destructive",
    swatches: [
      { name: "--destructive", hex: "#ee3e34", fg: "light" },
      { name: "--destructive-hover", hex: "#d82518", fg: "light" },
      { name: "--destructive-active", hex: "#b01f14", fg: "light" },
      { name: "--destructive-soft", hex: "#fdf1f0", fg: "dark" },
      { name: "--destructive-soft-hover", hex: "#fcdfde", fg: "dark" },
      { name: "--destructive-border", hex: "#fbc5c3", fg: "dark" },
    ],
  },
  {
    title: "Success",
    swatches: [
      { name: "--success", hex: "#29bb54", fg: "light" },
      { name: "--success-hover", hex: "#87e7a8", fg: "dark" },
      { name: "--success-active", hex: "#1f9742", fg: "light" },
      { name: "--success-soft", hex: "#effcf3", fg: "dark" },
      { name: "--success-soft-hover", hex: "#dafae5", fg: "dark" },
      { name: "--success-border", hex: "#b2e7c4", fg: "dark" },
    ],
  },
  {
    title: "Warning",
    swatches: [
      { name: "--warning", hex: "#e8a900", fg: "dark" },
      { name: "--warning-hover", hex: "#fdda43", fg: "dark" },
      { name: "--warning-active", hex: "#c47e00", fg: "light" },
      { name: "--warning-soft", hex: "#fefbe7", fg: "dark" },
      { name: "--warning-soft-hover", hex: "#fef7bf", fg: "dark" },
      { name: "--warning-border", hex: "#fdec87", fg: "dark" },
    ],
  },
  {
    title: "Info",
    swatches: [
      { name: "--info", hex: "#1c58f2", fg: "light" },
      { name: "--info-hover", hex: "#5099fe", fg: "light" },
      { name: "--info-active", hex: "#1745da", fg: "light" },
      { name: "--info-soft", hex: "#edf4fe", fg: "dark" },
      { name: "--info-soft-hover", hex: "#d7e7fc", fg: "dark" },
      { name: "--info-border", hex: "#b9d6fc", fg: "dark" },
    ],
  },
  {
    title: "Sidebar",
    description: "侧导航专属底色与状态",
    swatches: [
      { name: "--sidebar", hex: "#f5f7ff", fg: "dark" },
      { name: "--sidebar-soft", hex: "#f8faff", fg: "dark" },
      { name: "--sidebar-accent", hex: "#dce4fd", fg: "dark" },
      { name: "--sidebar-border", hex: "#d8ddea", fg: "dark" },
      { name: "--sidebar-brand-bg", hex: "#dce4fd", fg: "dark" },
      { name: "--sidebar-active-text", hex: "#423eec", fg: "light" },
    ],
  },
]

function Swatch({ swatch }: { swatch: Swatch }) {
  function handleClick() {
    const ref = `var(${swatch.name})`
    navigator.clipboard?.writeText(ref).then(
      () => showSuccessToast(`已复制 ${ref}`),
      () => undefined
    )
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className="group flex w-[124px] flex-col gap-[var(--space-2)] text-left transition-transform hover:-translate-y-[1px]"
    >
      <div
        className={cn(
          "flex h-[72px] items-end justify-start rounded-[var(--corner-md)] border border-border/60 p-[var(--space-2)]",
          swatch.fg === "light" ? "text-white/80" : "text-foreground/60"
        )}
        style={{ backgroundColor: swatch.hex }}
      >
        <span className="font-mono text-[10px]">{swatch.hex}</span>
      </div>
      <span className="truncate font-mono text-[11px] text-foreground">
        {swatch.name}
      </span>
    </button>
  )
}

function ColorsFoundation() {
  return (
    <div className="flex flex-col gap-[var(--space-6)]">
      {GROUPS.map((group) => (
        <div key={group.title} className="flex flex-col gap-[var(--space-3)]">
          <div>
            <p className="text-[13px] font-semibold text-foreground">
              {group.title}
            </p>
            {group.description && (
              <p className="mt-[2px] text-[12px] text-muted-foreground">
                {group.description}
              </p>
            )}
          </div>
          <div className="flex flex-wrap gap-[var(--space-3)]">
            {group.swatches.map((s) => (
              <Swatch key={s.name} swatch={s} />
            ))}
          </div>
        </div>
      ))}
      <p className="text-[12px] text-muted-foreground">
        点击任一色卡复制 <code className="font-mono">var(--token)</code> 引用到剪贴板。
      </p>
    </div>
  )
}

export { ColorsFoundation }
