import * as React from "react"
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/resizable"
import { ComponentShowcase } from "../component-showcase"

function ResizableShowcase() {
  return (
    <ComponentShowcase
      id="resizable"
      title="Resizable"
      source="src/components/resizable.tsx"
      description="可拖拽调整大小的面板组。orientation: horizontal / vertical。拖动中间手柄实时调整。"
      colSpan={2}
      sections={[
        {
          label: "Horizontal",
          children: (
            <div className="h-[180px] w-full overflow-hidden rounded-[var(--corner-md)] border border-border">
              <ResizablePanelGroup orientation="horizontal">
                <ResizablePanel defaultSize={30}>
                  <div className="flex h-full items-center justify-center text-[13px] text-muted-foreground">左侧</div>
                </ResizablePanel>
                <ResizableHandle withHandle />
                <ResizablePanel defaultSize={70}>
                  <div className="flex h-full items-center justify-center text-[13px] text-muted-foreground">右侧主区</div>
                </ResizablePanel>
              </ResizablePanelGroup>
            </div>
          ),
        },
      ]}
    />
  )
}

export { ResizableShowcase }
