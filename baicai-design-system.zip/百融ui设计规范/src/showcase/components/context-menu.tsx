import * as React from "react"
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuLabel,
  ContextMenuSeparator,
  ContextMenuShortcut,
  ContextMenuTrigger,
} from "@/components/context-menu"
import { ComponentShowcase } from "../component-showcase"

function ContextMenuShowcase() {
  return (
    <ComponentShowcase
      id="context-menu"
      title="Context Menu"
      source="src/components/context-menu.tsx"
      description="右键菜单。"
      sections={[
        {
          label: "Interactive (right-click area)",
          children: (
            <ContextMenu>
              <ContextMenuTrigger asChild>
                <div className="w-full rounded-[var(--corner-md)] border border-dashed border-border bg-card px-[var(--space-5)] py-[var(--space-8)] text-center text-[13px] text-muted-foreground">
                  在此区域右键
                </div>
              </ContextMenuTrigger>
              <ContextMenuContent>
                <ContextMenuLabel>操作</ContextMenuLabel>
                <ContextMenuItem>
                  复制 <ContextMenuShortcut>⌘C</ContextMenuShortcut>
                </ContextMenuItem>
                <ContextMenuItem>
                  粘贴 <ContextMenuShortcut>⌘V</ContextMenuShortcut>
                </ContextMenuItem>
                <ContextMenuSeparator />
                <ContextMenuItem className="text-destructive">删除</ContextMenuItem>
              </ContextMenuContent>
            </ContextMenu>
          ),
        },
      ]}
    />
  )
}

export { ContextMenuShowcase }
