import * as React from "react"
import { Monitor, Smartphone, Tablet } from "lucide-react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableSelectionBar,
} from "@/components/table"
import { Avatar, AvatarFallback } from "@/components/avatar"
import { Badge } from "@/components/badge"
import { Button } from "@/components/button"
import { Checkbox } from "@/components/checkbox"
import { SearchInput } from "@/components/search-input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"
import { ComponentShowcase } from "../component-showcase"

type SessionRow = {
  id: string
  name: string
  email: string
  device: { os: string; browser: string }
  deviceType: "desktop" | "mobile" | "tablet"
  ip: string
  geo: string
  loginAt: string
  lastActive: string
  status: "active" | "idle"
  isCurrent?: boolean
}

const ROWS: SessionRow[] = [
  { id: "1", name: "张三", email: "zhangsan@br.com", device: { os: "macOS", browser: "Chrome" }, deviceType: "desktop", ip: "10.0.1.5",  geo: "上海", loginAt: "今天 08:30", lastActive: "刚刚",      status: "active", isCurrent: true },
  { id: "2", name: "李四", email: "lisi@br.com",     device: { os: "Windows", browser: "Edge" }, deviceType: "desktop", ip: "10.0.1.12", geo: "北京", loginAt: "今天 09:15", lastActive: "3 分钟前", status: "active" },
  { id: "3", name: "王五", email: "wangwu@br.com",   device: { os: "iOS", browser: "Safari" },   deviceType: "mobile",  ip: "10.0.1.8",  geo: "广州", loginAt: "今天 07:00", lastActive: "22 分钟前", status: "idle" },
  { id: "4", name: "赵六", email: "zhaoliu@br.com",  device: { os: "Android", browser: "Chrome" }, deviceType: "mobile", ip: "10.0.1.20", geo: "深圳", loginAt: "今天 10:00", lastActive: "1 分钟前", status: "active" },
  { id: "5", name: "陈七", email: "chenqi@br.com",   device: { os: "macOS", browser: "Safari" },  deviceType: "desktop", ip: "10.0.1.33", geo: "杭州", loginAt: "昨天 18:40", lastActive: "45 分钟前", status: "idle" },
]

function DeviceIcon({ type }: { type: SessionRow["deviceType"] }) {
  if (type === "mobile") return <Smartphone className="size-[14px] text-muted-foreground" />
  if (type === "tablet") return <Tablet className="size-[14px] text-muted-foreground" />
  return <Monitor className="size-[14px] text-muted-foreground" />
}

function TableShowcase() {
  const [selectedKeys, setSelectedKeys] = React.useState<Set<string>>(new Set())
  const allSelected = selectedKeys.size > 0 && selectedKeys.size === ROWS.length
  const someSelected = selectedKeys.size > 0 && selectedKeys.size < ROWS.length

  function toggleRow(id: string) {
    setSelectedKeys((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <ComponentShowcase
      id="table"
      title="Table"
      source="src/components/table.tsx"
      description="基础表格原语。本示例复刻 #sessions 业务页的在线设备列表样式：Checkbox 多选 + Avatar/Badge 单元格 + 双行 IP/位置 + 设备 icon + 行内 ghost 退出登录。勾选任意行触发 TableSelectionBar 顶部覆盖式批量操作条（替换原过滤工具栏）。"
      colSpan={2}
      sections={[
        {
          label: "Sessions table · 完整样式 + 批量选择",
          description: "8 列 + Checkbox 全选/多选 + 选中行 > 0 时顶部工具栏由 SearchInput+Select 切换为 TableSelectionBar（单个 ghost 批量退出登录，hover 红）",
          children: (
            <div className="flex w-full flex-col gap-[var(--space-3)]">
              {/* 顶部工具栏：选中 > 0 时由 TableSelectionBar 覆盖 */}
              {selectedKeys.size > 0 ? (
                <TableSelectionBar
                  count={selectedKeys.size}
                  onCancel={() => setSelectedKeys(new Set())}
                  actions={
                    <Button
                      variant="ghost"
                      size="sm"
                      className="hover:bg-transparent hover:text-destructive"
                    >
                      批量退出登录
                    </Button>
                  }
                />
              ) : (
                <div className="flex items-center gap-[var(--space-3)]">
                  <SearchInput placeholder="搜索用户名、邮箱或 IP" className="w-[280px]" />
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部设备</SelectItem>
                      <SelectItem value="desktop">桌面端</SelectItem>
                      <SelectItem value="mobile">移动端</SelectItem>
                      <SelectItem value="tablet">平板</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部状态</SelectItem>
                      <SelectItem value="active">活跃</SelectItem>
                      <SelectItem value="idle">空闲</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="flex-1" />
                  <span className="text-[12px] text-muted-foreground">{ROWS.length} 台设备在线</span>
                </div>
              )}

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40px]">
                      <Checkbox
                        size="sm"
                        checked={allSelected}
                        data-state={someSelected ? "indeterminate" : undefined}
                        onCheckedChange={(checked) => {
                          if (checked) setSelectedKeys(new Set(ROWS.map((m) => m.id)))
                          else setSelectedKeys(new Set())
                        }}
                      />
                    </TableHead>
                    <TableHead>用户</TableHead>
                    <TableHead>设备</TableHead>
                    <TableHead>IP / 位置</TableHead>
                    <TableHead>登录时间</TableHead>
                    <TableHead>最近活跃</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ROWS.map((row) => (
                    <TableRow key={row.id}>
                      <TableCell>
                        <Checkbox
                          size="sm"
                          checked={selectedKeys.has(row.id)}
                          onCheckedChange={() => toggleRow(row.id)}
                        />
                      </TableCell>

                      <TableCell>
                        <div className="flex items-center gap-[var(--space-2)]">
                          <Avatar size="sm">
                            <AvatarFallback>{row.name[0]}</AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <div className="flex items-center gap-[var(--space-1)]">
                              <span className="text-[12px] font-medium text-foreground">{row.name}</span>
                              {row.isCurrent && (
                                <Badge variant="default" size="sm" className="bg-primary-soft text-primary">当前</Badge>
                              )}
                            </div>
                            <span className="text-[11px] text-muted-foreground">{row.email}</span>
                          </div>
                        </div>
                      </TableCell>

                      <TableCell>
                        <div className="flex items-center gap-[var(--space-1_5)]">
                          <DeviceIcon type={row.deviceType} />
                          <span className="text-[12px] text-foreground">
                            {row.device.os} · {row.device.browser}
                          </span>
                        </div>
                      </TableCell>

                      <TableCell>
                        <span className="block text-[12px] text-foreground">{row.ip}</span>
                        <span className="text-[11px] text-muted-foreground">{row.geo}</span>
                      </TableCell>

                      <TableCell>
                        <span className="text-[12px] text-foreground">{row.loginAt}</span>
                      </TableCell>

                      <TableCell>
                        <span className="text-[12px] text-foreground">{row.lastActive}</span>
                      </TableCell>

                      <TableCell>
                        {row.status === "active" ? (
                          <Badge variant="success" size="sm">活跃</Badge>
                        ) : (
                          <Badge variant="secondary" size="sm">空闲</Badge>
                        )}
                      </TableCell>

                      <TableCell>
                        <button className="text-[12px] text-foreground transition-colors hover:text-destructive">
                          退出登录
                        </button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ),
        },
      ]}
    />
  )
}

export { TableShowcase }
