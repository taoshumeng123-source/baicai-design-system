import * as React from "react"
import { Mail, Search } from "lucide-react"
import { Input } from "@/components/input"
import { Label } from "@/components/label"
import {
  InputGroup,
  InputGroupAddon,
  InputGroupInput,
  InputGroupText,
} from "@/components/input-group"
import { ComponentShowcase } from "../component-showcase"

function InputShowcase() {
  return (
    <ComponentShowcase
      id="input"
      title="Input"
      source="src/components/input.tsx"
      description="基础文本输入框，状态：default / focus / disabled / aria-invalid。配 InputGroup 可加前后缀图标/文本。"
      sections={[
        {
          label: "States",
          description: "default / placeholder / filled / disabled / error（aria-invalid）",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-2">
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Default</Label>
                <Input placeholder="请输入..." />
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Filled</Label>
                <Input defaultValue="百融云创科技有限公司" />
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Disabled</Label>
                <Input disabled defaultValue="不可编辑" />
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label className="text-destructive">Error (aria-invalid)</Label>
                <Input aria-invalid defaultValue="invalid@" />
              </div>
            </div>
          ),
        },
        {
          label: "Composition · InputGroup",
          description: "前后缀图标、文本单位、按钮等",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-2">
              <InputGroup>
                <InputGroupAddon><Search /></InputGroupAddon>
                <InputGroupInput placeholder="搜索成员" />
              </InputGroup>
              <InputGroup>
                <InputGroupAddon><Mail /></InputGroupAddon>
                <InputGroupInput placeholder="you@example.com" />
              </InputGroup>
              <InputGroup>
                <InputGroupInput placeholder="价格" />
                <InputGroupAddon align="inline-end"><InputGroupText>¥</InputGroupText></InputGroupAddon>
              </InputGroup>
              <InputGroup>
                <InputGroupInput placeholder="域名" />
                <InputGroupAddon align="inline-end"><InputGroupText>.bairong.com</InputGroupText></InputGroupAddon>
              </InputGroup>
            </div>
          ),
        },
      ]}
    />
  )
}

export { InputShowcase }
