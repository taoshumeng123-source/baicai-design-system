import * as React from "react"
import { Separator } from "@/components/separator"
import { ComponentShowcase } from "../component-showcase"

function SeparatorShowcase() {
  return (
    <ComponentShowcase
      id="separator"
      title="Separator"
      source="src/components/separator.tsx"
      description="语义化分隔线。orientation: horizontal / vertical。color 来自 --border。"
      sections={[
        {
          label: "Horizontal",
          children: (
            <div className="w-full">
              <p className="text-[13px] text-foreground">上方内容</p>
              <Separator className="my-[var(--space-3)]" />
              <p className="text-[13px] text-foreground">下方内容</p>
            </div>
          ),
        },
        {
          label: "Vertical",
          children: (
            <div className="flex h-[40px] items-center gap-[var(--space-3)]">
              <span className="text-[13px]">百融</span>
              <Separator orientation="vertical" />
              <span className="text-[13px]">云创</span>
              <Separator orientation="vertical" />
              <span className="text-[13px]">招聘</span>
            </div>
          ),
        },
      ]}
    />
  )
}

export { SeparatorShowcase }
