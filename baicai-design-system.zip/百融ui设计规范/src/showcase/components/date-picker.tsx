import * as React from "react"
import { DatePicker } from "@/components/date-picker"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function DatePickerShowcase() {
  const [date, setDate] = React.useState<Date | undefined>(new Date(2026, 4, 15))

  return (
    <ComponentShowcase
      id="date-picker"
      title="Date Picker"
      source="src/components/date-picker.tsx"
      description="日期选择器：输入框 + 弹出 Calendar 面板。"
      sections={[
        {
          label: "Interactive",
          children: (
            <div className="flex flex-col gap-[var(--space-1_5)]">
              <Label>选择日期</Label>
              <DatePicker value={date} onChange={setDate} />
            </div>
          ),
        },
      ]}
    />
  )
}

export { DatePickerShowcase }
