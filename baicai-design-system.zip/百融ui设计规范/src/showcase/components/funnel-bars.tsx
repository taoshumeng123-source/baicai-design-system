import { FunnelBars } from "@/components/funnel-bars"
import { ComponentShowcase } from "../component-showcase"

// 示例数据：与数据看板 #dashboard 招聘漏斗同款（近 1 个月）
const FUNNEL_DATA = [
  { key: "applied",   label: "简历投递", value: 248 },
  { key: "screened",  label: "初筛通过", value: 128 },
  { key: "interview", label: "面试邀约", value: 84  },
  { key: "offer",     label: "Offer",   value: 23  },
  { key: "hired",     label: "成功入职", value: 6   },
]

function FunnelBarsShowcase() {
  return (
    <ComponentShowcase
      id="funnel-bars"
      title="Funnel Bars"
      source="src/components/funnel-bars.tsx"
      description="招聘漏斗：居中圆角条（宽度收窄成倒三角）+ 浅紫渐变（hover 品牌色 + 整行浅灰底）+ 段内数值 + 右侧转化率 + 可选底部「整体转化」。最小段也保证数值可见。自带 hover 气泡。"
      sections={[
        {
          label: "倒三角圆角条漏斗 · 含整体转化",
          description: "宽度 = 0.16 起底 + 0.84×比例；hover 任意阶段弹气泡 + 整行浅灰底；底部为投递→入职整体转化率",
          children: (
            <div className="w-full max-w-[420px]">
              <FunnelBars data={FUNNEL_DATA} footer={{ label: "整体转化（投递 → 入职）" }} />
            </div>
          ),
        },
        {
          label: "无底部整体转化",
          children: (
            <div className="w-full max-w-[420px]">
              <FunnelBars data={FUNNEL_DATA} />
            </div>
          ),
        },
      ]}
    />
  )
}

export { FunnelBarsShowcase }
