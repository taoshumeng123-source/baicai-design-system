import * as React from "react"
import { ScrollArea } from "@/components/scroll-area"
import { ComponentShowcase } from "../component-showcase"

function ScrollAreaShowcase() {
  return (
    <ComponentShowcase
      id="scroll-area"
      title="Scroll Area"
      source="src/components/scroll-area.tsx"
      description="自定义滚动条容器。比原生滚动条更细、跨平台一致。"
      sections={[
        {
          label: "Vertical",
          children: (
            <ScrollArea className="h-[200px] w-[300px] rounded-[var(--corner-md)] border border-border">
              <div className="flex flex-col gap-[var(--space-2)] px-[var(--space-4)] py-[var(--space-3)]">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div key={i} className="text-[13px] text-foreground">
                    候选人 {i + 1} · zhang{i + 1}@br.com
                  </div>
                ))}
              </div>
            </ScrollArea>
          ),
        },
      ]}
    />
  )
}

export { ScrollAreaShowcase }
