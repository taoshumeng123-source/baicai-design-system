import * as React from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/dialog"
import { Button } from "@/components/button"
import { Input } from "@/components/input"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function DialogShowcase() {
  return (
    <ComponentShowcase
      id="dialog"
      title="Dialog"
      source="src/components/dialog.tsx"
      description="模态对话框。中等强度交互，覆盖在页面上方。点击 Trigger 可打开真实 Dialog。"
      sections={[
        {
          label: "Interactive",
          description: "点击按钮打开真实 Dialog",
          children: (
            <>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline">编辑成员</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>编辑成员信息</DialogTitle>
                    <DialogDescription>修改后立即生效，将通知该成员。</DialogDescription>
                  </DialogHeader>
                  <div className="flex flex-col gap-[var(--space-3)] py-[var(--space-2)]">
                    <div className="flex flex-col gap-[var(--space-1_5)]">
                      <Label htmlFor="dlg-name">姓名</Label>
                      <Input id="dlg-name" defaultValue="张伟" />
                    </div>
                    <div className="flex flex-col gap-[var(--space-1_5)]">
                      <Label htmlFor="dlg-email">邮箱</Label>
                      <Input id="dlg-email" type="email" defaultValue="zhangwei@br.com" />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline">取消</Button>
                    <Button>保存</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          ),
        },
      ]}
    />
  )
}

export { DialogShowcase }
