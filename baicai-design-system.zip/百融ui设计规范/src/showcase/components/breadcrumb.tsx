import * as React from "react"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/breadcrumb"
import { ComponentShowcase } from "../component-showcase"

function BreadcrumbShowcase() {
  return (
    <ComponentShowcase
      id="breadcrumb"
      title="Breadcrumb"
      source="src/components/breadcrumb.tsx"
      description="独立面包屑组件（TopPageBar 内已内置一份简化版）。可作为普通区域的路径导航。"
      sections={[
        {
          label: "Basic",
          children: (
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href="#">系统管理</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbLink href="#">组织与授权</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbPage>成员</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          ),
        },
      ]}
    />
  )
}

export { BreadcrumbShowcase }
