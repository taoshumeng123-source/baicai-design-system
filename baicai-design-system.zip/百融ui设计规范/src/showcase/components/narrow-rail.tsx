import * as React from "react"
import { Bell, Briefcase, Code2, Database, Settings, User } from "lucide-react"
import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import { ComponentShowcase } from "../component-showcase"

function NarrowRailShowcase() {
  return (
    <ComponentShowcase
      id="narrow-rail"
      title="Narrow Rail"
      source="src/components/narrow-rail.tsx"
      description="一级侧导航（56px）。AppTile 用于应用层，AdminTile 用于系统/通知/我的。hover/active 自带 Tooltip。"
      colSpan={2}
      sections={[
        {
          label: "Full rail",
          children: (
            <div className="h-[420px] w-full overflow-hidden rounded-[var(--corner-md)] border border-border">
              <NarrowRail
                logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
                topItems={
                  <>
                    <AppTile icon={<Briefcase className="size-[18px]" />} label="招聘" active />
                    <AppTile icon={<Code2 className="size-[18px]" />} label="智码" />
                    <AppTile icon={<Database className="size-[18px]" />} label="智源" />
                  </>
                }
                bottomItems={
                  <>
                    <AdminTile icon={<Bell className="size-[18px]" />} label="通知" />
                    <AdminTile icon={<Settings className="size-[18px]" />} label="系统管理" />
                    <AdminTile icon={<User className="size-[18px]" />} label="我的" />
                  </>
                }
              />
            </div>
          ),
        },
      ]}
    />
  )
}

export { NarrowRailShowcase }
