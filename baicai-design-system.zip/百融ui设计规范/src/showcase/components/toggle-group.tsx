import * as React from "react"
import { AlignCenter, AlignLeft, AlignRight, Bold, Italic, Underline } from "lucide-react"
import { ToggleGroup, ToggleGroupItem } from "@/components/toggle-group"
import { ComponentShowcase } from "../component-showcase"

function ToggleGroupShowcase() {
  return (
    <ComponentShowcase
      id="toggle-group"
      title="Toggle Group"
      source="src/components/toggle-group.tsx"
      description="Toggle 的分组容器。type='single' 单选、type='multiple' 多选。"
      sections={[
        {
          label: "Multiple (rich text)",
          children: (
            <ToggleGroup type="multiple" defaultValue={["bold"]}>
              <ToggleGroupItem value="bold" aria-label="Bold"><Bold /></ToggleGroupItem>
              <ToggleGroupItem value="italic" aria-label="Italic"><Italic /></ToggleGroupItem>
              <ToggleGroupItem value="underline" aria-label="Underline"><Underline /></ToggleGroupItem>
            </ToggleGroup>
          ),
        },
        {
          label: "Single (alignment)",
          children: (
            <ToggleGroup type="single" defaultValue="left">
              <ToggleGroupItem value="left" aria-label="Left"><AlignLeft /></ToggleGroupItem>
              <ToggleGroupItem value="center" aria-label="Center"><AlignCenter /></ToggleGroupItem>
              <ToggleGroupItem value="right" aria-label="Right"><AlignRight /></ToggleGroupItem>
            </ToggleGroup>
          ),
        },
      ]}
    />
  )
}

export { ToggleGroupShowcase }
