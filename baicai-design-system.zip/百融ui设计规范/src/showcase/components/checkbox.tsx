import * as React from "react"
import { Checkbox } from "@/components/checkbox"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function CheckboxShowcase() {
  return (
    <ComponentShowcase
      id="checkbox"
      title="Checkbox"
      source="src/components/checkbox.tsx"
      description="多选项控件。状态：unchecked / checked / indeterminate / disabled。"
      sections={[
        {
          label: "States",
          children: (
            <>
              <div className="flex items-center gap-[var(--space-2)]">
                <Checkbox id="cb-1" />
                <Label htmlFor="cb-1">Unchecked</Label>
              </div>
              <div className="flex items-center gap-[var(--space-2)]">
                <Checkbox id="cb-2" defaultChecked />
                <Label htmlFor="cb-2">Checked</Label>
              </div>
              <div className="flex items-center gap-[var(--space-2)]">
                <Checkbox id="cb-3" checked="indeterminate" />
                <Label htmlFor="cb-3">Indeterminate</Label>
              </div>
              <div className="flex items-center gap-[var(--space-2)]">
                <Checkbox id="cb-4" disabled />
                <Label htmlFor="cb-4" className="text-muted-foreground">Disabled</Label>
              </div>
              <div className="flex items-center gap-[var(--space-2)]">
                <Checkbox id="cb-5" disabled defaultChecked />
                <Label htmlFor="cb-5" className="text-muted-foreground">Disabled + Checked</Label>
              </div>
            </>
          ),
        },
        {
          label: "Sizes",
          children: (
            <>
              <div className="flex items-center gap-[var(--space-2)]">
                <Checkbox id="cbs-1" size="sm" defaultChecked />
                <Label htmlFor="cbs-1">Small</Label>
              </div>
              <div className="flex items-center gap-[var(--space-2)]">
                <Checkbox id="cbs-2" defaultChecked />
                <Label htmlFor="cbs-2">Default</Label>
              </div>
            </>
          ),
        },
      ]}
    />
  )
}

export { CheckboxShowcase }
