import * as React from "react"
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/carousel"
import { ComponentShowcase } from "../component-showcase"

function CarouselShowcase() {
  return (
    <ComponentShowcase
      id="carousel"
      title="Carousel"
      source="src/components/carousel.tsx"
      description="走马灯轮播。键盘 Left / Right。"
      sections={[
        {
          label: "Basic",
          children: (
            // 按钮 absolute 收到容器内（left-2 / right-2），蓝色区域 mx-12 左右各留 48px 给按钮
            <Carousel className="relative w-[360px]">
              <CarouselContent>
                {[1, 2, 3, 4].map((i) => (
                  <CarouselItem key={i}>
                    <div className="mx-12 flex h-[140px] items-center justify-center rounded-[var(--corner-md)] bg-primary-soft text-[32px] font-bold text-primary">
                      {i}
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="left-2 z-10" />
              <CarouselNext className="right-2 z-10" />
            </Carousel>
          ),
        },
      ]}
    />
  )
}

export { CarouselShowcase }
