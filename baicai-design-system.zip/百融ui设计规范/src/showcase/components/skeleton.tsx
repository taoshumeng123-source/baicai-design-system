import * as React from "react"
import { Skeleton } from "@/components/skeleton"
import { ComponentShowcase } from "../component-showcase"

function SkeletonShowcase() {
  return (
    <ComponentShowcase
      id="skeleton"
      title="Skeleton"
      source="src/components/skeleton.tsx"
      description="加载占位。脉冲动画，按比例 / 块状占位。"
      sections={[
        {
          label: "Lines",
          children: (
            <div className="flex w-full flex-col gap-[var(--space-2)]">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ),
        },
        {
          label: "Card placeholder",
          children: (
            <div className="flex w-[280px] gap-[var(--space-3)]">
              <Skeleton className="size-[48px] rounded-full" />
              <div className="flex flex-1 flex-col gap-[var(--space-2)]">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            </div>
          ),
        },
      ]}
    />
  )
}

export { SkeletonShowcase }
