import * as React from "react"
import { Calendar } from "@/components/calendar"
import { ComponentShowcase } from "../component-showcase"

function CalendarShowcase() {
  const month = new Date(2026, 4, 1)

  return (
    <ComponentShowcase
      id="calendar"
      title="Calendar"
      source="src/components/calendar.tsx"
      description="日历选择。mode: single / range / multiple；支持 dropdown 月年切换 / week number / 禁用日期。"
      colSpan={2}
      sections={[
        {
          label: "Single · 禁用日期",
          children: (
            <Calendar
              className="rounded-[var(--corner-md)] border border-border p-[var(--space-3)]"
              mode="single"
              month={month}
              selected={new Date(2026, 4, 15)}
              disabled={[new Date(2026, 4, 9), new Date(2026, 4, 10)]}
            />
          ),
        },
        {
          label: "Range · 双月",
          children: (
            <Calendar
              className="rounded-[var(--corner-md)] border border-border p-[var(--space-3)]"
              mode="range"
              month={month}
              numberOfMonths={2}
              selected={{ from: new Date(2026, 4, 6), to: new Date(2026, 4, 14) }}
            />
          ),
        },
        {
          label: "Multiple · 多日期",
          description: "支持选择多个不连续日期",
          children: (
            <Calendar
              className="rounded-[var(--corner-md)] border border-border p-[var(--space-3)]"
              mode="multiple"
              month={month}
              selected={[
                new Date(2026, 4, 3),
                new Date(2026, 4, 12),
                new Date(2026, 4, 21),
              ]}
            />
          ),
        },
        {
          label: "Dropdown · 双切换交互（月年下拉 + 左右箭头）",
          description: "captionLayout='dropdown' 用项目内 Select 组件渲染月/年下拉，可快速跳转；同时保留头部左右 < > 箭头按钮，按月顺序前后翻；showWeekNumber 显示第几周",
          children: (
            <Calendar
              className="rounded-[var(--corner-md)] border border-border p-[var(--space-3)]"
              captionLayout="dropdown"
              mode="single"
              month={month}
              selected={new Date(2026, 4, 21)}
              showOutsideDays={false}
              showWeekNumber
              startMonth={new Date(2025, 0, 1)}
              endMonth={new Date(2027, 11, 1)}
            />
          ),
        },
      ]}
    />
  )
}

export { CalendarShowcase }
