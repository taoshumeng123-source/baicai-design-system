import * as React from "react"
import { Pagination } from "@/components/pagination"
import { ComponentShowcase } from "../component-showcase"

function PaginationShowcase() {
  const [page, setPage] = React.useState(3)

  return (
    <ComponentShowcase
      id="pagination"
      title="Pagination"
      source="src/components/pagination.tsx"
      description="分页控件。可控当前页 + 总页数。"
      sections={[
        {
          label: "Interactive",
          children: (
            <Pagination
              page={page}
              totalPages={12}
              total={240}
              onPageChange={setPage}
            />
          ),
        },
      ]}
    />
  )
}

export { PaginationShowcase }
