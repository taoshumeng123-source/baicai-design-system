import * as React from "react"
import { Badge } from "@/components/badge"
import { ComponentShowcase } from "../component-showcase"

function BadgeShowcase() {
  return (
    <ComponentShowcase
      id="badge"
      title="Badge"
      source="src/components/badge.tsx"
      description="标签徽章。variant: default / secondary / outline / success / warning / info / destructive。size: sm / default。"
      sections={[
        {
          label: "Variants",
          children: (
            <>
              <Badge>Default</Badge>
              <Badge variant="secondary">Secondary</Badge>
              <Badge variant="outline">Outline</Badge>
              <Badge variant="success">Success</Badge>
              <Badge variant="warning">Warning</Badge>
              <Badge variant="info">Info</Badge>
              <Badge variant="destructive">Destructive</Badge>
            </>
          ),
        },
        {
          label: "Sizes",
          children: (
            <>
              <Badge size="sm">Small</Badge>
              <Badge>Default</Badge>
              <Badge size="lg">Large</Badge>
              <Badge size="sm" variant="success">活跃</Badge>
              <Badge size="sm" variant="warning">待审核</Badge>
            </>
          ),
        },
      ]}
    />
  )
}

export { BadgeShowcase }
