import * as React from "react"
import {
  Bell,
  Briefcase,
  Code2,
  Database,
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Network,
  Scale,
  Settings,
  User,
  Users,
} from "lucide-react"
import { NarrowRail, AppTile, AdminTile } from "@/components/narrow-rail"
import {
  WideNav,
  WideNavHeader,
  NavGroup,
  NavItem,
} from "@/components/wide-nav"
import { ComponentShowcase } from "../component-showcase"

function SidebarShowcase() {
  return (
    <ComponentShowcase
      id="sidebar"
      title="Sidebar"
      source="src/components/narrow-rail.tsx + src/components/wide-nav.tsx"
      description="B 端项目实际侧边栏 = NarrowRail (56px 一级图标轨) + WideNav (240px 二级文字导航)。NarrowRail 顶部 AppTile（业务应用切换）+ 底部 AdminTile（通知/系统管理/我的）；WideNav 含 Header + 多个 NavGroup + NavItem。"
      colSpan={2}
      sections={[
        {
          label: "Full sidebar · NarrowRail + WideNav",
          description: "完整展示一级图标轨 + 二级文字导航的组合，模拟系统管理实际页面",
          children: (
            <div className="flex w-full overflow-hidden rounded-[var(--corner-md)] border border-border">
              <NarrowRail
                logo={<img src={`${import.meta.env.BASE_URL}logo-icon.svg`} alt="百融百才" className="size-8" />}
                topItems={
                  <>
                    <AppTile icon={<Briefcase className="size-[18px]" strokeWidth={2} />} label="招聘" />
                    <AppTile icon={<Code2 className="size-[18px]" strokeWidth={2} />} label="智码" />
                    <AppTile icon={<Database className="size-[18px]" strokeWidth={2} />} label="智源" />
                  </>
                }
                bottomItems={
                  <>
                    <AdminTile icon={<Bell className="size-[18px]" strokeWidth={2} />} label="通知" />
                    <AdminTile icon={<Settings className="size-[18px]" strokeWidth={2} />} label="系统管理" active />
                    <AdminTile icon={<User className="size-[18px]" strokeWidth={2} />} label="我的" />
                  </>
                }
              />

              <WideNav header={<WideNavHeader title="系统管理" />}>
                <NavGroup label="应用与接入">
                  <NavItem icon={<LayoutDashboard className="size-[14px]" />}>应用中心</NavItem>
                  <NavItem icon={<Lock className="size-[14px]" />}>登录设置</NavItem>
                  <NavItem icon={<Monitor className="size-[14px]" />}>在线设备</NavItem>
                </NavGroup>
                <NavGroup label="组织与授权">
                  <NavItem icon={<Users className="size-[14px]" />}>成员</NavItem>
                  <NavItem icon={<Network className="size-[14px]" />}>部门</NavItem>
                  <NavItem icon={<Layers className="size-[14px]" />}>用户组</NavItem>
                  <NavItem icon={<KeyRound className="size-[14px]" />}>角色</NavItem>
                  <NavItem icon={<List className="size-[14px]" />}>权限项</NavItem>
                  <NavItem icon={<Scale className="size-[14px]" />}>权限策略</NavItem>
                </NavGroup>
                <NavGroup label="审计与风险">
                  <NavItem icon={<History className="size-[14px]" />}>操作日志</NavItem>
                  <NavItem icon={<LogIn className="size-[14px]" />}>登录日志</NavItem>
                </NavGroup>
                <NavGroup label="租户设置">
                  <NavItem icon={<Settings className="size-[14px]" />} active>通用设置</NavItem>
                  <NavItem icon={<Mail className="size-[14px]" />}>通知模板</NavItem>
                </NavGroup>
              </WideNav>
            </div>
          ),
        },
      ]}
    />
  )
}

export { SidebarShowcase }
