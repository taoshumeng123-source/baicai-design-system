import * as React from "react"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@/components/command"
import { ComponentShowcase } from "../component-showcase"

function CommandShowcase() {
  return (
    <ComponentShowcase
      id="command"
      title="Command"
      source="src/components/command.tsx"
      description="命令面板（Spotlight 风格）。输入实时搜索，键盘上下选择。"
      sections={[
        {
          label: "Basic",
          children: (
            <Command className="w-[360px] rounded-[var(--corner-md)] border border-border">
              <CommandInput placeholder="搜索命令..." />
              <CommandList>
                <CommandEmpty>未找到</CommandEmpty>
                <CommandGroup heading="导航">
                  <CommandItem>
                    成员管理 <CommandShortcut>⌘M</CommandShortcut>
                  </CommandItem>
                  <CommandItem>
                    角色权限 <CommandShortcut>⌘R</CommandShortcut>
                  </CommandItem>
                </CommandGroup>
                <CommandSeparator />
                <CommandGroup heading="操作">
                  <CommandItem>邀请新成员</CommandItem>
                  <CommandItem>导出登录日志</CommandItem>
                </CommandGroup>
              </CommandList>
            </Command>
          ),
        },
      ]}
    />
  )
}

export { CommandShowcase }
