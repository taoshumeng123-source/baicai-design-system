import * as React from "react"
import { ToggleChip } from "@/components/toggle-chip"
import { ComponentShowcase } from "../component-showcase"

function ToggleChipShowcase() {
  return (
    <ComponentShowcase
      id="toggle-chip"
      title="Toggle Chip"
      source="src/components/toggle-chip.tsx"
      description="Flat 设计平面复选。无外框胶囊，仅 [checkbox 指示器] + [标签]。常用于多选标签场景。"
      sections={[
        {
          label: "Multi-select",
          children: (
            <>
              <ToggleChip defaultChecked>大写字母</ToggleChip>
              <ToggleChip defaultChecked>小写字母</ToggleChip>
              <ToggleChip defaultChecked>数字</ToggleChip>
              <ToggleChip>特殊符号</ToggleChip>
            </>
          ),
        },
        {
          label: "Disabled",
          children: (
            <>
              <ToggleChip disabled>禁用 · 未选</ToggleChip>
              <ToggleChip disabled defaultChecked>禁用 · 已选</ToggleChip>
            </>
          ),
        },
      ]}
    />
  )
}

export { ToggleChipShowcase }
