import * as React from "react"
import { Progress } from "@/components/progress"
import { ComponentShowcase } from "../component-showcase"

function ProgressShowcase() {
  return (
    <ComponentShowcase
      id="progress"
      title="Progress"
      source="src/components/progress.tsx"
      description="进度条。value: 0-100。"
      sections={[
        {
          label: "Steps",
          children: (
            <div className="flex w-full flex-col gap-[var(--space-3)]">
              {[12, 38, 67, 100].map((v) => (
                <div key={v} className="flex flex-col gap-[var(--space-1)]">
                  <div className="flex justify-between text-[12px] text-muted-foreground">
                    <span>简历筛选</span>
                    <span>{v}%</span>
                  </div>
                  <Progress value={v} />
                </div>
              ))}
            </div>
          ),
        },
      ]}
    />
  )
}

export { ProgressShowcase }
