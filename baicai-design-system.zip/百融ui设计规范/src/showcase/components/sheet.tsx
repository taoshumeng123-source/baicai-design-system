import * as React from "react"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/sheet"
import { Button } from "@/components/button"
import { Skeleton } from "@/components/skeleton"
import { ComponentShowcase } from "../component-showcase"

function SheetShowcase() {
  return (
    <ComponentShowcase
      id="sheet"
      title="Sheet"
      source="src/components/sheet.tsx"
      description="侧边抽屉。常用于详情面板。支持 left / right / top / bottom 四向滑入。"
      sections={[
        {
          label: "Side · right",
          children: (
            <Sheet>
              <SheetTrigger asChild><Button variant="outline">右侧打开</Button></SheetTrigger>
              <SheetContent side="right">
                <SheetHeader>
                  <SheetTitle>登录日志详情</SheetTitle>
                  <SheetDescription>2026-05-26 09:12:33</SheetDescription>
                </SheetHeader>
                <div className="flex flex-col gap-[var(--space-3)] px-[var(--space-5)]">
                  <Skeleton className="h-4 w-4/5" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/5" />
                </div>
                <SheetFooter>
                  <Button variant="outline">关闭</Button>
                </SheetFooter>
              </SheetContent>
            </Sheet>
          ),
        },
        {
          label: "Other sides",
          children: (
            <>
              {(["left", "top", "bottom"] as const).map((side) => (
                <Sheet key={side}>
                  <SheetTrigger asChild>
                    <Button size="sm" variant="outline">{side}</Button>
                  </SheetTrigger>
                  <SheetContent side={side}>
                    <SheetHeader>
                      <SheetTitle>Side: {side}</SheetTitle>
                    </SheetHeader>
                  </SheetContent>
                </Sheet>
              ))}
            </>
          ),
        },
      ]}
    />
  )
}

export { SheetShowcase }
