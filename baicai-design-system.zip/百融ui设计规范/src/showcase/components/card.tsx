import * as React from "react"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
  StatCard,
} from "@/components/card"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function CardShowcase() {
  return (
    <ComponentShowcase
      id="card"
      title="Card"
      source="src/components/card.tsx"
      description="基础容器卡片。包含 Header / Title / Description / Content / Footer 子部件，以及 StatCard 紧凑统计卡。"
      colSpan={2}
      sections={[
        {
          label: "Full Layout",
          description: "Header (Title + Description) + Content + Footer 的完整组合",
          children: (
            <Card className="w-[320px]">
              <CardHeader>
                <CardTitle>本月招聘汇总</CardTitle>
                <CardDescription>2026 年 5 月</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-[13px] text-foreground">
                  共发布 12 个岗位，收到 248 份简历，安排 18 场面试，已发 4 个 Offer。
                </p>
              </CardContent>
              <CardFooter className="justify-end">
                <Button variant="outline" size="sm">查看详情</Button>
              </CardFooter>
            </Card>
          ),
        },
        {
          label: "StatCard · 紧凑统计卡",
          description: "label (12px muted) + value (16px semibold)，px-3 py-2。用于列表页顶部统计区（如 #sessions）",
          children: (
            <div className="grid w-full grid-cols-2 gap-[var(--space-4)] sm:grid-cols-4">
              <StatCard label="在线设备" value={128} />
              <StatCard label="活跃用户" value={89} />
              <StatCard label="5 分钟内活跃" value={34} />
              <StatCard label="空闲设备" value={39} />
            </div>
          ),
        },
      ]}
    />
  )
}

export { CardShowcase }
