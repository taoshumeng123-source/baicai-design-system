import * as React from "react"
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/hover-card"
import { Avatar, AvatarFallback } from "@/components/avatar"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function HoverCardShowcase() {
  return (
    <ComponentShowcase
      id="hover-card"
      title="Hover Card"
      source="src/components/hover-card.tsx"
      description="悬停触发的浮层，承载摘要信息。可通过 openDelay / closeDelay 调整触发节奏；side 控制方向。"
      sections={[
        {
          label: "Profile summary",
          description: "鼠标悬停在标签上 ~200ms 后展开用户摘要",
          children: (
            <HoverCard openDelay={200} closeDelay={150}>
              <HoverCardTrigger asChild>
                <button
                  type="button"
                  className="flex items-center gap-[var(--space-2)] rounded-[var(--corner-md)] border border-border bg-card px-[var(--space-3)] py-[var(--space-2)] text-[13px] text-foreground"
                >
                  <Avatar size="sm"><AvatarFallback>张</AvatarFallback></Avatar>
                  <span>张伟</span>
                </button>
              </HoverCardTrigger>
              <HoverCardContent className="w-[260px]">
                <div className="flex items-start gap-[var(--space-3)]">
                  <Avatar><AvatarFallback>张</AvatarFallback></Avatar>
                  <div>
                    <p className="text-[13px] font-semibold text-foreground">张伟</p>
                    <p className="text-[12px] text-muted-foreground">zhangwei@br.com · 技术部</p>
                    <p className="mt-[var(--space-2)] text-[12px] text-foreground">2024-03-01 加入</p>
                  </div>
                </div>
              </HoverCardContent>
            </HoverCard>
          ),
        },
        {
          label: "Side variants",
          description: "top / right / bottom / left 控制弹出方向",
          children: (
            <>
              {(["top", "right", "bottom", "left"] as const).map((side) => (
                <HoverCard key={side} openDelay={100} closeDelay={100}>
                  <HoverCardTrigger asChild>
                    <Button variant="outline" size="sm">{side}</Button>
                  </HoverCardTrigger>
                  <HoverCardContent side={side} sideOffset={6} className="w-auto px-[var(--space-3)] py-[var(--space-2)]">
                    <p className="text-[13px] text-foreground">side = {side}</p>
                  </HoverCardContent>
                </HoverCard>
              ))}
            </>
          ),
        },
        {
          label: "Delay 对比",
          description: "openDelay 控制悬停多久后弹出（默认 700ms）；closeDelay 控制鼠标离开后多久收起",
          children: (
            <>
              <HoverCard openDelay={0} closeDelay={0}>
                <HoverCardTrigger asChild>
                  <Button variant="outline" size="sm">即时（0/0）</Button>
                </HoverCardTrigger>
                <HoverCardContent className="w-auto px-[var(--space-3)] py-[var(--space-2)]">
                  <p className="text-[13px]">openDelay=0 / closeDelay=0</p>
                </HoverCardContent>
              </HoverCard>
              <HoverCard openDelay={700} closeDelay={300}>
                <HoverCardTrigger asChild>
                  <Button variant="outline" size="sm">默认（700/300）</Button>
                </HoverCardTrigger>
                <HoverCardContent className="w-auto px-[var(--space-3)] py-[var(--space-2)]">
                  <p className="text-[13px]">openDelay=700 / closeDelay=300</p>
                </HoverCardContent>
              </HoverCard>
            </>
          ),
        },
      ]}
    />
  )
}

export { HoverCardShowcase }
