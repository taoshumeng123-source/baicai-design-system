import * as React from "react"
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarSeparator,
  MenubarShortcut,
  MenubarTrigger,
} from "@/components/menubar"
import { ComponentShowcase } from "../component-showcase"

function MenubarShowcase() {
  return (
    <ComponentShowcase
      id="menubar"
      title="Menubar"
      source="src/components/menubar.tsx"
      description="桌面应用顶部菜单条。"
      sections={[
        {
          label: "Basic",
          children: (
            <Menubar>
              <MenubarMenu>
                <MenubarTrigger>文件</MenubarTrigger>
                <MenubarContent>
                  <MenubarItem>
                    新建 <MenubarShortcut>⌘N</MenubarShortcut>
                  </MenubarItem>
                  <MenubarItem>打开...</MenubarItem>
                  <MenubarSeparator />
                  <MenubarItem>保存</MenubarItem>
                </MenubarContent>
              </MenubarMenu>
              <MenubarMenu>
                <MenubarTrigger>编辑</MenubarTrigger>
                <MenubarContent>
                  <MenubarItem>撤销</MenubarItem>
                  <MenubarItem>重做</MenubarItem>
                </MenubarContent>
              </MenubarMenu>
            </Menubar>
          ),
        },
      ]}
    />
  )
}

export { MenubarShowcase }
