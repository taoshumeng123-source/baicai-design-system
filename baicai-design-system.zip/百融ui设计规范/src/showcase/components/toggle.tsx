import * as React from "react"
import { Bold, Italic, Underline } from "lucide-react"
import { Toggle } from "@/components/toggle"
import { ComponentShowcase } from "../component-showcase"

function ToggleShowcase() {
  return (
    <ComponentShowcase
      id="toggle"
      title="Toggle"
      source="src/components/toggle.tsx"
      description="单按钮 on/off 切换。variant: default / outline。size: sm / default / lg。常用于工具栏（加粗 / 斜体 / 下划线）。"
      sections={[
        {
          label: "Variants",
          description: "default（透明底，pressed 时填充 accent）/ outline（带边框）",
          children: (
            <>
              <Toggle aria-label="Bold (default)"><Bold /></Toggle>
              <Toggle aria-label="Italic (default, pressed)" pressed><Italic /></Toggle>
              <Toggle aria-label="Bold (outline)" variant="outline"><Bold /></Toggle>
              <Toggle aria-label="Italic (outline, pressed)" variant="outline" pressed><Italic /></Toggle>
            </>
          ),
        },
        {
          label: "Sizes",
          children: (
            <>
              <Toggle aria-label="Small" size="sm"><Bold /></Toggle>
              <Toggle aria-label="Default"><Bold /></Toggle>
              <Toggle aria-label="Large" size="lg"><Bold /></Toggle>
            </>
          ),
        },
        {
          label: "States",
          children: (
            <>
              <Toggle aria-label="Default"><Underline /></Toggle>
              <Toggle aria-label="Pressed" pressed><Underline /></Toggle>
              <Toggle aria-label="Disabled" disabled><Underline /></Toggle>
              <Toggle aria-label="Disabled pressed" disabled pressed><Underline /></Toggle>
            </>
          ),
        },
      ]}
    />
  )
}

export { ToggleShowcase }
