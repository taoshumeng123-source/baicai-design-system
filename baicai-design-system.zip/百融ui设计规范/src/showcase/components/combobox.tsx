import * as React from "react"
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxGroup,
  ComboboxInput,
  ComboboxItem,
  ComboboxLabel,
  ComboboxList,
} from "@/components/combobox"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

const FRAMEWORKS = [
  "Next.js",
  "Remix",
  "Astro",
  "Nuxt",
  "SvelteKit",
  "Solid Start",
  "Qwik City",
  "Gatsby",
  "Redwood",
  "RedwoodSDK",
]

function ComboboxShowcase() {
  return (
    <ComponentShowcase
      id="combobox"
      title="Combobox"
      source="src/components/combobox.tsx"
      description="可搜索的下拉选择。输入即过滤，键盘上下选择，空结果时显示 ComboboxEmpty。"
      sections={[
        {
          label: "Search & Filter",
          description: "输入 'r' 过滤 Remix / Redwood…；输入 'xxx' 触发 Empty",
          children: (
            <div className="flex w-[300px] flex-col gap-[var(--space-1_5)]">
              <Label>选择框架</Label>
              <Combobox>
                <ComboboxInput placeholder="搜索框架..." />
                <ComboboxContent>
                  <ComboboxList>
                    <ComboboxEmpty>未找到匹配项</ComboboxEmpty>
                    <ComboboxGroup>
                      <ComboboxLabel>Meta-frameworks</ComboboxLabel>
                      {FRAMEWORKS.map((f) => (
                        <ComboboxItem key={f} value={f}>{f}</ComboboxItem>
                      ))}
                    </ComboboxGroup>
                  </ComboboxList>
                </ComboboxContent>
              </Combobox>
            </div>
          ),
        },
      ]}
    />
  )
}

export { ComboboxShowcase }
