import { ChannelDonut } from "@/components/channel-donut"
import { ComponentShowcase } from "../component-showcase"

// 示例数据：与数据看板 #dashboard 招聘渠道同款（近 1 个月）。
// 颜色由调用方给出：内推用 info 色、猎头加深、校招浅紫，其余走品牌色 opacity 阶梯。
const CHANNEL_DATA = [
  { label: "BOSS直聘", value: 96, color: "var(--primary)",     opacity: 0.95, dotColor: "var(--primary)" },
  { label: "内推",     value: 58, color: "var(--info-hover)",  opacity: 1,    dotColor: "var(--info-hover)" },
  { label: "猎头",     value: 42, color: "var(--primary)",     opacity: 0.82, dotColor: "var(--primary)" },
  { label: "智联",     value: 35, color: "var(--primary)",     opacity: 0.48, dotColor: "var(--primary)" },
  { label: "校招",     value: 17, color: "var(--primary)",     opacity: 0.3,  dotColor: "var(--primary)" },
]

function ChannelDonutShowcase() {
  return (
    <ComponentShowcase
      id="channel-donut"
      title="Channel Donut"
      source="src/components/channel-donut.tsx"
      description="招聘渠道：环形图（每段竖向微弱渐变）+ 中心总计 + 右侧图例列表（色点 / 名称 / 数量 / 占比）。颜色由调用方在 data 里给出，组件保持通用。自带 hover 气泡（色点用 dotColor）。"
      colSpan={2}
      sections={[
        {
          label: "环形图 + 图例列表",
          description: "中心显示总计；hover 任意段弹气泡（纯色点）；图例固定窄列：色点 / 渠道 / 数量 / 占比",
          children: (
            <div className="w-full">
              <ChannelDonut data={CHANNEL_DATA} valueLabel="候选人数" />
            </div>
          ),
        },
      ]}
    />
  )
}

export { ChannelDonutShowcase }
