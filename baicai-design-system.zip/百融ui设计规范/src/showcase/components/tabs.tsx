import * as React from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/tabs"
import { ComponentShowcase } from "../component-showcase"

function TabsShowcase() {
  return (
    <ComponentShowcase
      id="tabs"
      title="Tabs"
      source="src/components/tabs.tsx"
      description="标签页切换。键盘 Left / Right 切换。"
      sections={[
        {
          label: "Interactive",
          children: (
            <Tabs defaultValue="overview" className="w-full">
              <TabsList>
                <TabsTrigger value="overview">概览</TabsTrigger>
                <TabsTrigger value="members">成员</TabsTrigger>
                <TabsTrigger value="logs">日志</TabsTrigger>
              </TabsList>
              <TabsContent value="overview" className="mt-[var(--space-3)] text-[13px] text-muted-foreground">
                概览：当前共 8 名成员，3 个部门，10 个角色。
              </TabsContent>
              <TabsContent value="members" className="mt-[var(--space-3)] text-[13px] text-muted-foreground">
                成员列表（mock）
              </TabsContent>
              <TabsContent value="logs" className="mt-[var(--space-3)] text-[13px] text-muted-foreground">
                操作日志（mock）
              </TabsContent>
            </Tabs>
          ),
        },
      ]}
    />
  )
}

export { TabsShowcase }
