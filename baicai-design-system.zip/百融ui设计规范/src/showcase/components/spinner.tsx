import * as React from "react"
import { Spinner } from "@/components/spinner"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function SpinnerShowcase() {
  return (
    <ComponentShowcase
      id="spinner"
      title="Spinner"
      source="src/components/spinner.tsx"
      description="加载旋转指示器。可独立使用，也可嵌入 Button / Field。"
      sections={[
        {
          label: "Sizes",
          children: (
            <>
              <Spinner className="size-3" />
              <Spinner />
              <Spinner className="size-6" />
              <Spinner className="size-8" />
            </>
          ),
        },
        {
          label: "In Button",
          children: (
            <Button disabled>
              <Spinner data-icon="inline-start" />
              加载中…
            </Button>
          ),
        },
      ]}
    />
  )
}

export { SpinnerShowcase }
