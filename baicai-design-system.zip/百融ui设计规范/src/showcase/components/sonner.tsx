import * as React from "react"
import {
  showFailureToast,
  showReminderToast,
  showSuccessToast,
} from "@/components/sonner"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function SonnerShowcase() {
  return (
    <ComponentShowcase
      id="sonner"
      title="Sonner"
      source="src/components/sonner.tsx"
      description="全局 Toast。项目封装三种语义：成功 / 提醒 / 失败。Toaster 已在 catalog 根挂载。"
      sections={[
        {
          label: "Interactive · 触发 toast",
          children: (
            <>
              <Button
                variant="outline"
                onClick={() => showSuccessToast("已保存", { description: "设置已生效" })}
              >
                成功 Toast
              </Button>
              <Button
                variant="outline"
                onClick={() => showReminderToast("提醒", { description: "下次审批请提前 1 小时设置" })}
              >
                提醒 Toast
              </Button>
              <Button
                variant="outline"
                onClick={() => showFailureToast("失败", { description: "网络异常，请稍后重试" })}
              >
                失败 Toast
              </Button>
            </>
          ),
        },
      ]}
    />
  )
}

export { SonnerShowcase }
