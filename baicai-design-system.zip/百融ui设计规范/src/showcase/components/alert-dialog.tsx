import * as React from "react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/alert-dialog"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function AlertDialogShowcase() {
  return (
    <ComponentShowcase
      id="alert-dialog"
      title="Alert Dialog"
      source="src/components/alert-dialog.tsx"
      description="阻塞型确认弹窗，用于破坏性操作前的最后确认。Esc / 点击遮罩不可关闭，必须显式点击 Cancel / Action。"
      sections={[
        {
          label: "Interactive · Destructive",
          children: (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">删除部门</Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>确认删除"技术部"？</AlertDialogTitle>
                  <AlertDialogDescription>
                    此操作无法撤回。该部门下的 3 名成员将被移至"未分配"。
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>取消</AlertDialogCancel>
                  <AlertDialogAction variant="destructive">删除</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          ),
        },
      ]}
    />
  )
}

export { AlertDialogShowcase }
