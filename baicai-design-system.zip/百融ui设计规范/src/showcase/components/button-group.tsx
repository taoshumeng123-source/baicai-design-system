import * as React from "react"
import { ButtonGroup } from "@/components/button-group"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

const TIME_RANGES = ["Day", "Week", "Month"] as const
const STATUS_FILTERS = ["All", "Active", "Pending", "Archived"] as const

function ButtonGroupShowcase() {
  const [range, setRange] = React.useState<(typeof TIME_RANGES)[number]>("Week")
  const [status, setStatus] = React.useState<(typeof STATUS_FILTERS)[number]>("All")

  return (
    <ComponentShowcase
      id="button-group"
      title="Button Group"
      source="src/components/button-group.tsx"
      description="连体边框风格：相邻 button 共享边界，整体形成圆角矩形。配合 aria-pressed 实现单选 segmented 行为；选中态用品牌浅色高亮（bg-primary-soft + text-primary）。"
      sections={[
        {
          label: "Basic · 时间维度切换（可点击）",
          description: "点击切换激活项，aria-pressed 由 state 控制",
          children: (
            <>
              <ButtonGroup>
                {TIME_RANGES.map((r) => (
                  <Button
                    key={r}
                    size="sm"
                    aria-pressed={range === r}
                    onClick={() => setRange(r)}
                  >
                    {r}
                  </Button>
                ))}
              </ButtonGroup>
              <span className="text-[12px] text-muted-foreground">
                当前选中：{range}
              </span>
            </>
          ),
        },
        {
          label: "Multi-segment · 状态筛选",
          description: "更多分段同样适用",
          children: (
            <>
              <ButtonGroup>
                {STATUS_FILTERS.map((s) => (
                  <Button
                    key={s}
                    size="sm"
                    aria-pressed={status === s}
                    onClick={() => setStatus(s)}
                  >
                    {s}
                  </Button>
                ))}
              </ButtonGroup>
              <span className="text-[12px] text-muted-foreground">
                当前选中：{status}
              </span>
            </>
          ),
        },
      ]}
    />
  )
}

export { ButtonGroupShowcase }
