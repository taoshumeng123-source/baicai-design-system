import * as React from "react"
import { NumberInput } from "@/components/number-input"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function NumberInputShowcase() {
  return (
    <ComponentShowcase
      id="number-input"
      title="Number Input"
      source="src/components/number-input.tsx"
      description="数值 + 单位组合输入框。无阴影、focus-within 高亮。常用于密码长度、天数、并发数等设置场景。"
      sections={[
        {
          label: "Basic",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-2">
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>最小长度</Label>
                <NumberInput defaultValue={8} unit="位" />
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>密码轮换周期</Label>
                <NumberInput defaultValue={90} unit="天" />
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>会话时长</Label>
                <NumberInput defaultValue={24} unit="小时" unitWidth="w-[40px]" />
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>最大并发设备</Label>
                <NumberInput defaultValue={3} unit="台" />
              </div>
            </div>
          ),
        },
        {
          label: "Disabled",
          children: (
            <div className="flex flex-col gap-[var(--space-1_5)]">
              <Label className="text-muted-foreground">不可编辑</Label>
              <NumberInput disabled defaultValue={0} unit="次" />
            </div>
          ),
        },
      ]}
    />
  )
}

export { NumberInputShowcase }
