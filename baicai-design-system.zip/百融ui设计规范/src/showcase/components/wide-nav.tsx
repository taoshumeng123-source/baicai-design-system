import * as React from "react"
import {
  History,
  KeyRound,
  Layers,
  LayoutDashboard,
  List,
  Lock,
  LogIn,
  Mail,
  Monitor,
  Network,
  Scale,
  Settings,
  Users,
} from "lucide-react"
import { WideNav, WideNavHeader, NavGroup, NavItem } from "@/components/wide-nav"
import { ComponentShowcase } from "../component-showcase"

function WideNavShowcase() {
  return (
    <ComponentShowcase
      id="wide-nav"
      title="Wide Nav"
      source="src/components/wide-nav.tsx"
      description="二级侧导航（240px）。底色 bg-sidebar-soft（浅紫），NavItem 三态统一紫色系（default/hover/active）。"
      colSpan={2}
      sections={[
        {
          label: "Full nav",
          children: (
            <div className="h-[520px] w-[240px] overflow-hidden rounded-[var(--corner-md)] border border-border">
              <WideNav header={<WideNavHeader title="系统管理" />}>
                <NavGroup label="应用与接入">
                  <NavItem icon={<LayoutDashboard className="size-[14px]" />}>应用中心</NavItem>
                  <NavItem icon={<Lock className="size-[14px]" />}>登录设置</NavItem>
                  <NavItem icon={<Monitor className="size-[14px]" />}>在线设备</NavItem>
                </NavGroup>
                <NavGroup label="组织与授权">
                  <NavItem icon={<Users className="size-[14px]" />}>成员</NavItem>
                  <NavItem icon={<Network className="size-[14px]" />}>部门</NavItem>
                  <NavItem icon={<Layers className="size-[14px]" />}>用户组</NavItem>
                  <NavItem icon={<KeyRound className="size-[14px]" />}>角色</NavItem>
                  <NavItem icon={<List className="size-[14px]" />}>权限项</NavItem>
                  <NavItem icon={<Scale className="size-[14px]" />}>权限策略</NavItem>
                </NavGroup>
                <NavGroup label="审计与风险">
                  <NavItem icon={<History className="size-[14px]" />}>操作日志</NavItem>
                  <NavItem icon={<LogIn className="size-[14px]" />}>登录日志</NavItem>
                </NavGroup>
                <NavGroup label="租户设置">
                  <NavItem icon={<Settings className="size-[14px]" />} active>通用设置</NavItem>
                  <NavItem icon={<Mail className="size-[14px]" />}>通知模板</NavItem>
                </NavGroup>
              </WideNav>
            </div>
          ),
        },
      ]}
    />
  )
}

export { WideNavShowcase }
