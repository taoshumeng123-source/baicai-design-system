import * as React from "react"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

const INDUSTRIES = [
  { value: "internet", label: "互联网" },
  { value: "finance", label: "金融" },
  { value: "manufacturing", label: "制造业" },
  { value: "healthcare", label: "医疗" },
  { value: "education", label: "教育" },
]

function SelectShowcase() {
  return (
    <ComponentShowcase
      id="select"
      title="Select"
      source="src/components/select.tsx"
      description="基于 Radix 的下拉选择。状态：default placeholder / selected / disabled / aria-invalid。"
      sections={[
        {
          label: "States",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-2">
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Placeholder</Label>
                <Select>
                  <SelectTrigger className="w-full"><SelectValue placeholder="请选择行业" /></SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map((o) => (
                      <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Selected</Label>
                <Select defaultValue="finance">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map((o) => (
                      <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Disabled</Label>
                <Select disabled defaultValue="internet">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map((o) => (
                      <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label className="text-destructive">Error (aria-invalid)</Label>
                <Select>
                  <SelectTrigger aria-invalid className="w-full"><SelectValue placeholder="必填项未选" /></SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map((o) => (
                      <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          ),
        },
        {
          label: "With Group",
          description: "SelectGroup 可叠加分组，常用于行业多级、地区分组",
          children: (
            <Select>
              <SelectTrigger className="w-[240px]"><SelectValue placeholder="选择城市" /></SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="beijing">北京</SelectItem>
                  <SelectItem value="shanghai">上海</SelectItem>
                  <SelectItem value="guangzhou">广州</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          ),
        },
      ]}
    />
  )
}

export { SelectShowcase }
