import * as React from "react"
import { AspectRatio } from "@/components/aspect-ratio"
import { ComponentShowcase } from "../component-showcase"

function AspectRatioShowcase() {
  return (
    <ComponentShowcase
      id="aspect-ratio"
      title="Aspect Ratio"
      source="src/components/aspect-ratio.tsx"
      description="维持固定宽高比的容器。常用于图片、视频、封面。"
      sections={[
        {
          label: "16/9 · 4/3 · 1/1",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-3">
              {[
                { ratio: 16 / 9, label: "16 / 9" },
                { ratio: 4 / 3, label: "4 / 3" },
                { ratio: 1, label: "1 / 1" },
              ].map((r) => (
                <div key={r.label}>
                  <AspectRatio ratio={r.ratio}>
                    <div className="flex size-full items-center justify-center rounded-[var(--corner-md)] bg-primary-soft text-[13px] text-primary">
                      {r.label}
                    </div>
                  </AspectRatio>
                </div>
              ))}
            </div>
          ),
        },
      ]}
    />
  )
}

export { AspectRatioShowcase }
