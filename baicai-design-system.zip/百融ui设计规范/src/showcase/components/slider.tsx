import * as React from "react"
import { Slider } from "@/components/slider"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function SliderShowcase() {
  const [vol, setVol] = React.useState([60])
  const [range, setRange] = React.useState([20, 80])

  return (
    <ComponentShowcase
      id="slider"
      title="Slider"
      source="src/components/slider.tsx"
      description="数值滑块。支持单值 / 区间。"
      sections={[
        {
          label: "Single",
          children: (
            <div className="flex w-[320px] flex-col gap-[var(--space-2)]">
              <div className="flex justify-between text-[12px] text-muted-foreground">
                <span>音量</span>
                <span>{vol[0]}</span>
              </div>
              <Slider value={vol} onValueChange={setVol} max={100} step={1} />
            </div>
          ),
        },
        {
          label: "Range",
          children: (
            <div className="flex w-[320px] flex-col gap-[var(--space-2)]">
              <div className="flex justify-between text-[12px] text-muted-foreground">
                <span>价格区间</span>
                <span>{range[0]} – {range[1]}</span>
              </div>
              <Slider value={range} onValueChange={setRange} max={100} step={5} />
            </div>
          ),
        },
      ]}
    />
  )
}

export { SliderShowcase }
