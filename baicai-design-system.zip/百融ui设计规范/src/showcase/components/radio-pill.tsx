import * as React from "react"
import { RadioPill } from "@/components/radio-pill"
import { ComponentShowcase } from "../component-showcase"

function RadioPillShowcase() {
  const [value, setValue] = React.useState("90")

  return (
    <ComponentShowcase
      id="radio-pill"
      title="Radio Pill"
      source="src/components/radio-pill.tsx"
      description="Ring 样式的胶囊单选。带 4px 紫色内环，无中心圆点。"
      sections={[
        {
          label: "Interactive",
          children: (
            <>
              {[
                { v: "30", label: "30 天" },
                { v: "90", label: "90 天（推荐）" },
                { v: "180", label: "180 天" },
                { v: "365", label: "365 天" },
              ].map((o) => (
                <RadioPill
                  key={o.v}
                  active={value === o.v}
                  label={o.label}
                  onSelect={() => setValue(o.v)}
                />
              ))}
            </>
          ),
        },
        {
          label: "Disabled",
          children: (
            <>
              <RadioPill active={false} label="禁用 · 未选" onSelect={() => {}} disabled />
              <RadioPill active label="禁用 · 已选" onSelect={() => {}} disabled />
            </>
          ),
        },
      ]}
    />
  )
}

export { RadioPillShowcase }
