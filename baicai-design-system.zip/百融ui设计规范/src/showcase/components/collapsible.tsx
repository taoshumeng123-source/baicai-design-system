import * as React from "react"
import { ChevronDown } from "lucide-react"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/collapsible"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function CollapsibleShowcase() {
  return (
    <ComponentShowcase
      id="collapsible"
      title="Collapsible"
      source="src/components/collapsible.tsx"
      description="折叠基本原语，自行控制 trigger / content。"
      sections={[
        {
          label: "Interactive",
          children: (
            <Collapsible className="w-full">
              <CollapsibleTrigger asChild>
                <Button variant="outline" className="w-full justify-between">
                  高级筛选
                  <ChevronDown className="size-[14px]" />
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="mt-[var(--space-2)] rounded-[var(--corner-md)] border border-border bg-card px-[var(--space-4)] py-[var(--space-3)] text-[13px] text-muted-foreground">
                这里放进阶筛选条件，如时间区间、IP、风险标记...
              </CollapsibleContent>
            </Collapsible>
          ),
        },
      ]}
    />
  )
}

export { CollapsibleShowcase }
