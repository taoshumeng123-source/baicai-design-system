import * as React from "react"
import {
  Avatar,
  AvatarBadge,
  AvatarFallback,
  AvatarGroup,
  AvatarGroupCount,
} from "@/components/avatar"
import { ComponentShowcase } from "../component-showcase"

function AvatarShowcase() {
  return (
    <ComponentShowcase
      id="avatar"
      title="Avatar"
      source="src/components/avatar.tsx"
      description="头像。size: sm / default / lg；自动 Fallback 首字母；可叠加 AvatarBadge 标记在线 / 警告等状态；AvatarGroup 重叠展示。"
      colSpan={2}
      sections={[
        {
          label: "Sizes",
          children: (
            <>
              <Avatar name="Mia Chen" size="sm"><AvatarFallback /></Avatar>
              <Avatar name="Alex Li"><AvatarFallback /></Avatar>
              <Avatar name="Nina Tan" size="lg"><AvatarFallback /></Avatar>
            </>
          ),
        },
        {
          label: "Badge variants",
          description: "5 种：default（紫，bg-primary）/ success / warning / destructive / muted",
          children: (
            <>
              <Avatar name="李雷"><AvatarFallback /><AvatarBadge variant="default" /></Avatar>
              <Avatar name="张伟"><AvatarFallback /><AvatarBadge variant="success" /></Avatar>
              <Avatar name="李娜"><AvatarFallback /><AvatarBadge variant="warning" /></Avatar>
              <Avatar name="王芳"><AvatarFallback /><AvatarBadge variant="destructive" /></Avatar>
              <Avatar name="赵磊"><AvatarFallback /><AvatarBadge variant="muted" /></Avatar>
            </>
          ),
        },
        {
          label: "Group with overflow",
          children: (
            <AvatarGroup>
              <Avatar name="A"><AvatarFallback /></Avatar>
              <Avatar name="B"><AvatarFallback /></Avatar>
              <Avatar name="C"><AvatarFallback /></Avatar>
              <AvatarGroupCount>+5</AvatarGroupCount>
            </AvatarGroup>
          ),
        },
      ]}
    />
  )
}

export { AvatarShowcase }
