import * as React from "react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/table"
import { Skeleton } from "@/components/skeleton"
import { ComponentShowcase } from "../component-showcase"

function TableSkeletonShowcase() {
  return (
    <ComponentShowcase
      id="table-skeleton"
      title="Table Skeleton"
      source="src/components/table-skeleton.tsx"
      description="表格加载占位。结构参考 Members 业务页 Table 样式（table-fixed + 8 列 + Checkbox 列 + Avatar/Badge 单元格），body 用 Skeleton 占位。"
      colSpan={2}
      sections={[
        {
          label: "Members table · 完整骨架",
          description: "8 列 + Checkbox 占位 + Avatar 圆形 + 多行文字 + Badge 形占位",
          children: (
            <div className="w-full">
              <Table className="table-fixed">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40px]"></TableHead>
                    <TableHead className="w-[25%]">成员</TableHead>
                    <TableHead className="w-[12%]">所属部门</TableHead>
                    <TableHead className="w-[18%]">用户组</TableHead>
                    <TableHead className="w-[12%]">角色</TableHead>
                    <TableHead className="w-[8%]">状态</TableHead>
                    <TableHead className="w-[12%]">加入时间</TableHead>
                    <TableHead className="w-[8%]">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell className="w-[40px]">
                        <Skeleton className="size-4 rounded-[var(--corner-xs)]" />
                      </TableCell>

                      <TableCell>
                        <div className="flex items-center gap-[var(--space-2)]">
                          <Skeleton className="size-8 rounded-full" />
                          <div className="flex flex-col gap-[4px]">
                            <Skeleton className="h-3 w-20" />
                            <Skeleton className="h-[10px] w-32" />
                          </div>
                        </div>
                      </TableCell>

                      <TableCell>
                        <Skeleton className="h-3 w-16" />
                      </TableCell>

                      <TableCell>
                        <div className="flex flex-wrap gap-[var(--space-1)]">
                          <Skeleton className="h-5 w-14 rounded-[var(--corner-sm)]" />
                          <Skeleton className="h-5 w-12 rounded-[var(--corner-sm)]" />
                        </div>
                      </TableCell>

                      <TableCell>
                        <Skeleton className="h-5 w-16 rounded-[var(--corner-sm)]" />
                      </TableCell>

                      <TableCell>
                        <Skeleton className="h-5 w-12 rounded-[var(--corner-sm)]" />
                      </TableCell>

                      <TableCell>
                        <Skeleton className="h-3 w-20" />
                      </TableCell>

                      <TableCell>
                        <Skeleton className="h-3 w-8" />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ),
        },
      ]}
    />
  )
}

export { TableSkeletonShowcase }
