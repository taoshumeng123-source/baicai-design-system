import * as React from "react"
import { ChevronRight, FileText, Mail } from "lucide-react"
import {
  Item,
  ItemActions,
  ItemContent,
  ItemDescription,
  ItemGroup,
  ItemMedia,
  ItemTitle,
} from "@/components/item"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function ItemShowcase() {
  return (
    <ComponentShowcase
      id="item"
      title="Item"
      source="src/components/item.tsx"
      description="行级列表元素原语：Item / ItemMedia / ItemContent / ItemTitle / ItemDescription / ItemActions。"
      sections={[
        {
          label: "Group",
          children: (
            <ItemGroup className="w-full">
              <Item>
                <ItemMedia><FileText className="size-[16px] text-primary" /></ItemMedia>
                <ItemContent>
                  <ItemTitle>2026 Q1 招聘需求</ItemTitle>
                  <ItemDescription>共 12 个岗位 · 上次更新 3 小时前</ItemDescription>
                </ItemContent>
                <ItemActions>
                  <Button size="icon-sm" variant="ghost" aria-label="详情">
                    <ChevronRight className="size-[14px]" />
                  </Button>
                </ItemActions>
              </Item>
              <Item>
                <ItemMedia><Mail className="size-[16px] text-info" /></ItemMedia>
                <ItemContent>
                  <ItemTitle>系统通知</ItemTitle>
                  <ItemDescription>本周日维护，期间不可访问</ItemDescription>
                </ItemContent>
                <ItemActions>
                  <Button size="icon-sm" variant="ghost" aria-label="详情">
                    <ChevronRight className="size-[14px]" />
                  </Button>
                </ItemActions>
              </Item>
            </ItemGroup>
          ),
        },
      ]}
    />
  )
}

export { ItemShowcase }
