import * as React from "react"
import { Settings } from "lucide-react"
import { TopPageBar } from "@/components/top-page-bar"
import { ComponentShowcase } from "../component-showcase"

function TopPageBarShowcase() {
  return (
    <ComponentShowcase
      id="top-page-bar"
      title="Top Page Bar"
      source="src/components/top-page-bar.tsx"
      description="顶部导航条，纯面包屑布局。背景 bg-card/80 + backdrop-blur-md，模拟 macOS 风格的半透明高斯模糊导航。"
      colSpan={2}
      sections={[
        {
          label: "Breadcrumb",
          description: "传 breadcrumb 渲染面包屑行（48px）。标题/操作 由 PageTitleHeader 在内容区独立呈现，不在导航条内。",
          children: (
            <div className="w-full overflow-hidden rounded-[var(--corner-md)] border border-border">
              <TopPageBar
                breadcrumb={[
                  { icon: <Settings className="size-[14px]" />, label: "系统管理" },
                  { label: "通用设置" },
                ]}
              />
            </div>
          ),
        },
      ]}
    />
  )
}

export { TopPageBarShowcase }
