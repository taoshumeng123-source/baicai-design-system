import * as React from "react"
import { Plus, Search, Trash2 } from "lucide-react"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/tooltip"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function TooltipShowcase() {
  return (
    <ComponentShowcase
      id="tooltip"
      title="Tooltip"
      source="src/components/tooltip.tsx"
      description={
        "黑底白字气泡提示。规范见 SKILL.md §19.11。严禁用原生 title=。"
      }
      sections={[
        {
          label: "Sides",
          description: "top / right / bottom / left",
          children: (
            <TooltipProvider delayDuration={300}>
              {(["top", "right", "bottom", "left"] as const).map((side) => (
                <Tooltip key={side}>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="sm" aria-label={side}>{side}</Button>
                  </TooltipTrigger>
                  <TooltipContent side={side} sideOffset={6}>
                    side = {side}
                  </TooltipContent>
                </Tooltip>
              ))}
            </TooltipProvider>
          ),
        },
        {
          label: "Icon-only buttons",
          description: "搭配 aria-label + Tooltip，无障碍",
          children: (
            <TooltipProvider delayDuration={300}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon-xs" variant="ghost" aria-label="添加">
                    <Plus className="size-[14px]" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="top" sideOffset={6}>添加</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon-xs" variant="ghost" aria-label="搜索">
                    <Search className="size-[14px]" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="top" sideOffset={6}>搜索</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon-xs" variant="ghost" aria-label="删除">
                    <Trash2 className="size-[14px] text-destructive" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="top" sideOffset={6}>删除</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ),
        },
      ]}
    />
  )
}

export { TooltipShowcase }
