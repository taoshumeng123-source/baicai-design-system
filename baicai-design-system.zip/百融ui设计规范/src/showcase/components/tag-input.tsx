import * as React from "react"
import { TagInput } from "@/components/tag-input"
import { ComponentShowcase } from "../component-showcase"

function TagInputShowcase() {
  const [tags, setTags] = React.useState<string[]>(["Frontend", "B 端", "招聘"])

  return (
    <ComponentShowcase
      id="tag-input"
      title="Tag Input"
      source="src/components/tag-input.tsx"
      description="标签输入框。回车添加，Backspace 删除最后一个。"
      sections={[
        {
          label: "Interactive",
          children: (
            <div className="w-[420px]">
              <TagInput value={tags} onChange={setTags} placeholder="输入标签后回车" />
            </div>
          ),
        },
      ]}
    />
  )
}

export { TagInputShowcase }
