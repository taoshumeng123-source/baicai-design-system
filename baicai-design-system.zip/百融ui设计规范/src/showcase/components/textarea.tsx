import * as React from "react"
import { Textarea } from "@/components/textarea"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function TextareaShowcase() {
  return (
    <ComponentShowcase
      id="textarea"
      title="Textarea"
      source="src/components/textarea.tsx"
      description="多行文本输入。默认 min-h，可垂直拉伸。状态：default / focus / disabled / error。"
      sections={[
        {
          label: "States",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-2">
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Default</Label>
                <Textarea placeholder="请输入..." />
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Filled</Label>
                <Textarea defaultValue="百融云创成立于 2014 年，是一家以人工智能和大数据技术为驱动的金融数字化服务提供商。" />
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Disabled</Label>
                <Textarea disabled defaultValue="不可编辑的内容" />
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label className="text-destructive">Error (aria-invalid)</Label>
                <Textarea aria-invalid defaultValue="字数超出限制" />
              </div>
            </div>
          ),
        },
      ]}
    />
  )
}

export { TextareaShowcase }
