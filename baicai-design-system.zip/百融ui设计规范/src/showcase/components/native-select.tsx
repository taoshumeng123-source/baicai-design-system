import * as React from "react"
import {
  NativeSelect,
  NativeSelectOption,
  NativeSelectOptGroup,
} from "@/components/native-select"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function NativeSelectShowcase() {
  return (
    <ComponentShowcase
      id="native-select"
      title="Native Select"
      source="src/components/native-select.tsx"
      description="基于原生 <select> 的轻量包装。Trigger 圆角 rounded-md (8px) 与 Input / Select 一致；下拉菜单由浏览器 / OS 原生渲染（CSS 不可控），如需项目规范风格的下拉视觉请用 Select 组件。优势：移动端体验友好、键盘可访问、轻量。"
      sections={[
        {
          label: "States · Sizes",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-2">
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Default · sm</Label>
                <NativeSelect size="sm" defaultValue="beijing">
                  <NativeSelectOption value="beijing">北京</NativeSelectOption>
                  <NativeSelectOption value="shanghai">上海</NativeSelectOption>
                  <NativeSelectOption value="shenzhen">深圳</NativeSelectOption>
                </NativeSelect>
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Default · default</Label>
                <NativeSelect defaultValue="cn">
                  <NativeSelectOption value="cn">简体中文</NativeSelectOption>
                  <NativeSelectOption value="en">English</NativeSelectOption>
                </NativeSelect>
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>Disabled</Label>
                <NativeSelect disabled defaultValue="cn">
                  <NativeSelectOption value="cn">简体中文</NativeSelectOption>
                </NativeSelect>
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label className="text-destructive">Error (aria-invalid)</Label>
                <NativeSelect aria-invalid defaultValue="">
                  <NativeSelectOption value="">请选择</NativeSelectOption>
                  <NativeSelectOption value="cn">简体中文</NativeSelectOption>
                </NativeSelect>
              </div>
            </div>
          ),
        },
        {
          label: "Optgroup",
          children: (
            <NativeSelect defaultValue="beijing">
              <NativeSelectOptGroup label="华北">
                <NativeSelectOption value="beijing">北京</NativeSelectOption>
                <NativeSelectOption value="tianjin">天津</NativeSelectOption>
              </NativeSelectOptGroup>
              <NativeSelectOptGroup label="华东">
                <NativeSelectOption value="shanghai">上海</NativeSelectOption>
                <NativeSelectOption value="hangzhou">杭州</NativeSelectOption>
              </NativeSelectOptGroup>
            </NativeSelect>
          ),
        },
      ]}
    />
  )
}

export { NativeSelectShowcase }
