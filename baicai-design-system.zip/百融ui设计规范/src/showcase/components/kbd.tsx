import * as React from "react"
import { Kbd, KbdGroup } from "@/components/kbd"
import { ComponentShowcase } from "../component-showcase"

function KbdShowcase() {
  return (
    <ComponentShowcase
      id="kbd"
      title="Kbd"
      source="src/components/kbd.tsx"
      description="键盘按键提示。可组合 KbdGroup 展示快捷键。"
      sections={[
        {
          label: "Basic",
          children: (
            <>
              <Kbd>Esc</Kbd>
              <Kbd>Tab</Kbd>
              <Kbd>Enter</Kbd>
              <Kbd>⌘</Kbd>
              <Kbd>⇧</Kbd>
            </>
          ),
        },
        {
          label: "Combinations",
          children: (
            <>
              <KbdGroup>
                <Kbd>⌘</Kbd>
                <Kbd>K</Kbd>
              </KbdGroup>
              <KbdGroup>
                <Kbd>⌘</Kbd>
                <Kbd>⇧</Kbd>
                <Kbd>P</Kbd>
              </KbdGroup>
            </>
          ),
        },
      ]}
    />
  )
}

export { KbdShowcase }
