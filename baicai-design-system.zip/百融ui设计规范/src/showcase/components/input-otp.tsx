import * as React from "react"
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSeparator,
  InputOTPSlot,
} from "@/components/input-otp"
import { ComponentShowcase } from "../component-showcase"

function InputOTPShowcase() {
  return (
    <ComponentShowcase
      id="input-otp"
      title="Input OTP"
      source="src/components/input-otp.tsx"
      description="一次性密码输入。独立长方形 slot（48×40）+ 8px 间距；支持 6 位（3+3 分组）/ 4 位 / 自定义分组。"
      sections={[
        {
          label: "6-digit · 3+3 分组",
          description: "中间用 InputOTPSeparator 分隔，常用于短信验证码 6 位场景",
          children: (
            <InputOTP maxLength={6}>
              <InputOTPGroup>
                <InputOTPSlot index={0} />
                <InputOTPSlot index={1} />
                <InputOTPSlot index={2} />
              </InputOTPGroup>
              <InputOTPSeparator />
              <InputOTPGroup>
                <InputOTPSlot index={3} />
                <InputOTPSlot index={4} />
                <InputOTPSlot index={5} />
              </InputOTPGroup>
            </InputOTP>
          ),
        },
        {
          label: "4-digit · 单组",
          description: "4 位 PIN 码 / 邮箱验证码场景，无分隔符",
          children: (
            <InputOTP maxLength={4}>
              <InputOTPGroup>
                <InputOTPSlot index={0} />
                <InputOTPSlot index={1} />
                <InputOTPSlot index={2} />
                <InputOTPSlot index={3} />
              </InputOTPGroup>
            </InputOTP>
          ),
        },
        {
          label: "6-digit · 单组无分隔",
          description: "6 位连续展示，不分组",
          children: (
            <InputOTP maxLength={6}>
              <InputOTPGroup>
                {Array.from({ length: 6 }).map((_, i) => (
                  <InputOTPSlot key={i} index={i} />
                ))}
              </InputOTPGroup>
            </InputOTP>
          ),
        },
      ]}
    />
  )
}

export { InputOTPShowcase }
