import * as React from "react"
import {
  DataTable,
  type DataTableColumn,
  type DataTableModule,
} from "@/components/data-table"
import { Badge } from "@/components/badge"
import { ComponentShowcase } from "../component-showcase"

type Row = {
  id: string
  position: string
  company: string
  city: string
  resumes: string
  interviews: string
  offers: string
  conversion: string
  budget: string
  spend: string
  priority: string
  dueDate: string
  owner: string
  status: string
  variant: "success" | "warning" | "info" | "destructive"
}

const ROWS: Row[] = [
  { id: "1", position: "前端工程师", company: "百融云创", city: "北京", resumes: "128", interviews: "18", offers: "4", conversion: "14.3%", budget: "18w", spend: "6.2w", priority: "高", dueDate: "04/30", owner: "Mia", status: "进行中", variant: "info" },
  { id: "2", position: "产品经理", company: "百融云创", city: "上海", resumes: "74", interviews: "9", offers: "2", conversion: "10.8%", budget: "15w", spend: "5.6w", priority: "中", dueDate: "05/16", owner: "Ian", status: "待推进", variant: "warning" },
  { id: "3", position: "Java 工程师", company: "百融云创", city: "深圳", resumes: "64", interviews: "8", offers: "1", conversion: "7.8%", budget: "22w", spend: "8.4w", priority: "高", dueDate: "05/12", owner: "Nina", status: "预警", variant: "destructive" },
  { id: "4", position: "数据分析师", company: "百融云创", city: "杭州", resumes: "112", interviews: "14", offers: "3", conversion: "12.5%", budget: "11w", spend: "3.7w", priority: "中", dueDate: "05/20", owner: "Amy", status: "进行中", variant: "info" },
  { id: "5", position: "客户成功", company: "天九集团", city: "广州", resumes: "58", interviews: "7", offers: "1", conversion: "8.2%", budget: "9w", spend: "2.9w", priority: "低", dueDate: "05/24", owner: "Chen", status: "已完成", variant: "success" },
]

const LEFT: DataTableColumn<Row>[] = [
  {
    key: "position",
    label: "岗位",
    width: 200,
    render: (r) => (
      <div>
        <p className="font-medium">{r.position}</p>
        <p className="text-[11px] text-muted-foreground">{r.company}</p>
      </div>
    ),
  },
]

const MODULES: DataTableModule<Row>[] = [
  {
    key: "funnel",
    label: "招聘漏斗",
    description: "候选人流转",
    tint: "blue",
    columns: [
      { key: "resumes", label: "简历", width: 88, align: "right", render: (r) => r.resumes },
      { key: "interviews", label: "面试", width: 88, align: "right", render: (r) => r.interviews },
      { key: "offers", label: "Offer", width: 88, align: "right", render: (r) => r.offers },
    ],
  },
  {
    key: "conversion",
    label: "转化质量",
    description: "Offer 转化率",
    tint: "emerald",
    columns: [
      {
        key: "conversion",
        label: "转化率",
        width: 96,
        align: "right",
        render: (r) => <span className="font-medium text-foreground">{r.conversion}</span>,
      },
    ],
  },
  {
    key: "budget",
    label: "预算成本",
    description: "薪酬与消耗",
    tint: "amber",
    columns: [
      { key: "budget", label: "预算", width: 88, align: "right", render: (r) => r.budget },
      { key: "spend", label: "已用", width: 88, align: "right", render: (r) => r.spend },
    ],
  },
  {
    key: "source",
    label: "渠道来源",
    description: "城市与渠道",
    tint: "violet",
    defaultVisible: false,
    columns: [
      { key: "city", label: "城市", width: 96, render: (r) => r.city },
    ],
  },
  {
    key: "priority",
    label: "优先级",
    description: "交付节奏",
    defaultVisible: false,
    columns: [
      { key: "priority", label: "优先级", width: 88, render: (r) => r.priority },
      { key: "dueDate", label: "截止", width: 88, render: (r) => r.dueDate },
    ],
  },
]

const RIGHT: DataTableColumn<Row>[] = [
  { key: "owner", label: "负责人", width: 96, render: (r) => r.owner },
  {
    key: "status",
    label: "状态",
    width: 96,
    render: (r) => (
      <Badge size="sm" variant={r.variant}>
        {r.status}
      </Badge>
    ),
  },
]

function DataTableShowcase() {
  return (
    <ComponentShowcase
      id="data-table"
      title="Data Table"
      source="src/components/data-table.tsx"
      description="可配置列分组（modules）的复杂数据表。左/右 sticky 列 + 多 tint 模块列；defaultVisible=false 的模块默认隐藏，可在顶部工具栏切换显示。"
      colSpan={2}
      sections={[
        {
          label: "Full configuration",
          description: "5 个 module（3 默认显示 + 2 默认隐藏）+ 左 sticky 岗位列 + 右 sticky 负责人/状态列",
          children: (
            <div className="w-full">
              <DataTable
                rows={ROWS}
                getRowId={(r) => r.id}
                leftColumns={LEFT}
                modules={MODULES}
                rightColumns={RIGHT}
              />
            </div>
          ),
        },
      ]}
    />
  )
}

export { DataTableShowcase }
