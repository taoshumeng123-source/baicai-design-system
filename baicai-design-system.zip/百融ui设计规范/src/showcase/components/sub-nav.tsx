import * as React from "react"
import { Copy, Plus, Trash2 } from "lucide-react"
import { SubNav, SubNavGroup, SubNavItem } from "@/components/sub-nav"
import { Button } from "@/components/button"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/tooltip"
import { ComponentShowcase } from "../component-showcase"

type Role = {
  id: string
  name: string
  type: "system" | "custom"
  memberCount: number
}

const SYSTEM_ROLES: Role[] = [
  { id: "r1", name: "超级管理员", type: "system", memberCount: 2 },
  { id: "r2", name: "管理员", type: "system", memberCount: 8 },
  { id: "r3", name: "普通成员", type: "system", memberCount: 156 },
]

const CUSTOM_ROLES: Role[] = [
  { id: "r4", name: "HR 专员", type: "custom", memberCount: 23 },
  { id: "r5", name: "部门负责人", type: "custom", memberCount: 12 },
  { id: "r6", name: "面试官", type: "custom", memberCount: 45 },
  { id: "r7", name: "外部顾问", type: "custom", memberCount: 3 },
  { id: "r8", name: "数据分析师", type: "custom", memberCount: 5 },
]

function SubNavShowcase() {
  const [selectedId, setSelectedId] = React.useState("r4")

  return (
    <TooltipProvider delayDuration={300}>
      <ComponentShowcase
        id="sub-nav"
        title="Sub Nav"
        source="src/components/sub-nav.tsx"
        description="三级导航。220px 宽左侧 master-detail 选择栏：SubNavGroup 分组标题（可带操作按钮）+ SubNavItem 条目（支持 count / lock / hover 替换图标操作）。"
        colSpan={2}
        sections={[
          {
            label: "Roles · 系统角色 + 自定义角色（可点击）",
            description: "系统组：locked icon + 始终显示 count；自定义组：分组标题旁带「新建」+ icon-xs Tooltip，条目 hover 时 count 替换为「复制 / 删除」图标",
            children: (
              <div className="flex h-[480px] w-full overflow-hidden rounded-[var(--corner-lg)] border border-border bg-background">
                <SubNav>
                  <SubNavGroup label="系统角色">
                    {SYSTEM_ROLES.map((role) => (
                      <SubNavItem
                        key={role.id}
                        selected={selectedId === role.id}
                        onSelect={() => setSelectedId(role.id)}
                        count={role.memberCount}
                        locked
                      >
                        {role.name}
                      </SubNavItem>
                    ))}
                  </SubNavGroup>

                  <SubNavGroup
                    label="自定义角色"
                    action={
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon-xs"
                            aria-label="新建角色"
                            onClick={() => console.log("新建角色")}
                          >
                            <Plus className="size-[14px]" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent side="right" sideOffset={6}>
                          新建角色
                        </TooltipContent>
                      </Tooltip>
                    }
                  >
                    {CUSTOM_ROLES.map((role) => (
                      <SubNavItem
                        key={role.id}
                        selected={selectedId === role.id}
                        onSelect={() => setSelectedId(role.id)}
                        count={role.memberCount}
                        actions={[
                          {
                            icon: <Copy className="size-[11px]" />,
                            label: "复制权限",
                            onClick: () => console.log("复制", role.id),
                          },
                          {
                            icon: <Trash2 className="size-[11px]" />,
                            label: "删除角色",
                            onClick: () => console.log("删除", role.id),
                            destructive: true,
                          },
                        ]}
                      >
                        {role.name}
                      </SubNavItem>
                    ))}
                  </SubNavGroup>
                </SubNav>

                <div className="flex flex-1 items-center justify-center px-[var(--space-6)] py-[var(--space-5)] text-[12px] text-muted-foreground">
                  右侧为主面板示意区
                </div>
              </div>
            ),
          },
        ]}
      />
    </TooltipProvider>
  )
}

export { SubNavShowcase }
