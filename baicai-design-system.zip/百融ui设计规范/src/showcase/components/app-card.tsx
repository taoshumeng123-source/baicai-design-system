import * as React from "react"
import { Briefcase, Code2, Database, Mic } from "lucide-react"
import { AppCard } from "@/components/app-card"
import { ComponentShowcase } from "../component-showcase"

function AppCardShowcase() {
  return (
    <ComponentShowcase
      id="app-card"
      title="App Card"
      source="src/components/app-card.tsx"
      description="应用中心卡片。active（已上线，Info 色）/ enabled（已开通，Success 色）可 hover 抬升 + 点击跳转；coming_soon（即将上线）状态置灰，无 hover。"
      colSpan={2}
      sections={[
        {
          label: "States · active / enabled / coming_soon",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-4)] sm:grid-cols-2 xl:grid-cols-4">
              <AppCard
                icon={<Briefcase className="size-[18px]" />}
                iconBg="bg-primary-soft"
                iconColor="text-primary"
                name="招聘"
                category="HR"
                description="一站式招聘流程：JD → 候选人 → 面试 → Offer"
                status="active"
              />
              <AppCard
                icon={<Database className="size-[18px]" />}
                iconBg="bg-info-soft"
                iconColor="text-info"
                name="智源"
                category="数据"
                description="简历解析 / 画像 / 智能匹配"
                status="active"
              />
              <AppCard
                icon={<Code2 className="size-[18px]" />}
                iconBg="bg-success-soft"
                iconColor="text-success"
                name="智码"
                category="测评"
                description="Vibe Coding 测评：Claude Code + AI 评分"
                status="enabled"
              />
              <AppCard
                icon={<Mic className="size-[18px]" />}
                iconBg="bg-warning-soft"
                iconColor="text-warning"
                name="智面"
                category="面试"
                description="AI 智能面试 Agent"
                status="coming_soon"
              />
            </div>
          ),
        },
      ]}
    />
  )
}

export { AppCardShowcase }
