import * as React from "react"
import { AlertCircle, CheckCircle, Info, XCircle } from "lucide-react"
import { Alert, AlertClose, AlertDescription, AlertTitle } from "@/components/alert"
import { ComponentShowcase } from "../component-showcase"

function AlertShowcase() {
  return (
    <ComponentShowcase
      id="alert"
      title="Alert"
      source="src/components/alert.tsx"
      description="非阻塞提示横幅。5 个 variant (default / info / success / warning / destructive)；图标 16×16 与第一行文字垂直居中对齐，description 12px；可选 AlertClose 关闭按钮。"
      colSpan={2}
      sections={[
        {
          label: "Variants · with title + description + close",
          children: (
            <div className="flex w-full flex-col gap-[var(--space-3)]">
              <Alert variant="info">
                <Info />
                <AlertTitle>系统通知</AlertTitle>
                <AlertDescription>本周日 02:00 - 04:00 将进行系统升级，期间可能短暂不可用。</AlertDescription>
                <AlertClose />
              </Alert>
              <Alert variant="success">
                <CheckCircle />
                <AlertTitle>保存成功</AlertTitle>
                <AlertDescription>您的设置已生效。</AlertDescription>
                <AlertClose />
              </Alert>
              <Alert variant="warning">
                <AlertCircle />
                <AlertTitle>注意</AlertTitle>
                <AlertDescription>检测到 3 条异地登录，请及时检查账号安全。</AlertDescription>
                <AlertClose />
              </Alert>
              <Alert variant="destructive">
                <XCircle />
                <AlertTitle>操作失败</AlertTitle>
                <AlertDescription>密码错误次数过多，账号已临时锁定 30 分钟。</AlertDescription>
                <AlertClose />
              </Alert>
            </div>
          ),
        },
        {
          label: "Single-line · 仅图标 + 一行文字 + close",
          description: "紧凑型 Alert，去掉 AlertTitle，整体更扁，适合行内提示 / 顶部通知条",
          children: (
            <div className="flex w-full flex-col gap-[var(--space-3)]">
              <Alert variant="info">
                <Info />
                <AlertDescription>本周日 02:00 - 04:00 将进行系统升级</AlertDescription>
                <AlertClose />
              </Alert>
              <Alert variant="success">
                <CheckCircle />
                <AlertDescription>设置已保存并生效</AlertDescription>
                <AlertClose />
              </Alert>
              <Alert variant="warning">
                <AlertCircle />
                <AlertDescription>检测到 3 条异地登录，请及时检查</AlertDescription>
                <AlertClose />
              </Alert>
              <Alert variant="destructive">
                <XCircle />
                <AlertDescription>密码错误次数过多，账号已锁定 30 分钟</AlertDescription>
                <AlertClose />
              </Alert>
            </div>
          ),
        },
      ]}
    />
  )
}

export { AlertShowcase }
