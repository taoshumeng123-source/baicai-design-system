import * as React from "react"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/accordion"
import { ComponentShowcase } from "../component-showcase"

function AccordionShowcase() {
  return (
    <ComponentShowcase
      id="accordion"
      title="Accordion"
      source="src/components/accordion.tsx"
      description="可折叠列表。type='single' 单展开，type='multiple' 多展开。"
      colSpan={2}
      sections={[
        {
          label: "Single (collapsible)",
          description: "同时只能展开一项，再次点击当前项可全部收起",
          children: (
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="a">
                <AccordionTrigger>什么是 RBAC？</AccordionTrigger>
                <AccordionContent>
                  基于角色的访问控制（Role-Based Access Control），通过角色集中管理权限授予。
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="b">
                <AccordionTrigger>什么是 ABAC？</AccordionTrigger>
                <AccordionContent>
                  基于属性的访问控制（Attribute-Based Access Control），用属性策略动态判断权限。
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="c">
                <AccordionTrigger>本系统采用哪种？</AccordionTrigger>
                <AccordionContent>
                  采用 RBAC 为主，对部分场景叠加 ABAC 策略（如数据范围隔离）。
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          ),
        },
        {
          label: "Multiple",
          description: "可同时展开多项；默认展开 'a' 和 'b' 两条",
          children: (
            <Accordion type="multiple" defaultValue={["a", "b"]} className="w-full">
              <AccordionItem value="a">
                <AccordionTrigger>密码策略</AccordionTrigger>
                <AccordionContent>
                  最少 8 位，需包含大小写字母 + 数字；90 天强制更新。
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="b">
                <AccordionTrigger>会话策略</AccordionTrigger>
                <AccordionContent>
                  默认会话 24 小时；空闲超时 30 分钟；最多 3 个并发设备。
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="c">
                <AccordionTrigger>MFA 策略</AccordionTrigger>
                <AccordionContent>
                  管理员强制 MFA；其他用户可选；支持 TOTP / 短信。
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          ),
        },
      ]}
    />
  )
}

export { AccordionShowcase }
