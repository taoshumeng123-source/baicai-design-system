import * as React from "react"
import { ConfirmDialog } from "@/components/confirm-dialog"
import { Button } from "@/components/button"
import { showSuccessToast } from "@/components/sonner"
import { ComponentShowcase } from "../component-showcase"

function ConfirmDialogShowcase() {
  const [openA, setOpenA] = React.useState(false)
  const [openB, setOpenB] = React.useState(false)
  const [loading, setLoading] = React.useState(false)

  function handleDestructive() {
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      setOpenB(false)
      showSuccessToast("已删除")
    }, 600)
  }

  return (
    <ComponentShowcase
      id="confirm-dialog"
      title="Confirm Dialog"
      source="src/components/confirm-dialog.tsx"
      description="对 Dialog 的快捷封装，统一确认/取消 + loading + destructive 状态。"
      sections={[
        {
          label: "Default",
          children: (
            <>
              <Button variant="outline" onClick={() => setOpenA(true)}>提交申请</Button>
              <ConfirmDialog
                open={openA}
                onOpenChange={setOpenA}
                title="提交招聘需求？"
                description="提交后等待 HR 审核，预计 1-2 个工作日。"
                onConfirm={() => { setOpenA(false); showSuccessToast("已提交") }}
              />
            </>
          ),
        },
        {
          label: "Destructive · Loading",
          children: (
            <>
              <Button variant="destructive" onClick={() => setOpenB(true)}>移除候选人</Button>
              <ConfirmDialog
                open={openB}
                onOpenChange={setOpenB}
                title="确认移除候选人？"
                description="此操作不会通知候选人，但其简历将从招聘列表中移除。"
                confirmLabel="移除"
                destructive
                loading={loading}
                onConfirm={handleDestructive}
              />
            </>
          ),
        },
      ]}
    />
  )
}

export { ConfirmDialogShowcase }
