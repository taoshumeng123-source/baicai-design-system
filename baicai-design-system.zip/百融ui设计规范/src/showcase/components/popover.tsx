import * as React from "react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/popover"
import { Button } from "@/components/button"
import { Input } from "@/components/input"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function PopoverShowcase() {
  return (
    <ComponentShowcase
      id="popover"
      title="Popover"
      source="src/components/popover.tsx"
      description="轻量悬浮面板，可包含表单/操作。点击外部自动关闭。可指定 side 控制弹出方向。"
      sections={[
        {
          label: "Form inside",
          children: (
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline">编辑标签</Button>
              </PopoverTrigger>
              <PopoverContent className="w-[260px]">
                <div className="flex flex-col gap-[var(--space-3)]">
                  <div className="flex flex-col gap-[var(--space-1_5)]">
                    <Label>标签名称</Label>
                    <Input defaultValue="重点跟进" />
                  </div>
                  <div className="flex justify-end gap-[var(--space-2)]">
                    <Button size="sm" variant="outline">取消</Button>
                    <Button size="sm">保存</Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          ),
        },
        {
          label: "Side variants",
          description: "top / right / bottom / left 控制弹出方向",
          children: (
            <>
              {(["top", "right", "bottom", "left"] as const).map((side) => (
                <Popover key={side}>
                  <PopoverTrigger asChild>
                    <Button size="sm" variant="outline">{side}</Button>
                  </PopoverTrigger>
                  <PopoverContent side={side} sideOffset={6} className="w-auto px-[var(--space-3)] py-[var(--space-2)]">
                    <p className="text-[13px] text-foreground">side = {side}</p>
                  </PopoverContent>
                </Popover>
              ))}
            </>
          ),
        },
      ]}
    />
  )
}

export { PopoverShowcase }
