import * as React from "react"
import { Label } from "@/components/label"
import { Input } from "@/components/input"
import { Checkbox } from "@/components/checkbox"
import { ComponentShowcase } from "../component-showcase"

function LabelShowcase() {
  return (
    <ComponentShowcase
      id="label"
      title="Label"
      source="src/components/label.tsx"
      description="表单标签。配 htmlFor 与对应控件关联，点击 label 自动聚焦/切换控件。"
      sections={[
        {
          label: "With Input",
          children: (
            <div className="flex w-[260px] flex-col gap-[var(--space-1_5)]">
              <Label htmlFor="lb-email">邮箱</Label>
              <Input id="lb-email" type="email" placeholder="you@example.com" />
            </div>
          ),
        },
        {
          label: "Inline · with Checkbox",
          children: (
            <div className="flex items-center gap-[var(--space-2)]">
              <Checkbox id="lb-agree" />
              <Label htmlFor="lb-agree">我已阅读并同意服务条款</Label>
            </div>
          ),
        },
      ]}
    />
  )
}

export { LabelShowcase }
