import * as React from "react"
import { Switch } from "@/components/switch"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function SwitchShowcase() {
  return (
    <ComponentShowcase
      id="switch"
      title="Switch"
      source="src/components/switch.tsx"
      description="开关控件。状态：off / on / disabled。"
      sections={[
        {
          label: "States",
          children: (
            <>
              <div className="flex items-center gap-[var(--space-2)]">
                <Switch id="sw-1" />
                <Label htmlFor="sw-1">Off</Label>
              </div>
              <div className="flex items-center gap-[var(--space-2)]">
                <Switch id="sw-2" defaultChecked />
                <Label htmlFor="sw-2">On</Label>
              </div>
              <div className="flex items-center gap-[var(--space-2)]">
                <Switch id="sw-3" disabled />
                <Label htmlFor="sw-3" className="text-muted-foreground">Disabled · Off</Label>
              </div>
              <div className="flex items-center gap-[var(--space-2)]">
                <Switch id="sw-4" disabled defaultChecked />
                <Label htmlFor="sw-4" className="text-muted-foreground">Disabled · On</Label>
              </div>
            </>
          ),
        },
      ]}
    />
  )
}

export { SwitchShowcase }
