import * as React from "react"
import { EmptyState } from "@/components/empty-state"
import { EmptyActionLink } from "@/components/empty"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function EmptyStateShowcase() {
  return (
    <ComponentShowcase
      id="empty-state"
      title="Empty State"
      source="src/components/empty-state.tsx"
      description="5 种语义化空态：no-data / no-content / no-result / no-permission / network-error；2 种 size：default / sm；可选 action / description / icon。"
      colSpan={2}
      sections={[
        {
          label: "All 5 variants · default size · with action / description",
          description: "完整形态：插图 + 标题 + 描述（可含 EmptyActionLink）+ 操作按钮",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-3">
              <EmptyState
                variant="no-data"
                title="暂无数据"
                description={<>暂无数据，请<EmptyActionLink>添加</EmptyActionLink></>}
                action={<Button size="sm">去添加</Button>}
              />
              <EmptyState
                variant="no-content"
                title="暂无内容"
                description="还没有任何内容，去创建吧"
                action={<Button size="sm">立即创建</Button>}
              />
              <EmptyState
                variant="no-result"
                title="暂无结果"
                description="未找到匹配项，请调整筛选条件"
              />
              <EmptyState
                variant="no-permission"
                title="暂无权限"
                description="您没有访问该功能的权限"
                action={<Button size="sm" variant="outline">联系管理员</Button>}
              />
              <EmptyState
                variant="network-error"
                title="网络异常"
                description={<>网络异常，请<EmptyActionLink>刷新</EmptyActionLink></>}
                action={<Button size="sm">刷新</Button>}
              />
            </div>
          ),
        },
        {
          label: "Sm size · 紧凑模式",
          description: "插图与文字均缩小，适合 inline 嵌入卡片 / 抽屉 / 弹窗内部",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-3">
              <EmptyState
                size="sm"
                variant="no-data"
                title="暂无数据"
                description="点击右上 + 添加第一条"
              />
              <EmptyState
                size="sm"
                variant="no-result"
                title="未匹配"
                description="调整筛选试试"
              />
              <EmptyState
                size="sm"
                variant="network-error"
                title="网络异常"
                action={<Button size="sm" variant="outline">重试</Button>}
              />
            </div>
          ),
        },
        {
          label: "Title only · 最简形态",
          description: "无 description、无 action，仅插图 + 标题。常用于占位强提示场景",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-3">
              <EmptyState variant="no-data" title="暂无数据" />
              <EmptyState variant="no-permission" title="暂无权限" />
              <EmptyState variant="no-content" title="敬请期待" />
            </div>
          ),
        },
      ]}
    />
  )
}

export { EmptyStateShowcase }
