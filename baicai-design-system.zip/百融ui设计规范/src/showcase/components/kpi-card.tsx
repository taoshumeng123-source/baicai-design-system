import { Briefcase, CircleCheck, Send, UserPlus } from "lucide-react"

import { KpiCard } from "@/components/kpi-card"
import { TooltipProvider } from "@/components/tooltip"
import { ComponentShowcase } from "../component-showcase"

// 示例数据：与数据看板 #dashboard 同款（本月口径 KPI）
const KPI_CARDS = [
  {
    label: "本月简历投递", value: "248", trend: "+12%", trendDir: "up" as const, note: "较上月", icon: Send,
    series: [185, 142, 168, 210, 196, 248],
    compare: {
      rows: [
        { label: "本月", value: "248" },
        { label: "上月", value: "221", delta: "+27", pct: "+12%" },
        { label: "去年同期", value: "210", delta: "+38", pct: "+18%" },
      ],
      trend: [185, 142, 168, 210, 196, 248],
      extra: "近 6 月峰值 248（5月）· 均值 192",
    },
  },
  {
    label: "在招职位数", value: "18", trend: "+5", trendDir: "up" as const, note: "本月新开", icon: Briefcase,
    series: [12, 13, 14, 15, 16, 18],
    compare: {
      rows: [
        { label: "本月", value: "18" },
        { label: "上月", value: "13", delta: "+5", pct: "+38%" },
        { label: "去年同期", value: "15", delta: "+3", pct: "+20%" },
      ],
      trend: [12, 13, 14, 15, 16, 18],
      extra: "目标 20 · 缺口 2",
    },
  },
  {
    label: "面试通过率", value: "34%", trend: "+5%", trendDir: "up" as const, note: "较上月", icon: CircleCheck,
    series: [28, 30, 29, 32, 31, 34],
    compare: {
      rows: [
        { label: "本月", value: "34%" },
        { label: "上月", value: "32.4%", delta: "+1.6pt", pct: "+5%" },
        { label: "去年同期", value: "30.4%", delta: "+3.6pt", pct: "+12%" },
      ],
      trend: [28, 30, 29, 32, 31, 34],
      extra: "行业基准 28%",
    },
  },
  {
    label: "本月入职", value: "6", trend: "75%", trendDir: "none" as const, note: "目标完成率", icon: UserPlus,
    series: [3, 4, 5, 4, 6, 6],
    compare: {
      rows: [
        { label: "本月", value: "6" },
        { label: "上月", value: "5", delta: "+1", pct: "+20%" },
        { label: "去年同期", value: "4", delta: "+2", pct: "+50%" },
      ],
      trend: [3, 4, 5, 4, 6, 6],
      extra: "目标 8 · 缺口 2",
    },
  },
]

function KpiCardShowcase() {
  return (
    <ComponentShowcase
      id="kpi-card"
      title="KPI Card"
      source="src/components/kpi-card.tsx"
      description="数据看板 KPI 玻璃卡：玻璃渐变卡 + icon tile + 大数字 + 趋势 + 右下迷你柱图。传入 compare 时 hover 弹「数据对比」气泡（真实数值表 + 近 6 月趋势）。需置于 TooltipProvider 内。"
      colSpan={2}
      sections={[
        {
          label: "一排 4 个 · hover 弹数据对比气泡",
          description: "普通月柱用 --primary-border 浅紫渐变，最新月用 --primary 高亮；hover 卡片弹出真实数值对比",
          children: (
            <TooltipProvider delayDuration={150}>
              <div className="grid w-full grid-cols-4 gap-[var(--space-4)]">
                {KPI_CARDS.map((card) => (
                  <KpiCard key={card.label} {...card} />
                ))}
              </div>
            </TooltipProvider>
          ),
        },
        {
          label: "无 compare · 纯展示卡（不弹气泡）",
          children: (
            <div className="w-[280px]">
              <KpiCard
                label="本月简历投递"
                value="248"
                trend="+12%"
                trendDir="up"
                note="较上月"
                icon={Send}
                series={[185, 142, 168, 210, 196, 248]}
              />
            </div>
          ),
        },
      ]}
    />
  )
}

export { KpiCardShowcase }
