import * as React from "react"
import { AlertCircle, ArrowRight, Copy, MoreHorizontal, Search, Settings } from "lucide-react"
import { Button } from "@/components/button"
import { Spinner } from "@/components/spinner"
import { ComponentShowcase } from "../component-showcase"

function ButtonShowcase() {
  return (
    <ComponentShowcase
      id="button"
      title="Button"
      source="src/components/button.tsx"
      description="6 个 variant、3 个文本尺寸、3 个 icon-only 尺寸；支持 asChild、ButtonGroup 组合。"
      colSpan={2}
      sections={[
        {
          label: "Variants",
          description: "default / secondary / outline / ghost / destructive / link",
          children: (
            <>
              <Button>Default</Button>
              <Button variant="secondary">Secondary</Button>
              <Button variant="outline">Outline</Button>
              <Button variant="ghost">Ghost</Button>
              <Button variant="destructive">
                <AlertCircle data-icon="inline-start" />
                Destructive
              </Button>
              <Button variant="link">Link</Button>
            </>
          ),
        },
        {
          label: "Sizes",
          description: "sm / default / lg；icon / icon-sm / icon-xs",
          children: (
            <>
              <Button size="sm">Small</Button>
              <Button>Default</Button>
              <Button size="lg">Large</Button>
              <Button aria-label="Settings" size="icon">
                <Settings />
              </Button>
              <Button aria-label="Search" size="icon-sm" variant="outline">
                <Search />
              </Button>
              <Button aria-label="More" size="icon-xs" variant="ghost">
                <MoreHorizontal />
              </Button>
            </>
          ),
        },
        {
          label: "States",
          description: "default / hover（鼠标悬停查看）/ active（按住）/ disabled / loading",
          children: (
            <>
              <Button>Default</Button>
              <Button disabled>Disabled</Button>
              <Button disabled variant="outline">Disabled Outline</Button>
              <Button disabled>
                <Spinner data-icon="inline-start" />
                Loading
              </Button>
            </>
          ),
        },
        {
          label: "Icon · Inline / Composition",
          description: "图标在前/后；asChild 透传",
          children: (
            <>
              <Button>
                <Search data-icon="inline-start" />
                Search
              </Button>
              <Button variant="outline">
                Next
                <ArrowRight data-icon="inline-end" />
              </Button>
              <Button asChild variant="link">
                <a href="#button">As link</a>
              </Button>
              <Button size="sm" variant="outline">
                <Copy data-icon="inline-start" />
                Copy
              </Button>
            </>
          ),
        },
      ]}
    />
  )
}

export { ButtonShowcase }
