import * as React from "react"
import { DirectionProvider } from "@/components/direction"
import { Input } from "@/components/input"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function DirectionShowcase() {
  return (
    <ComponentShowcase
      id="direction"
      title="Direction"
      source="src/components/direction.tsx"
      description="RTL / LTR 方向 Provider。子组件 hover / focus 等位置感知会随方向翻转。"
      sections={[
        {
          label: "LTR (default)",
          children: (
            <DirectionProvider dir="ltr">
              <div className="flex w-full flex-col gap-[var(--space-1_5)]">
                <Label>姓名</Label>
                <Input placeholder="Latin script" />
              </div>
            </DirectionProvider>
          ),
        },
        {
          label: "RTL",
          children: (
            <DirectionProvider dir="rtl">
              <div className="flex w-full flex-col gap-[var(--space-1_5)]" dir="rtl">
                <Label>الاسم</Label>
                <Input placeholder="اكتب هنا" />
              </div>
            </DirectionProvider>
          ),
        },
      ]}
    />
  )
}

export { DirectionShowcase }
