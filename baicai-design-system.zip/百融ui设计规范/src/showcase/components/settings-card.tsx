import * as React from "react"
import { SettingsCard, FieldRow } from "@/components/settings-card"
import { Input } from "@/components/input"
import { NumberInput } from "@/components/number-input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/select"
import { Switch } from "@/components/switch"
import { ComponentShowcase } from "../component-showcase"

function SettingsCardShowcase() {
  return (
    <ComponentShowcase
      id="settings-card"
      title="Settings Card"
      source="src/components/settings-card.tsx"
      description="B 端设置页核心容器。header 单行紧凑（44px）；FieldRow 默认 layout='split'（label 左 / 控件右，两端对齐）。"
      colSpan={2}
      sections={[
        {
          label: "Default · 两端对齐 (layout='split')",
          description: "label 居左、控件靠右；description 跟随 label 下方",
          children: (
            <SettingsCard title="租户基本信息" className="w-full">
              <FieldRow label="企业名称">
                <Input className="w-[320px]" defaultValue="百融云创" />
              </FieldRow>
              <FieldRow label="最大并发设备" description="同一账号允许同时在线的设备数，0 不限">
                <NumberInput defaultValue={3} unit="台" />
              </FieldRow>
              <FieldRow label="启用 MFA" description="管理员强制开启二次验证">
                <Switch defaultChecked />
              </FieldRow>
              <FieldRow label="日报推送">
                <Switch />
              </FieldRow>
            </SettingsCard>
          ),
        },
        {
          label: "Multiple controls · 两端对齐（统一 layout='split'）",
          description: "更多控件类型混排：Input / Select / NumberInput / Switch，全部两端对齐",
          children: (
            <SettingsCard title="域名与审计" className="w-full">
              <FieldRow label="主域名" description="用于多租户隔离与登录入口">
                <Input className="w-[320px]" defaultValue="bairong.com" />
              </FieldRow>
              <FieldRow label="时区" description="影响日志时间显示">
                <Select defaultValue="Asia/Shanghai">
                  <SelectTrigger className="w-[200px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Asia/Shanghai">Asia/Shanghai</SelectItem>
                    <SelectItem value="Asia/Hong_Kong">Asia/Hong_Kong</SelectItem>
                    <SelectItem value="Asia/Tokyo">Asia/Tokyo</SelectItem>
                    <SelectItem value="Asia/Singapore">Asia/Singapore</SelectItem>
                    <SelectItem value="Europe/London">Europe/London</SelectItem>
                    <SelectItem value="America/New_York">America/New_York</SelectItem>
                    <SelectItem value="UTC">UTC</SelectItem>
                  </SelectContent>
                </Select>
              </FieldRow>
              <FieldRow label="日志保留天数">
                <NumberInput defaultValue={90} unit="天" />
              </FieldRow>
              <FieldRow label="启用审计日志">
                <Switch defaultChecked />
              </FieldRow>
            </SettingsCard>
          ),
        },
      ]}
    />
  )
}

export { SettingsCardShowcase }
