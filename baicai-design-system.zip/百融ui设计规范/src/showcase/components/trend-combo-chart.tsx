import { TrendComboChart } from "@/components/trend-combo-chart"
import { ComponentShowcase } from "../component-showcase"

// 示例数据：与数据看板 #dashboard 招聘趋势同款（近 6 月）
const TREND_DATA = [
  { month: "12月", applied: 185, interview: 62, hired: 18, rate: 16 },
  { month: "1月",  applied: 142, interview: 48, hired: 12, rate: 20 },
  { month: "2月",  applied: 168, interview: 55, hired: 15, rate: 19 },
  { month: "3月",  applied: 210, interview: 71, hired: 20, rate: 27 },
  { month: "4月",  applied: 196, interview: 66, hired: 17, rate: 31 },
  { month: "5月",  applied: 248, interview: 84, hired: 23, rate: 34 },
]

const BARS = [
  { key: "applied",   label: "简历投递数", color: "var(--primary-border)", gradient: { from: 1, to: 0.55 } },
  { key: "interview", label: "面试数",     color: "var(--info-hover)",     gradient: { from: 1, to: 0.8 } },
  { key: "hired",     label: "入职数",     color: "var(--primary)",        gradient: { from: 0.95, to: 0.5 } },
]

const LINE = { key: "rate", label: "面试通过率", color: "var(--chart-1)" }

function TrendComboChartShowcase() {
  return (
    <ComponentShowcase
      id="trend-combo-chart"
      title="Trend Combo Chart"
      source="src/components/trend-combo-chart.tsx"
      description="招聘趋势：分组柱（每柱按 color 生成竖向微弱渐变）+ 折线（右轴 %）+ 双 Y 轴。hover 游标为覆盖整组的全高浅灰渐变面块。复用 @/components/chart。"
      colSpan={2}
      sections={[
        {
          label: "分组柱 + 折线 · 双 Y 轴",
          description: "左轴为人数（柱），右轴为通过率 %（折线）；hover 任意月份弹整组浅灰游标 + tooltip",
          children: (
            <div className="w-full">
              <TrendComboChart
                data={TREND_DATA}
                bars={BARS}
                line={LINE}
                xKey="month"
                rightDomain={[0, 50]}
                rightTicks={[0, 10, 20, 30, 40, 50]}
              />
            </div>
          ),
        },
      ]}
    />
  )
}

export { TrendComboChartShowcase }
