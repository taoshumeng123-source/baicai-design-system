import * as React from "react"
import { Field, FieldDescription, FieldGroup, FieldLabel } from "@/components/field"
import { Input } from "@/components/input"
import { ComponentShowcase } from "../component-showcase"

function FieldGroupShowcase() {
  return (
    <ComponentShowcase
      id="field-group"
      title="Field Group"
      source="src/components/field.tsx"
      description="Field 的纵向组容器，自动控制字段间距，常用于表单中段。"
      sections={[
        {
          label: "Basic",
          children: (
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="fg-name">姓名</FieldLabel>
                <Input id="fg-name" placeholder="请输入" />
              </Field>
              <Field>
                <FieldLabel htmlFor="fg-email">邮箱</FieldLabel>
                <Input id="fg-email" type="email" placeholder="you@example.com" />
                <FieldDescription>用于接收通知邮件。</FieldDescription>
              </Field>
            </FieldGroup>
          ),
        },
      ]}
    />
  )
}

export { FieldGroupShowcase }
