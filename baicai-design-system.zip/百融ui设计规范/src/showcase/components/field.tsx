import * as React from "react"
import {
  Field,
  FieldContent,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
  FieldSeparator,
  FieldSet,
  FieldTitle,
} from "@/components/field"
import { Input } from "@/components/input"
import { Switch } from "@/components/switch"
import { ComponentShowcase } from "../component-showcase"

// 与 #command 同款独立卡片外壳；540px 保证内宽 500 ≥ 448 (@md 容器查询断点)，触发 responsive Field 横排
const CARD_CLASS =
  "w-[540px] rounded-[var(--corner-md)] border border-border bg-card px-[var(--space-5)] py-[var(--space-4)] shadow-[var(--shadow-control)]"

function FieldShowcase() {
  return (
    <ComponentShowcase
      id="field"
      title="Field"
      source="src/components/field.tsx"
      description="表单字段原语：FieldSet / FieldGroup / Field / FieldLabel / FieldContent / FieldTitle / FieldDescription / FieldSeparator / FieldError。"
      colSpan={2}
      sections={[
        {
          label: "Basic · vertical + horizontal",
          children: (
            <FieldSet className={CARD_CLASS}>
              <FieldGroup>
                <Field>
                  <FieldLabel htmlFor="f-username">用户名</FieldLabel>
                  <Input id="f-username" placeholder="3-20 个字符" />
                  <FieldDescription>用户名一经创建不可修改。</FieldDescription>
                </Field>
                <Field orientation="horizontal">
                  <FieldContent>
                    <FieldTitle>双因子认证</FieldTitle>
                    <FieldDescription>开启后登录时需输入 OTP 验证码。</FieldDescription>
                  </FieldContent>
                  <Switch defaultChecked />
                </Field>
              </FieldGroup>
            </FieldSet>
          ),
        },
        {
          label: "States · invalid / disabled / FieldError",
          description: "通过 data-invalid / aria-invalid 触发红色错误态；group 内 disabled 让 Label 半透明",
          children: (
            <FieldSet className={CARD_CLASS}>
              <FieldGroup>
                <Field data-invalid="true">
                  <FieldLabel htmlFor="f-email">邮箱</FieldLabel>
                  <Input id="f-email" aria-invalid defaultValue="invalid@" />
                  <FieldError>请输入有效的邮箱地址</FieldError>
                </Field>
                <Field data-disabled="true">
                  <FieldLabel htmlFor="f-phone">手机号</FieldLabel>
                  <Input id="f-phone" disabled defaultValue="13800138000" />
                  <FieldDescription>不可编辑（已通过验证）</FieldDescription>
                </Field>
              </FieldGroup>
            </FieldSet>
          ),
        },
        {
          label: "Separator · 分组 + 中间标记",
          description: "FieldSeparator 在 FieldGroup 内插入水平分隔；带 children 时显示 \"or\" 等中间标记",
          children: (
            <FieldSet className={CARD_CLASS}>
              <FieldGroup>
                <Field>
                  <FieldLabel htmlFor="f-account">账号 + 密码</FieldLabel>
                  <Input id="f-account" placeholder="邮箱 / 手机号" />
                </Field>
                <FieldSeparator>or</FieldSeparator>
                <Field orientation="horizontal">
                  <FieldContent>
                    <FieldTitle>SSO 单点登录</FieldTitle>
                    <FieldDescription>通过企业身份提供商一键登录</FieldDescription>
                  </FieldContent>
                  <Switch />
                </Field>
              </FieldGroup>
            </FieldSet>
          ),
        },
        {
          label: "Responsive · 窄屏纵排 / 宽屏横排",
          description: "orientation='responsive'：< md (448px) 容器纵向堆叠，≥ md 容器自动转横向。Switch 等固定尺寸控件不适合作为 responsive 子项（参见上方 Basic / Separator section 的 horizontal Switch 用法）",
          children: (
            <FieldSet className={CARD_CLASS}>
              <FieldGroup>
                <Field orientation="responsive">
                  <FieldLabel htmlFor="f-resp-1">企业名称</FieldLabel>
                  <Input id="f-resp-1" placeholder="3-100 个字符" />
                </Field>
                <Field orientation="responsive">
                  <FieldLabel htmlFor="f-resp-2">联系邮箱</FieldLabel>
                  <Input id="f-resp-2" type="email" placeholder="hr@example.com" />
                </Field>
              </FieldGroup>
            </FieldSet>
          ),
        },
      ]}
    />
  )
}

export { FieldShowcase }
