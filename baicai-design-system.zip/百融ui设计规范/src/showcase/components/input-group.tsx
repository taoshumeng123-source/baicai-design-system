import * as React from "react"
import { Mail, Search } from "lucide-react"
import {
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  InputGroupInput,
  InputGroupText,
} from "@/components/input-group"
import { Label } from "@/components/label"
import { ComponentShowcase } from "../component-showcase"

function InputGroupShowcase() {
  return (
    <ComponentShowcase
      id="input-group"
      title="Input Group"
      source="src/components/input-group.tsx"
      description="Input 的组合容器，支持前后缀图标 / 文本 / 按钮 / 单位。"
      sections={[
        {
          label: "Variants",
          children: (
            <div className="grid w-full grid-cols-1 gap-[var(--space-3)] sm:grid-cols-2">
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>前置图标</Label>
                <InputGroup>
                  <InputGroupAddon><Search /></InputGroupAddon>
                  <InputGroupInput placeholder="搜索" />
                </InputGroup>
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>邮箱</Label>
                <InputGroup>
                  <InputGroupAddon><Mail /></InputGroupAddon>
                  <InputGroupInput placeholder="you@example.com" />
                </InputGroup>
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>金额（后置单位）</Label>
                <InputGroup>
                  <InputGroupInput placeholder="0" />
                  <InputGroupAddon align="inline-end"><InputGroupText>元</InputGroupText></InputGroupAddon>
                </InputGroup>
              </div>
              <div className="flex flex-col gap-[var(--space-1_5)]">
                <Label>带操作按钮</Label>
                <InputGroup>
                  <InputGroupInput placeholder="项目名" />
                  <InputGroupAddon align="inline-end">
                    <InputGroupButton>创建</InputGroupButton>
                  </InputGroupAddon>
                </InputGroup>
              </div>
            </div>
          ),
        },
      ]}
    />
  )
}

export { InputGroupShowcase }
