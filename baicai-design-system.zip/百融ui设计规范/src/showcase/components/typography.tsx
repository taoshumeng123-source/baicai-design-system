import * as React from "react"
import {
  TypographyH1,
  TypographyH2,
  TypographyH3,
  TypographyH4,
  TypographyP,
  TypographyLarge,
  TypographyLabel,
  TypographySmall,
  TypographyMuted,
  TypographyDisplay,
  TypographyInlineCode,
} from "@/components/typography"
import { ComponentShowcase } from "../component-showcase"

function Row({ spec, children }: { spec: string; children: React.ReactNode }) {
  return (
    <div className="flex w-full items-baseline justify-between gap-[var(--space-4)] border-b border-border/60 py-[var(--space-2)] last:border-b-0">
      <div className="min-w-0 flex-1">{children}</div>
      <span className="shrink-0 font-mono text-[11px] leading-[16px] text-muted-foreground">
        {spec}
      </span>
    </div>
  )
}

function TypographyComponentShowcase() {
  return (
    <ComponentShowcase
      id="typography"
      title="Typography"
      source="src/components/typography.tsx"
      description="按 B 端 case 页实际用量重新校准的语义化文本组件。所有尺寸/行高/字重/默认色已烤进 className，不带 margin（交给容器 gap-* 处理）。右侧 spec 列示意 size/leading/weight/color。"
      colSpan={2}
      sections={[
        {
          label: "Headings · 页面层级",
          description: "页面标题 H1 与 PageTitleHeader 对齐；H2 用于弹窗/区块；H3-H4 用于子区块",
          children: (
            <div className="flex w-full flex-col">
              <Row spec="20/32 · bold · foreground">
                <TypographyH1>H1 · 页面标题</TypographyH1>
              </Row>
              <Row spec="15/24 · semibold · foreground">
                <TypographyH2>H2 · 弹窗 / 区块标题</TypographyH2>
              </Row>
              <Row spec="14/22 · semibold · foreground">
                <TypographyH3>H3 · 子区块标题（如权限模块）</TypographyH3>
              </Row>
              <Row spec="13/20 · semibold · foreground">
                <TypographyH4>H4 · 卡片内子项</TypographyH4>
              </Row>
            </div>
          ),
        },
        {
          label: "Body · 正文与段落",
          description: "P 为正文默认（12px，最常见）；Large 用于次级描述/列表项；Muted 用于段落级弱化提示",
          children: (
            <div className="flex w-full flex-col">
              <Row spec="12/20 · normal · foreground">
                <TypographyP>
                  P · 正文默认。本系统采用 RBAC 模型管理角色与权限。
                </TypographyP>
              </Row>
              <Row spec="13/20 · normal · foreground">
                <TypographyLarge>
                  Large · 次级描述、列表项。比 P 略大，常用于卡片内的二级文本。
                </TypographyLarge>
              </Row>
              <Row spec="12/20 · normal · muted-foreground">
                <TypographyMuted>
                  Muted · 段落级 muted 提示。颜色比 P 更浅。
                </TypographyMuted>
              </Row>
            </div>
          ),
        },
        {
          label: "Inline · 行内文本",
          description: "Label 为表单 label（12px 中粗）；Small 为元数据/脚注（11px muted）；InlineCode 为行内代码标记",
          children: (
            <div className="flex w-full flex-col">
              <Row spec="12/20 · medium · foreground">
                <TypographyLabel>Label · 表单字段标签</TypographyLabel>
              </Row>
              <Row spec="11/16 · normal · muted-foreground">
                <TypographySmall>
                  Small · 元数据 / 表头 caption / 脚注
                </TypographySmall>
              </Row>
              <Row spec="12 · mono · bg-muted">
                <p className="text-[12px] leading-[20px] text-foreground">
                  行内代码：
                  <TypographyInlineCode>var(--primary)</TypographyInlineCode>
                </p>
              </Row>
            </div>
          ),
        },
        {
          label: "Display · 数据强调",
          description: "Display 用于 Dashboard 等场景的 KPI 大数字",
          children: (
            <div className="flex w-full flex-col">
              <Row spec="28/36 · bold · foreground">
                <TypographyDisplay>1,284</TypographyDisplay>
              </Row>
            </div>
          ),
        },
      ]}
    />
  )
}

export { TypographyComponentShowcase }
