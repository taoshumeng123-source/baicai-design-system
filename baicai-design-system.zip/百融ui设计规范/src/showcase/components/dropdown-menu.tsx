import * as React from "react"
import { MoreHorizontal } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuTrigger,
} from "@/components/dropdown-menu"
import { Button } from "@/components/button"
import { ComponentShowcase } from "../component-showcase"

function DropdownMenuShowcase() {
  return (
    <ComponentShowcase
      id="dropdown-menu"
      title="Dropdown Menu"
      source="src/components/dropdown-menu.tsx"
      description='点击触发的下拉菜单。常用于行内"更多操作"。'
      sections={[
        {
          label: "Interactive",
          children: (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon-sm" aria-label="更多操作">
                  <MoreHorizontal className="size-[14px]" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>账号操作</DropdownMenuLabel>
                <DropdownMenuItem>查看资料</DropdownMenuItem>
                <DropdownMenuItem>
                  编辑 <DropdownMenuShortcut>⌘E</DropdownMenuShortcut>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive">删除账号</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ),
        },
      ]}
    />
  )
}

export { DropdownMenuShowcase }
