import * as React from "react"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  Pie,
  PieChart,
  PolarAngleAxis,
  RadialBar,
  RadialBarChart,
  XAxis,
} from "recharts"
import {
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/chart"
import { ComponentShowcase } from "../component-showcase"

// ─── 数据 ─────────────────────────────────────────────────────────────────────

const MONTHLY = [
  { month: "1月", resumes: 86, interviews: 18 },
  { month: "2月", resumes: 124, interviews: 32 },
  { month: "3月", resumes: 162, interviews: 41 },
  { month: "4月", resumes: 138, interviews: 28 },
  { month: "5月", resumes: 204, interviews: 56 },
  { month: "6月", resumes: 186, interviews: 47 },
]

const STATUS = [
  { key: "screening", label: "筛选", value: 42, fill: "var(--chart-1)" },
  { key: "interview", label: "面试", value: 28, fill: "var(--chart-2)" },
  { key: "offer", label: "Offer", value: 18, fill: "var(--chart-3)" },
  { key: "hired", label: "入职", value: 12, fill: "var(--chart-4)" },
]

const RADIAL = [
  { name: "Q1", value: 62, fill: "var(--chart-1)" },
  { name: "Q2", value: 78, fill: "var(--chart-3)" },
  { name: "Q3", value: 45, fill: "var(--chart-4)" },
  { name: "Q4", value: 91, fill: "var(--chart-5)" },
]

const FUNNEL_CONFIG = {
  resumes: { label: "简历", color: "var(--chart-1)" },
  interviews: { label: "面试", color: "var(--chart-2)" },
} satisfies ChartConfig

const STATUS_CONFIG = {
  screening: { label: "筛选", color: "var(--chart-1)" },
  interview: { label: "面试", color: "var(--chart-2)" },
  offer: { label: "Offer", color: "var(--chart-3)" },
  hired: { label: "入职", color: "var(--chart-4)" },
} satisfies ChartConfig

const RADIAL_CONFIG = {
  Q1: { label: "Q1", color: "var(--chart-1)" },
  Q2: { label: "Q2", color: "var(--chart-3)" },
  Q3: { label: "Q3", color: "var(--chart-4)" },
  Q4: { label: "Q4", color: "var(--chart-5)" },
} satisfies ChartConfig

// 统一图表外壳：固定 240px 高 + 100% 宽，覆盖 ChartContainer 默认 aspect-video
function ChartBox({ children }: { children: React.ReactNode }) {
  return <div className="h-[240px] w-full">{children}</div>
}

// ─── Showcase ────────────────────────────────────────────────────────────────

function ChartShowcase() {
  return (
    <ComponentShowcase
      id="chart"
      title="Chart"
      source="src/components/chart.tsx"
      description="recharts 包装：ChartContainer / ChartTooltip / ChartLegend / ChartStyle。统一 token 色板 (--chart-1..5) 和 tooltip 样式。"
      colSpan={2}
      sections={[
        {
          label: "Bar · 多系列 + Legend",
          children: (
            <ChartBox>
              <ChartContainer config={FUNNEL_CONFIG} className="!aspect-auto h-full w-full">
                <BarChart data={MONTHLY}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <ChartLegend content={<ChartLegendContent />} />
                  <Bar dataKey="resumes" radius={6} fill="var(--color-resumes)" />
                  <Bar dataKey="interviews" radius={6} fill="var(--color-interviews)" />
                </BarChart>
              </ChartContainer>
            </ChartBox>
          ),
        },
        {
          label: "Bar · 堆叠",
          children: (
            <ChartBox>
              <ChartContainer config={FUNNEL_CONFIG} className="!aspect-auto h-full w-full">
                <BarChart data={MONTHLY}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <ChartLegend content={<ChartLegendContent />} />
                  <Bar dataKey="resumes" stackId="a" fill="var(--color-resumes)" />
                  <Bar dataKey="interviews" stackId="a" fill="var(--color-interviews)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ChartContainer>
            </ChartBox>
          ),
        },
        {
          label: "Line · 趋势",
          children: (
            <ChartBox>
              <ChartContainer config={FUNNEL_CONFIG} className="!aspect-auto h-full w-full">
                <LineChart data={MONTHLY}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <ChartLegend content={<ChartLegendContent />} />
                  <Line
                    dataKey="resumes"
                    type="monotone"
                    stroke="var(--color-resumes)"
                    strokeWidth={2}
                    dot={false}
                  />
                  <Line
                    dataKey="interviews"
                    type="monotone"
                    stroke="var(--color-interviews)"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ChartContainer>
            </ChartBox>
          ),
        },
        {
          label: "Area · 累积",
          children: (
            <ChartBox>
              <ChartContainer config={FUNNEL_CONFIG} className="!aspect-auto h-full w-full">
                <AreaChart data={MONTHLY}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area
                    dataKey="resumes"
                    type="monotone"
                    stroke="var(--color-resumes)"
                    fill="var(--color-resumes)"
                    fillOpacity={0.2}
                  />
                  <Area
                    dataKey="interviews"
                    type="monotone"
                    stroke="var(--color-interviews)"
                    fill="var(--color-interviews)"
                    fillOpacity={0.2}
                  />
                </AreaChart>
              </ChartContainer>
            </ChartBox>
          ),
        },
        {
          label: "Pie · 状态分布",
          children: (
            <ChartBox>
              <ChartContainer config={STATUS_CONFIG} className="!aspect-auto h-full w-full">
                <PieChart>
                  <ChartTooltip content={<ChartTooltipContent nameKey="label" hideLabel />} />
                  <Pie
                    data={STATUS}
                    dataKey="value"
                    nameKey="key"
                    innerRadius={48}
                    outerRadius={84}
                    paddingAngle={2}
                  />
                  <ChartLegend content={<ChartLegendContent nameKey="key" />} />
                </PieChart>
              </ChartContainer>
            </ChartBox>
          ),
        },
        {
          label: "Radial Bar · 进度",
          children: (
            <div className="h-[300px] w-full">
              <ChartContainer config={RADIAL_CONFIG} className="!aspect-auto h-full w-full">
                <RadialBarChart
                  data={RADIAL}
                  innerRadius={24}
                  outerRadius={90}
                  startAngle={90}
                  endAngle={-270}
                  margin={{ top: 0, right: 0, bottom: 32, left: 0 }}
                >
                  <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <RadialBar dataKey="value" background cornerRadius={6} />
                  <ChartLegend
                    content={<ChartLegendContent nameKey="name" />}
                    verticalAlign="bottom"
                    wrapperStyle={{ paddingTop: 16 }}
                  />
                </RadialBarChart>
              </ChartContainer>
            </div>
          ),
        },
      ]}
    />
  )
}

export { ChartShowcase }
