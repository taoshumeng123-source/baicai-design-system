import * as React from "react"
import { SearchInput } from "@/components/search-input"
import { showSuccessToast } from "@/components/sonner"
import { ComponentShowcase } from "../component-showcase"

function SearchInputShowcase() {
  return (
    <ComponentShowcase
      id="search-input"
      title="Search Input"
      source="src/components/search-input.tsx"
      description="带搜索图标 + 300ms debounce 的搜索输入框。"
      sections={[
        {
          label: "Interactive (输入触发 toast 演示 debounce)",
          children: (
            <SearchInput
              placeholder="搜索成员、邮箱、IP"
              className="w-[320px]"
              onSearch={(v) => { if (v) showSuccessToast(`搜索：${v}`) }}
            />
          ),
        },
      ]}
    />
  )
}

export { SearchInputShowcase }
