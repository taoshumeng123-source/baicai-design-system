# 百融 UI Design Specification

> B 端 SaaS 组件库与设计规范 · 独立可分享版（自包含、不依赖原项目内任何路径）

本文件是 3 个交付包之外的**第 4 件**，作用是让接手同事在 30 分钟内跑起来 + 按规范搭页面。

---

## 0. 交付物清单

| # | 名称 | 包内位置 | 角色 |
|---|------|---------|------|
| 1 | 基础规范 | `src/styles/globals.css` | 设计 token：颜色 / 间距 / 圆角 / 阴影 / 控件高度 / 字体 |
| 2 | 组件库 | `src/components/` (73 个 `.tsx`) | 可复用 React 组件 |
| 3 | 完整页面 Demo | `src/pages/` (9 个 `.tsx`) | 业务场景拼装示例 |
| 4 | **本文档** | `UI Design Specification.md` | 环境 / token 速查 / workflow / checklist |

**❗ 跑起来的第一条**：入口文件（通常是 `src/main.tsx` 或 `src/App.tsx`）必须 `import "./styles/globals.css"`。漏了它**全部 token 失效，所有页面看上去无样式**——这是 95% 新人会踩的坑。

---

## 1. 环境与依赖

### 1.1 依赖清单（package.json）

`dependencies`：

```json
{
  "@base-ui/react": "1.3.0",
  "@radix-ui/react-checkbox": "^1.3.3",
  "@radix-ui/react-dialog": "^1.1.15",
  "@radix-ui/react-dropdown-menu": "^2.1.16",
  "@radix-ui/react-label": "^2.1.8",
  "@radix-ui/react-popover": "^1.1.15",
  "@radix-ui/react-radio-group": "^1.3.8",
  "@radix-ui/react-scroll-area": "^1.2.10",
  "@radix-ui/react-select": "^2.2.6",
  "@radix-ui/react-separator": "^1.1.8",
  "@radix-ui/react-slot": "^1.2.4",
  "@radix-ui/react-switch": "^1.2.6",
  "@radix-ui/react-tabs": "^1.1.13",
  "@radix-ui/react-tooltip": "^1.2.8",
  "class-variance-authority": "^0.7.1",
  "clsx": "^2.1.1",
  "cmdk": "^1.1.1",
  "embla-carousel-react": "8.5.2",
  "input-otp": "^1.4.2",
  "lucide-react": "^1.7.0",
  "radix-ui": "^1.4.3",
  "react": "^19.2.4",
  "react-day-picker": "^9.7.0",
  "react-dom": "^19.2.4",
  "react-resizable-panels": "^4",
  "recharts": "3.8.0",
  "sonner": "^2.0.7",
  "tailwind-merge": "^3.5.0"
}
```

`devDependencies`：

```json
{
  "@tailwindcss/vite": "^4.2.2",
  "@types/react": "^19.2.14",
  "@types/react-dom": "^19.2.3",
  "@vitejs/plugin-react": "^4.7.0",
  "esbuild": "^0.28.0",
  "tailwindcss": "^4.2.2",
  "tw-animate-css": "^1.4.0",
  "typescript": "~6.0.2",
  "vite": "^6.4.1"
}
```

### 1.2 关键配置

#### `vite.config.mjs`

```js
import { fileURLToPath, URL } from "node:url"
import { defineConfig } from "vite"
import tailwindcss from "@tailwindcss/vite"
import react from "@vitejs/plugin-react"

export default defineConfig({
  base: "./",
  plugins: [tailwindcss(), react()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
})
```

#### `tsconfig.json` 关键段（`compilerOptions.paths`）

```json
"paths": {
  "@/*": ["./src/*"]
}
```

#### `components.json`（shadcn 风格 meta）

```json
{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "new-york",
  "rsc": false,
  "tsx": true,
  "tailwind": {
    "config": "tailwind.config.ts",
    "css": "src/styles/globals.css",
    "baseColor": "neutral",
    "cssVariables": true,
    "prefix": ""
  },
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components",
    "lib": "@/lib",
    "hooks": "@/hooks"
  },
  "iconLibrary": "lucide"
}
```

#### `tailwind.config.ts`

```ts
import type { Config } from "tailwindcss"

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
}

export default config
```

### 1.3 入口必须引入 globals.css

```tsx
// src/main.tsx
import "./styles/globals.css"   // ← 第一行 import，不能漏
import React from "react"
import ReactDOM from "react-dom/client"
import App from "./App"

ReactDOM.createRoot(document.getElementById("root")!).render(<App />)
```

---

## 2. Token 速查（最高频翻阅）

> 所有值直接抄自 `src/styles/globals.css`。Tailwind v4 通过 `@theme inline` 把每个 `--xxx` 自动暴露为对应的 utility（如 `--primary` → `bg-primary` / `text-primary`，`--corner-md` → `rounded-[var(--corner-md)]` 或 `rounded-md`）。

### 2.1 颜色 · Light Mode

**品牌色**
| Token | Hex | 用途 |
|---|---|---|
| `--primary` | `#423eec` | 主品牌色（蓝紫） |
| `--primary-hover` | `#717ffc` | hover |
| `--primary-active` | `#3833ca` | active |
| `--primary-foreground` | `#ffffff` | 品牌底上的文字 |
| `--primary-soft` | `#ecf0fe` | 品牌浅底（Badge / hover bg） |
| `--primary-soft-hover` | `#dce4fd` | soft 底 hover |
| `--primary-border` | `#c0cdfc` | 品牌色边框 |
| `--primary-border-hover` | `#9aacfd` | 边框 hover |
| `--primary-emphasis` | `#2e2c9c` | 品牌深色文字 |

**语义色 · Destructive（红）**
| Token | Hex |
|---|---|
| `--destructive` | `#ee3e34` |
| `--destructive-hover` | `#d82518` |
| `--destructive-active` | `#b01f14` |
| `--destructive-foreground` | `#ffffff` |
| `--destructive-soft` | `#fdf1f0` |
| `--destructive-soft-hover` | `#fcdfde` |
| `--destructive-border` | `#fbc5c3` |

**语义色 · Success（绿）**
| Token | Hex |
|---|---|
| `--success` | `#29bb54` |
| `--success-hover` | `#87e7a8` |
| `--success-active` | `#1f9742` |
| `--success-foreground` | `#ffffff` |
| `--success-soft` | `#effcf3` |
| `--success-soft-hover` | `#dafae5` |
| `--success-border` | `#b2e7c4` |

**语义色 · Warning（黄）**
| Token | Hex |
|---|---|
| `--warning` | `#e8a900` |
| `--warning-hover` | `#fdda43` |
| `--warning-active` | `#c47e00` |
| `--warning-foreground` | `#171717` |
| `--warning-soft` | `#fefbe7` |
| `--warning-soft-hover` | `#fef7bf` |
| `--warning-border` | `#fdec87` |

**语义色 · Info（蓝）**
| Token | Hex |
|---|---|
| `--info` | `#1c58f2` |
| `--info-hover` | `#5099fe` |
| `--info-active` | `#1745da` |
| `--info-foreground` | `#ffffff` |
| `--info-soft` | `#edf4fe` |
| `--info-soft-hover` | `#d7e7fc` |
| `--info-border` | `#b9d6fc` |

**中性 / 表面**
| Token | Hex | 用途 |
|---|---|---|
| `--background` | `#f9f9f9` | 页面外层底色 |
| `--foreground` | `#171717` | 默认文字 |
| `--card` | `#ffffff` | 卡片/弹层底 |
| `--card-foreground` | `#171717` | 卡片内文字 |
| `--secondary` | `#f3f3f3` | 弱次级底（hover、ghost） |
| `--secondary-foreground` | `#171717` | 次级文字 |
| `--muted` | `#f3f3f3` | 弱化区底 |
| `--muted-foreground` | `#686868` | 弱化文字（description、metadata） |
| `--accent` | `#f3f3f3` | 强调底 |
| `--accent-foreground` | `#171717` | 强调底上的文字 |
| `--surface-disabled` | `#f3f3f3` | 禁用控件底 |
| `--border` | `#ebebeb` | 默认分割线（已调浅） |
| `--border-strong` | `#686868` | 强边框 |
| `--input` | `#e1e1e1` | 输入框边框 |
| `--ring` | `#9aacfd` | focus ring |

**Sidebar 专用**
| Token | Hex | 用途 |
|---|---|---|
| `--sidebar` | `#f5f7ff` | WideNav 主底 |
| `--sidebar-soft` | `#f8faff` | WideNav 浅底（实际使用） |
| `--sidebar-foreground` | `#171717` | 侧栏文字 |
| `--sidebar-accent` | `#dce4fd` | active 项底 |
| `--sidebar-accent-foreground` | `#423eec` | active 项文字 |
| `--sidebar-border` | `#d8ddea` | 侧栏边 |
| `--sidebar-ring` | `#9aacfd` | focus |
| `--sidebar-brand-bg` | `#dce4fd` | 品牌入口底 |
| `--sidebar-brand-bg-hover` | `#dce4fd` | 品牌入口 hover |
| `--sidebar-active-text` | `#423eec` | 品牌入口文字 |

**图表色**
| Token | Hex |
|---|---|
| `--chart-1` | `#423eec` |
| `--chart-2` | `#1c58f2` |
| `--chart-3` | `#29bb54` |
| `--chart-4` | `#e8a900` |
| `--chart-5` | `#ee3e34` |

### 2.2 颜色 · Dark Mode

在根节点 `<html className="dark">` 或 `<body className="dark">` 触发。值列出关键差异（与 light 同名 token 自动切换）：

| Token | Light | Dark |
|---|---|---|
| `--background` | `#f9f9f9` | `#11131a` |
| `--foreground` | `#171717` | `#f3f3f3` |
| `--card` | `#ffffff` | `#171921` |
| `--primary` | `#423eec` | `#717ffc` |
| `--primary-soft` | `#ecf0fe` | `#1f245b` |
| `--primary-emphasis` | `#2e2c9c` | `#c0cdfc` |
| `--border` | `#ebebeb` | `#303544` |
| `--muted-foreground` | `#686868` | `#cecece` |
| `--sidebar` | `#f5f7ff` | `#171921` |
| `--sidebar-accent` | `#dce4fd` | `#1f245b` |

Dark mode 所有 `--destructive` / `--success` / `--warning` / `--info` 主色保持一致（`#ee3e34` / `#29bb54` / `#e8a900` / `#5099fe`），但 `*-soft` 改用深色暗底（如 `--success-soft: #152d1d`）。

### 2.3 间距 `--space-*`

| Token | Px | 常用场景 |
|---|---|---|
| `--space-0` | 0 | — |
| `--space-0_5` | 2 | 极细 gap、checkbox 偏移 |
| `--space-1` | 4 | 文字与图标小 gap |
| `--space-1_5` | 6 | inline 元素 gap |
| `--space-2` | 8 | Avatar+text gap、按钮内 padding |
| `--space-3` | 12 | 工具栏元素 gap、卡片内紧凑 padding |
| `--space-4` | 16 | 表格列 padding、PageTitleHeader gap |
| `--space-5` | 20 | 卡片间距 |
| `--space-6` | 24 | sidebar header padding |
| `--space-7` | 28 | **页面横向 padding（TopPageBar + 内容区对齐）** |
| `--space-8` | 32 | 大区块 margin |
| `--space-10` | 40 | — |
| `--space-12` | 48 | — |

### 2.4 圆角 `--corner-*`

| Token | Px | 场景 |
|---|---|---|
| `--corner-xs` | 4 | Checkbox、Badge 内圆角、小 hover bg |
| `--corner-sm` | 6 | Button sm、Input 内层 |
| `--corner-md` | 8 | Button 默认、Card 内部 |
| `--corner-lg` | 10 | Card 默认、AppCard、ModuleCard |
| `--corner-xl` | 12 | Button lg、大卡片 |

Tailwind v4 把这些自动暴露为 `--radius-xs` / `--radius-sm` / `--radius-md` / `--radius-lg` / `--radius-xl`，所以可以直接写 `rounded-xs` / `rounded-sm` / `rounded-md` / `rounded-lg` / `rounded-xl`，也可以显式 `rounded-[var(--corner-md)]`。

`--radius` 别名为 `var(--corner-md)`（8px）作为兜底默认。

### 2.5 控件高度 `--control-height-*`

| Token | Px | 场景 |
|---|---|---|
| `--control-height-2xs` | 28 | Button icon-xs、Tag close 按钮 |
| `--control-height-xs` | 32 | **Button sm、Input、SearchInput、SelectTrigger、TableSelectionBar** |
| `--control-height-md` | 40 | Button default |
| `--control-height-lg` | 48 | TopPageBar、Button lg |

### 2.6 阴影 `--shadow-*`

| Token | 值 | 用途 |
|---|---|---|
| `--shadow-floating` | `0 4px 12px rgb(12 18 36 / 0.08), 0 2px 4px rgb(12 18 36 / 0.04)` | 轻量下拉浮层 · DropdownMenu / Select / Combobox / Popover / HoverCard / ContextMenu / Menubar |
| `--shadow-overlay` | `0 28px 72px rgb(12 18 36 / 0.2), 0 10px 24px rgb(12 18 36 / 0.14)` | 重浮层 · Dialog / Sheet / CommandDialog |
| `--shadow-card-hover` | `0 6px 14px rgb(23 23 23 / 0.06), 0 1px 3px rgb(23 23 23 / 0.04)` | 卡片 hover 抬升（AppCard active） |
| `--shadow-control` | `0 1px 2px rgb(23 23 23 / 0.04)` | segmented control 选中态 |
| `--shadow-button` | `0 10px 24px rgb(66 62 236 / 0.2), 0 4px 8px rgb(66 62 236 / 0.12)` | 主 CTA 按钮（不常用） |
| `--shadow-surface` | `0 12px 28px rgb(23 23 23 / 0.06), 0 2px 6px rgb(23 23 23 / 0.04)` | 面板默认阴影 |
| `--shadow-sidebar` | `14px 0 34px rgb(56 51 202 / 0.06), inset -1px 0 0 rgb(216 221 234 / 0.72)` | WideNav 阴影 |
| `--shadow-thumb` | `0 1px 3px rgb(23 23 23 / 0.16)` | Switch thumb、Slider thumb |

### 2.7 字体

```css
--font-sans:
  "PingFang SC", "SF Pro Text", "Helvetica Neue", "Hiragino Sans GB",
  "Microsoft YaHei", sans-serif;
--font-mono:
  "SFMono-Regular", "JetBrains Mono", "SF Pro Display", "Consolas", monospace;
```

Tailwind utility：`font-sans` / `font-mono`。

---

## 3. Typography 规范

11 个语义化组件（导出位于 `src/components/typography.tsx`）。所有尺寸 + 行高 + 字重 + 默认色都烤进 className；**不带 margin**（交给容器 `gap-*`）。

| 导出 | HTML | size/leading | weight | 默认色 | 场景 |
|---|---|---|---|---|---|
| `TypographyH1` | `<h1>` | 20/32 | bold | foreground | 页面标题（PageTitleHeader 内部） |
| `TypographyH2` | `<h2>` | 15/24 | semibold | foreground | 弹窗/区块标题 |
| `TypographyH3` | `<h3>` | 14/22 | semibold | foreground | 子区块（如 Roles 权限模块） |
| `TypographyH4` | `<h4>` | 13/20 | semibold | foreground | 卡片子项 |
| `TypographyP` | `<p>` | 12/20 | normal | foreground | **正文默认**（B 端最常见） |
| `TypographyLarge` | `<p>` | 13/20 | normal | foreground | 次级描述、列表项 |
| `TypographyLabel` | `<span>` | 12/20 | medium | foreground | 表单 label |
| `TypographySmall` | `<small>` | 11/16 | normal | muted-foreground | 元数据 / 表头 caption / 脚注 |
| `TypographyMuted` | `<p>` | 12/20 | normal | muted-foreground | 段落级 muted 提示 |
| `TypographyDisplay` | `<div>` | 28/36 | bold | foreground | KPI 大数字（Dashboard） |
| `TypographyInlineCode` | `<code>` | 12 mono | normal | foreground + bg-muted + 4px corner | 行内代码 |

---

## 4. 组件库清单（73 个）

按功能分组（文件名小写带连字符，导出名 PascalCase）：

**基础原语**
- `button.tsx` · Button（default / destructive / outline / secondary / ghost / link × sm / default / lg / icon-xs/sm/md）
- `input.tsx` · Input
- `textarea.tsx` · Textarea
- `checkbox.tsx` · Checkbox（4px corner，sm 尺寸常用）
- `switch.tsx` · Switch（thumb translate-x 已校准为 18px）
- `toggle.tsx` · Toggle
- `toggle-group.tsx` · ToggleGroup
- `toggle-chip.tsx` · ToggleChip（flat 无外框）
- `radio-pill.tsx` · RadioPill（ring 样式）
- `slider.tsx` · Slider
- `label.tsx` · Label
- `badge.tsx` · Badge（default/secondary/outline/success/warning/info/destructive）
- `kbd.tsx` · Kbd
- `separator.tsx` · Separator
- `skeleton.tsx` · Skeleton
- `spinner.tsx` · Spinner
- `progress.tsx` · Progress
- `aspect-ratio.tsx` · AspectRatio
- `avatar.tsx` · Avatar + AvatarFallback（含 muted badge variant）

**容器**
- `card.tsx` · Card / CardHeader / CardTitle / CardDescription / CardContent / CardFooter / **StatCard**（紧凑统计卡）
- `app-card.tsx` · AppCard（status: `active` 已上线 info / `enabled` 已开通 success / `coming_soon` 灰）
- `settings-card.tsx` · SettingsCard + FieldRow（默认 layout="split" 两端对齐）
- `dialog.tsx` · Dialog
- `alert-dialog.tsx` · AlertDialog
- `confirm-dialog.tsx` · ConfirmDialog
- `sheet.tsx` · Sheet（侧滑面板，side: top/bottom/left/right，默认 right）

**数据展示**
- `table.tsx` · Table / TableHeader / TableBody / TableFooter / TableHead / TableRow / TableCell / TableCaption / **TableSelectionBar**（顶部覆盖式批量操作条）
- `data-table.tsx` · DataTable（带搜索分页的高级表格）
- `table-skeleton.tsx` · TableSkeleton
- `chart.tsx` · Chart 系列（基于 recharts）
- `kpi-card.tsx` · KpiCard（Dashboard KPI 玻璃卡 + 迷你柱图 + hover 数据对比气泡）
- `trend-combo-chart.tsx` · TrendComboChart（分组柱 + 折线 + 双 Y 轴，prop 驱动）
- `funnel-bars.tsx` · FunnelBars（倒三角圆角条漏斗 + 转化率 + hover 气泡）
- `channel-donut.tsx` · ChannelDonut（环形图 + 中心总计 + 图例列表）
- `chart-hover-bubble.tsx` · ChartHoverBubble（图表 hover 气泡，funnel / donut 共用）
- `empty.tsx` · Empty
- `empty-state.tsx` · EmptyState（含 4 种插画：no-data/no-result/no-permission/network-error）
- `pagination.tsx` · Pagination
- `accordion.tsx` · Accordion（hover bg 已收紧）
- `collapsible.tsx` · Collapsible

**导航**
- `narrow-rail.tsx` · NarrowRail（56px 一级侧栏）+ AppTile + AdminTile
- `wide-nav.tsx` · WideNav（240px 二级侧栏）+ WideNavHeader + NavGroup + NavItem
- `sub-nav.tsx` · SubNav / SubNavGroup / SubNavItem（页内三级导航，带 header 槽）
- `top-page-bar.tsx` · TopPageBar（面包屑模式，sticky inside scroll）+ PageTitleHeader
- `breadcrumb.tsx` · Breadcrumb
- `tabs.tsx` · Tabs / TabsList / TabsTrigger / TabsContent
- `button-group.tsx` · ButtonGroup（连体边框 segmented）+ ButtonGroupSeparator + ButtonGroupText
- `menubar.tsx` · Menubar
- `pagination.tsx`（同上）

**反馈**
- `alert.tsx` · Alert / AlertTitle / AlertDescription / **AlertClose**
- `tooltip.tsx` · Tooltip / TooltipTrigger / TooltipContent / TooltipProvider
- `sonner.tsx` · Toaster + showSuccessToast / showErrorToast / showInfoToast
- `dropdown-menu.tsx` · DropdownMenu
- `context-menu.tsx` · ContextMenu
- `popover.tsx` · Popover
- `hover-card.tsx` · HoverCard

**表单**
- `field.tsx` · Field / FieldGroup
- `input-group.tsx` · InputGroup
- `input-otp.tsx` · InputOTP（独立长方形 6 位）
- `number-input.tsx` · NumberInput（w-fit + 单位后缀）
- `search-input.tsx` · SearchInput（带 debounce）
- `select.tsx` · Select
- `native-select.tsx` · NativeSelect
- `combobox.tsx` · Combobox（基于 base-ui）
- `command.tsx` · Command / CommandDialog
- `calendar.tsx` · Calendar（react-day-picker，Select 替代原生 dropdown）
- `date-picker.tsx` · DatePicker / DateRangePicker
- `tag-input.tsx` · TagInput（关闭 icon 方形 hover）

**其他**
- `item.tsx` · Item / ItemTitle / ItemDescription（12px description）
- `direction.tsx` · DirectionProvider
- `resizable.tsx` · ResizablePanelGroup
- `scroll-area.tsx` · ScrollArea
- `carousel.tsx` · Carousel
- `typography.tsx` · 见 Section 3

---

## 5. 页面构建 8 步 Workflow

### Step 1 · 确认 App Shell 结构

```tsx
<div className="flex h-screen overflow-hidden overscroll-none bg-background">
  <NarrowRail logo={...} topItems={...} bottomItems={...} />   {/* 56px */}
  <WideNav header={<WideNavHeader title="..." />}>             {/* 240px */}
    <NavGroup label="...">
      <NavItem icon={...} active>子路由</NavItem>
    </NavGroup>
  </WideNav>
  <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
    <div ref={scrollRef} className="flex-1 overflow-y-auto overscroll-none bg-card">
      <TopPageBar breadcrumb={[...]} elevated={barElevated} />  {/* 48px，sticky inside scroll */}
      <div className="mx-auto max-w-[1280px] px-[var(--space-7)] py-[var(--space-5)]">
        <PageTitleHeader title="页面标题" actions={...} />
        {/* 页面内容 */}
      </div>
    </div>
  </div>
</div>
```

### Step 2 · 选页面模式

| 页面类型 | 主要组合 |
|---|---|
| 列表页 | SearchInput + Select 工具栏 → `<Table>` + `<TableSelectionBar>` + Pagination |
| 设置页 | SettingsCard + FieldRow（layout="split"）堆叠，PageTitleHeader 带 unsaved/save/discard |
| Dashboard | StatCard × N + Card + Chart |
| 表单页 | Field / FieldGroup + Input/Select/Combobox 控件 |
| Master-Detail | 左侧列表 + 右侧详情（Members / Roles 风格） |

### Step 3 · 先查现有组件再新增

```bash
rg --files src/components       # 列出所有组件
rg -n "^export" src/components/xxx.tsx   # 确认 API
```

**禁止**杜撰组件名、prop、variant、size；源码没有就说"仓库内未找到"。

### Step 4 · Token 使用（禁止硬编码）

- 颜色 → 语义 token：`bg-primary` / `text-muted-foreground` / `border-border`
- 横向 padding → `px-[var(--space-7)]` (28px)
- 控件高度 → `h-[var(--control-height-xs)]` (32px) / `--control-height-md` (40px)
- 圆角 → `rounded-[var(--corner-sm)]` / `--corner-md` / `--corner-lg`
- 阴影 → `shadow-[var(--shadow-floating)]` / `--shadow-overlay` / `--shadow-card-hover`
- **禁止**直接写 `#423eec` / `#686868` / `rounded-[8px]` / `shadow-[0_4px_12px_...]`

### Step 5 · 空 / 加载 / 错误状态

- 空数据 → `<EmptyState variant="no-data" />`
- 无搜索结果 → `<EmptyState variant="no-result" />`
- 无权限 → `<EmptyState variant="no-permission" />`
- 网络错误 → `<EmptyState variant="network-error" />`
- 加载中 → `<Skeleton>` / `<TableSkeleton rows={...} columns={...} />` / `<Spinner />`

### Step 6 · 交互规范

- 防 overscroll：`html, body { overscroll-behavior: none }` + 容器加 `overscroll-none`
- 滚动抬升：`scrollRef + 监听 scroll` → `setBarElevated(el.scrollTop > 0)` → `<TopPageBar elevated={barElevated} />`
- TopPageBar 必须放在 scrollRef 容器**内部**（sticky top-0 z-20 + backdrop-blur 80% 才会触发高斯模糊）
- 内容区 padding 与 TopPageBar 对齐：均用 `px-[var(--space-7)]`
- 设置页：维护 `isDirty` state → 传给 PageTitleHeader 的 `unsaved` + `onSave` + `onDiscard`
- icon-only 按钮必须包 `<Tooltip>` + `aria-label`（**禁止** HTML 原生 `title=`）
- 页面根包一次 `<TooltipProvider delayDuration={300}>`

### Step 7 · Review 自查（详见 Section 6）

### Step 8 · 验证

```bash
pnpm typecheck    # TypeScript 必须通过
pnpm build        # 涉及样式/组件改动时必须通过
```

---

## 6. Review Checklist

### 通用 UI Review

- [ ] 已读 `globals.css` 和用到的组件源码
- [ ] 没有杜撰组件 / variant / size / prop
- [ ] 没有绕过组件直接写 HTML（badge / chip / button / 头像 / 标签）
- [ ] 没有硬编码颜色 / 圆角 / 阴影 / 控件高度
- [ ] light / dark token 语义没破坏
- [ ] 已覆盖 loading / empty / error / disabled / focus-visible / keyboard 状态
- [ ] 窄屏下文本不溢出、按钮不挤压、表格可滚动

### 本规范沉淀的特殊条目

- [ ] **入口** import 了 `./styles/globals.css`
- [ ] 没有 `rounded-[Npx]`（用 `rounded-[var(--corner-*)]`）
- [ ] 没有 hex 颜色字面量（`#fff` / `#000`）
- [ ] 没有 native HTML `title=` 属性（用 `<Tooltip>`）
- [ ] 没有 native `<select>`（用 `<Select>` 或 `<NativeSelect>`）
- [ ] TopPageBar 放在 scrollRef 容器**内部**，启用 sticky+blur
- [ ] icon 全部来自 `lucide-react`（NavItem icon `size-[14px]`、功能区 icon `size-[18px]`）
- [ ] 横向 padding 用 `px-[var(--space-7)]`
- [ ] `pnpm typecheck` + `pnpm build` 通过

---

## 7. 公共资源（必须随包发送）

包根目录的 `public/` 文件夹必须随交付包一起发送，否则页面会 404：

| 路径 | 用途 |
|---|---|
| `public/logo-icon.svg` | 百融百才 logo，NarrowRail 顶部 |
| `public/logo-full.svg` | 完整 logo（登录页、品牌入口） |
| `public/empty-state/no-data.png` | EmptyState 无数据插画 |
| `public/empty-state/no-result.png` | 无搜索结果插画 |
| `public/empty-state/no-permission.png` | 无权限插画 |
| `public/empty-state/network-error.png` | 网络错误插画 |
| `public/empty-state/no-content.png` | 无内容插画 |

**如何打包**：在分享代码时务必把整个 `public/` 文件夹一并打包（zip / tar）。`pnpm build` 出的 `dist/` 已自动包含这些资源。

---

## 8. CHANGELOG · 近期重要变更

> 收到代码后对照旧版本时使用：

- **Typography 全套重写**为 B 端 11–20px 尺度（H1 20px / P 12px / Small 11px / Display 28px）；删除 Lead/Blockquote/List 等 marketing 风格组件；新增 Label / Display。
- **TableSelectionBar 新增**（`src/components/table.tsx`）：顶部覆盖式批量操作条，选中行 > 0 时替换原过滤工具栏。高度 32px，bg-background，文字 24px gap，所有 actions 推荐 `ghost size="sm"` + `hover:bg-transparent hover:text-{primary|destructive}`。
- **StatCard 新增**（`src/components/card.tsx`）：紧凑统计卡（label 12px muted + value 16px semibold，px-3 py-2 + corner-lg）。
- **AppCard 三态**：`active`（已上线 · Info 蓝）/ `enabled`（已开通 · Success 绿）/ `coming_soon`（即将上线 · 灰）。
- **TopPageBar** 改造为 `sticky top-0 z-20` 内嵌 scroll 容器；`bg-card/80 + backdrop-blur-md` 启用 macOS 风格高斯模糊；阴影已移除（仅保留恒定 border-b 分割线）。
- **Accordion** hover bg 收紧（去 `-mx-3`，padding `px-3 py-4` → `px-2 py-3`）；展开 content 加 `px-2` 与 trigger 对齐。
- **ButtonGroup** 改连体边框（共享 border + 圆角矩形）；选中态 `bg-primary-soft + text-primary + border-primary/40`；与 Tabs 视觉分离。
- **Tabs** 保留 segmented 胶囊外壳风格，与 ButtonGroup 区分。
- **Switch thumb** 偏移修正为 `translate-x-[18px]`（左右对称 2px gap）。
- **Checkbox** 统一 `rounded-[var(--corner-xs)]` (4px)。
- **下拉阴影统一**：DropdownMenu / Select / Combobox / Popover / HoverCard / ContextMenu / Menubar 全部对齐 `--shadow-floating`（已调轻为 `0 4px 12px rgb(12 18 36 / 0.08), 0 2px 4px rgb(12 18 36 / 0.04)`）。Dialog / Sheet 保留重 `--shadow-overlay`。
- **Tag Input** 关闭 icon hover bg 改为 `rounded-[var(--corner-xs)]` 方形。
- **Alert** padding 8px 全包；新增 AlertClose 24×24 + 4px corner；单行模式 icon 自动垂直居中。
- **Catalog 适配 breakpoint**：从 `2xl` (1536px) 下移到 `md` (768px+) — 目录导航 300px sticky 始终可见，showcase 区随 viewport 收窄。
- **AppCard showcase** 内部网格 `grid-cols-1 sm:grid-cols-2 xl:grid-cols-4`。
- **Roles 页面**：「新建角色」按钮从 PageTitleHeader 移至左侧「自定义角色」分组旁的 ghost icon-xs + Tooltip；外层包 TooltipProvider。
- **零硬编码 token**：GeneralSettings 色块改 `--corner-md`，Roles ModuleCard/empty icon 改 `--corner-lg`，case 页所有 `rounded-[Npx]` / `text-white` 已清零。
- **OperationsLog / LoginLog 风险横幅**：手撸结构改为纯 `<Alert><AlertCircle/><AlertDescription/><AlertClose/></Alert>`。
- **SessionManagementPage**：4 张 StatCard 顶部统计；顶部工具栏 TableSelectionBar 覆盖；批量退出登录 ghost + hover destructive。

---

## 9. 在线规范站

包内自带 catalog（基于 `src/showcase/` + `src/App.tsx`），运行：

```bash
pnpm install
pnpm dev
# 浏览器打开 http://localhost:5174/
```

效果：
- **基础规范** Tab：颜色 / 字体 / 间距 / 圆角 / 阴影 token 交互预览
- **组件库** Tab：70+ 组件交互 demo，每个组件有源码路径 + variant / size 全展示
- 9 个业务页通过 `#app-center` / `#login-setting` / `#members` 等 hash 路由直接访问

打包静态站：

```bash
pnpm build       # 出 dist/
# dist/ 可以上传任意静态 hosting（Vercel / Netlify / Nginx / OSS）
```

`dist/` 内部已是相对路径（`vite.config.mjs` 的 `base: "./"`），可以直接 zip 离线分享。

---

## 10. 容易踩坑 · 风险点清单

按"踩到的概率"排序：

1. ❗❗❗ **漏 `import "./styles/globals.css"`** — 全局无样式 / token 全部失效。新人 90% 第一时间不会查到这里。
2. ❗❗❗ **Tailwind v4 没装 `@tailwindcss/vite` 或 Vite 没 plug** — arbitrary value 类（`text-[12px]` / `bg-[var(--primary)]` / `h-[var(--control-height-xs)]`）不生成对应 CSS。表现：部分样式生效、部分不生效，看起来"组件坏了"。
3. ❗❗ **tsconfig `paths` 没配 `@/*`** — `@/components/...` import 全部 TS 报错；运行时 vite 的 alias 还能跑，但 IDE 全红。
4. ❗❗ **public 文件夹没拷贝** — NarrowRail logo 404 → 头像空白；EmptyState 插画 404 → 空白图标。
5. ❗ **Radix UI 依赖漏装** — `@radix-ui/react-dialog` / `@radix-ui/react-select` / `@radix-ui/react-checkbox` 等单独包必须安装，**`radix-ui` 元包不够**（项目里两套都依赖）。
6. ❗ **`base-ui/react` 漏装** — Combobox 跑不起来。
7. ❗ **lucide-react 漏装** — 全站 icon 报错。
8. ❗ **`recharts` / `react-day-picker` / `embla-carousel-react` / `cmdk` / `sonner` / `input-otp`** — 各自对应 Chart / Calendar / Carousel / Command / Toast / InputOTP 组件，缺一个对应组件就崩。
9. ❗ **page-level 漏 `<TooltipProvider>`** — Members / Roles 等用 Tooltip 的页面，少这层 Provider 就拿不到 delayDuration 配置（不会崩，但 hover 立即弹）。
10. ❗ **入口 HTML `<html className="dark">` 切换** — dark mode 需要手动加 class，没有自动从系统主题切换的逻辑（项目当前没集成 `next-themes` 之类）。

---

**End of UI Design Specification**

收到代码后建议依序：装依赖 → 跑 `pnpm dev` → 打开 catalog 浏览所有组件 → 翻 Section 5 workflow 起一个新页面。如有疑问回到 Section 2 / 4 查 token 和组件 API。
