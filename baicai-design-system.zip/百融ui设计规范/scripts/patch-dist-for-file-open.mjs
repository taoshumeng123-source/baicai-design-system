import fs from "node:fs"
import { createRequire } from "node:module"
import path from "node:path"
import { build } from "esbuild"

const require = createRequire(import.meta.url)
const distIndexPath = path.resolve("dist/index.html")
const distAssetsDir = path.resolve("dist/assets")
const standaloneOutfile = path.resolve("dist/assets/index-standalone.js")
const ssrOutfile = path.resolve("dist/.ssr-render.cjs")

if (!fs.existsSync(distIndexPath)) {
  console.error(`dist index not found: ${distIndexPath}`)
  process.exit(1)
}

await build({
  stdin: {
    contents: `
      import React from "react";
      import ReactDOM from "react-dom/client";
      import App from "./src/App";

      function renderFatalError(error) {
        const root = document.getElementById("root");
        if (!root) return;
        const message =
          error instanceof Error
            ? \`\${error.name}: \${error.message}\\n\\n\${error.stack ?? ""}\`
            : String(error);

        root.innerHTML = \`
          <div style="padding:24px;font-family:var(--font-sans-base, 'PingFang SC', sans-serif);color:#171717;">
            <div style="max-width:960px;margin:0 auto;border:1px solid #e1e1e1;border-radius:16px;background:#fff;padding:20px 24px;white-space:pre-wrap;line-height:1.6;">
              <strong style="display:block;margin-bottom:12px;">Runtime error</strong>
              \${message.replace(/[&<>]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[char] ?? char))}
            </div>
          </div>
        \`;
      }

      class RootErrorBoundary extends React.Component {
        constructor(props) {
          super(props);
          this.state = { error: null };
        }
        static getDerivedStateFromError(error) {
          return { error };
        }
        componentDidCatch(error) {
          console.error(error);
        }
        render() {
          if (this.state.error) {
            return React.createElement(
              "div",
              { style: { padding: 24 } },
              React.createElement(
                "div",
                {
                  style: {
                    maxWidth: 960,
                    margin: "0 auto",
                    border: "1px solid #e1e1e1",
                    borderRadius: 16,
                    background: "#fff",
                    padding: "20px 24px",
                    whiteSpace: "pre-wrap",
                    lineHeight: 1.6,
                    color: "#171717",
                  },
                },
                React.createElement(
                  "strong",
                  { style: { display: "block", marginBottom: 12 } },
                  "React render error"
                ),
                \`\${this.state.error.name}: \${this.state.error.message}\\n\\n\${this.state.error.stack ?? ""}\`
              )
            );
          }
          return this.props.children;
        }
      }

      window.addEventListener("error", (event) => {
        renderFatalError(event.error ?? event.message);
      });

      window.addEventListener("unhandledrejection", (event) => {
        renderFatalError(event.reason);
      });

      try {
        const root = document.getElementById("root");
        if (!root) {
          throw new Error("Root element #root not found");
        }
        const app = React.createElement(
          React.StrictMode,
          null,
          React.createElement(
            RootErrorBoundary,
            null,
            React.createElement(App, null)
          )
        );

        root.textContent = "";
        ReactDOM.createRoot(root).render(app);
      } catch (error) {
        renderFatalError(error);
      }
    `,
    resolveDir: process.cwd(),
    sourcefile: "standalone-entry.tsx",
    loader: "tsx",
  },
  bundle: true,
  format: "iife",
  platform: "browser",
  target: ["es2020"],
  outfile: standaloneOutfile,
  jsx: "automatic",
  minify: true,
  alias: {
    "@": path.resolve("src"),
  },
  define: {
    "import.meta.env.BASE_URL": '"./"',
  },
})

const ssrBundle = await build({
  stdin: {
    contents: `
      import React from "react";
      import { renderToString } from "react-dom/server";
      import App from "./src/App";

      const html = renderToString(React.createElement(App));
      export default html;
    `,
    resolveDir: process.cwd(),
    sourcefile: "standalone-ssr.tsx",
    loader: "tsx",
  },
  bundle: true,
  platform: "node",
  format: "cjs",
  write: true,
  outfile: ssrOutfile,
  jsx: "automatic",
  alias: {
    "@": path.resolve("src"),
  },
  define: {
    "import.meta.env.BASE_URL": '"./"',
  },
  loader: {
    ".css": "empty",
  },
})

if (ssrBundle.errors.length > 0) {
  console.error("failed to generate SSR bundle")
  process.exit(1)
}

const ssrModule = require(ssrOutfile)
const renderedAppHtml = ssrModule.default ?? ssrModule

const source = fs.readFileSync(distIndexPath, "utf8")
const standaloneScript = fs.readFileSync(standaloneOutfile, "utf8")
const inlineStandaloneScript = standaloneScript.replaceAll("</script>", "<\\/script>")
const cssMatch = source.match(/<link\s+rel="stylesheet"(?:\s+crossorigin)?\s+href="([^"]+)">/)
const cssHref = cssMatch?.[1]
const cssPath = cssHref ? path.resolve("dist", cssHref.replace(/^\.\//, "")) : null
const bundledCss = cssPath && fs.existsSync(cssPath) ? fs.readFileSync(cssPath, "utf8") : ""

const patched = source
  .replace(
    /<script\s+type="module"\s+crossorigin\s+src="([^"]+)"><\/script>/,
    () => ""
  )
  .replace(
    /<link\s+rel="stylesheet"\s+crossorigin\s+href="([^"]+)">/,
    () => (bundledCss ? `<style>\n${bundledCss}\n</style>` : "")
  )
  .replace(
    /<div id="root"><\/div>/,
    () => `<div id="root">${renderedAppHtml}</div>`
  )
  .replace(
    /\s*<\/body>/,
    () => `\n    <script>\n${inlineStandaloneScript}\n    </script>\n  </body>`
  )

if (patched === source) {
  console.warn("dist/index.html patch made no changes")
} else {
  fs.writeFileSync(distIndexPath, patched)
  console.log("patched dist/index.html for direct file opening")
}

if (fs.existsSync(distAssetsDir)) {
  for (const assetName of fs.readdirSync(distAssetsDir)) {
    const assetRef = `assets/${assetName}`
    const relativeAssetRef = `./${assetRef}`

    if (!patched.includes(assetRef) && !patched.includes(relativeAssetRef)) {
      fs.unlinkSync(path.join(distAssetsDir, assetName))
    }
  }

  if (fs.readdirSync(distAssetsDir).length === 0) {
    fs.rmdirSync(distAssetsDir)
  }
}

if (fs.existsSync(ssrOutfile)) {
  fs.unlinkSync(ssrOutfile)
}
