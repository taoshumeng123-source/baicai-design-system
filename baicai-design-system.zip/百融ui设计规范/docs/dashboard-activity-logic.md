# 数据看板 ·「最近动态」活动流业务逻辑

> 招聘看板 `#dashboard` 的「最近动态」每条记录前的**图标 + 配色**规范,以及它如何映射到招聘业务阶段。
> 代码位置:`src/pages/DashboardPage.tsx` 的 `ACTIVITY_GROUP` / `GROUP_STYLE`。

## 设计原则

- **颜色编码"业务阶段 / 进度"**,不编码单个动作 —— 颜色由浅入深表达推进:**灰(早期·中性)→ 蓝(进行中)→ 绿(产出·成功)**。
- **图标编码"阶段组"** —— 同一阶段组共用同一图标,具体做了什么由右侧**文案**(action)区分。
- 这样无论后续动作种类增多,前缀图标始终只有 3 类颜色,**列表不会因颜色过多而杂乱**。
- 全部走设计 token(`bg-secondary` / `bg-info-soft` / `bg-success-soft` 等),不硬编码颜色。
- 容器:圆角方块 tile(`rounded-[var(--corner-md)]`,28px),soft 色底 + 同色系图标。

## 阶段组 → 图标 + 配色

| 阶段组 | 含动作(type) | 业务语义 | 图标(lucide) | 配色(底 + 图标) |
|---|---|---|---|---|
| **简历** `resume` | 投递 `applied`、初筛 `screen` | 漏斗早期、候选人进入 | `FileText` | 灰 · `bg-secondary` + `text-muted-foreground` |
| **面试** `interview` | 安排面试 `interview`、面试评价 `evaluate`、推进 `advance` | 流程进行中 | `ClipboardCheck` | 蓝 · `bg-info-soft` + `text-info` |
| **结果** `result` | 发起 Offer `offer`、入职 `onboard` | 产出 / 成功 | `CircleCheck` | 绿 · `bg-success-soft` + `text-success` |

## type → 阶段组映射

| type | 阶段组 | 典型文案 |
|---|---|---|
| `applied` | resume | 收到新简历 |
| `screen` | resume | 简历初筛 |
| `interview` | interview | 安排了面试 |
| `evaluate` | interview | 完成了面试评价 |
| `advance` | interview | 推进了候选人 |
| `offer` | result | 发起了 Offer |
| `onboard` | result | 候选人入职 |

## 扩展约定

- **新增动作**:先归入上述三组之一(按它所处的招聘阶段),复用该组的图标 + 配色,不新增颜色。
- **失败终态(淘汰 / 拒绝)** `reject`:作为**例外**单列,用警示色 —— `bg-destructive-soft` + `text-destructive`,图标 `UserRoundX`。当前数据未包含,先在此记录;若启用,需在 `ACTIVITY_GROUP` / `GROUP_STYLE` 增加一个 `reject` 组(不并入三组,因其语义是"负向结果",需要与正向流程明显区分)。
- 颜色语义对照(便于扩展时判断归色):
  - 灰 = 中性 / 早期 / 未产生倾向
  - 蓝 = 流程进行中 / 信息性
  - 绿 = 正向产出 / 成功
  - 红(例外)= 负向结果 / 终止

## 关联

- 视觉规范与 token 取值见 `UI Design Specification.md`(颜色 / 圆角 / 间距 token)。
- 「最近动态」是**实时活动流**,不受看板顶部/各卡片的日期筛选器影响(语义为"最新发生了什么")。
